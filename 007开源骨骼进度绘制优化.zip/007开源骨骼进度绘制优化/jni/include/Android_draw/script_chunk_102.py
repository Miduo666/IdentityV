")
            side_entries[0].setdefault("door_role_source", "maze_side_door_path" if side_entries[0].get("is_side_door_room") else "height")
    finalized.sort(key=lambda item: (item.get("door_role", ""), item.get("door_id", -1), item.get("uid", "")))
    return finalized

def _collect_goldrush_room_points(combat_core):
    points = []
    maze_system = _get_goldrush_maze_system(combat_core)
    if not maze_system:
        return points
    maze_object = getattr(maze_system, 'maze_object', None)
    rooms = getattr(maze_object, 'rooms', None) if maze_object else None
    side_door_room_indexes = _extract_goldrush_side_door_room_indexes(maze_system, rooms)
    for room in _iter_values(rooms):
        try:
            room_type = _safe_int(getattr(room, 'room_type', -1), -1)
            room_index = _safe_int(getattr(room, 'room_index', getattr(room, 'index', -1)), -1)
            config_id = _safe_int(getattr(room, 'config_id', getattr(room, 'cfg_id', -1)), -1)
            room_cfg = _get_dm_row('random_advanture_room_configs', config_id) if config_id > 0 else {}
            transform = room.world_transform() if hasattr(room, 'world_transform') else None
            translation = getattr(transform, 'translation', None) if transform else None
            pos = _vec3_to_list(translation) if translation else [0.0, 0.0, 0.0]
            room_type_name = _get_goldrush_room_type_name(room_type)
            group_names = _extract_goldrush_room_group_names(room)
            model_names = _extract_goldrush_room_model_names(room)
            voxel_points = _serialize_voxel_list(getattr(room, 'voxels', None), 256)
            path_points = _serialize_path_list(getattr(room, 'paths', None), 24, 24)
            wall_infos = _serialize_path_wall_infos(getattr(room, 'path_wall_infos', None), 32)
            outline_segments = _build_room_outline_segments(voxel_points, 128)
            world_outline_segments = _build_world_segments_from_outline(outline_segments, 128)
            world_path_segments = _build_world_path_segments(path_points, 128)
            doorway_world_segments = _build_world_doorway_segments(path_points, wall_infos, 64)
            is_side_door_room = room_index in side_door_room_indexes
            is_safe_room = 'DnyMonsterBound' in group_names
            is_piano_room = ('Inter_Piano' in group_names) or ('Piano' in model_names)
            has_treasure_group = 'TreasureGroup' in group_names
            has_core_lock_group = ('Inter_CoreLock' in group_names) or ('CoreLock' in model_names)
            has_harp_group = 'Inter_Harp' in group_names
            room_tags = []
            if room_type == 2:
                room_tags.append("front_door_room")
            if room_type == 5:
                room_tags.append("core_room")
            if room_type == 6:
                room_tags.append("treasure_room")
            if is_side_door_room:
                room_tags.append("side_door_room")
            if is_safe_room:
                room_tags.append("safe_room")
            if is_piano_room:
                room_tags.append("piano_room")
            if has_core_lock_group:
                room_tags.append("core_lock_room")
            if has_treasure_group:
                room_tags.append("treasure_group")
            if has_harp_group:
                room_tags.append("harp_room")
            if not room_tags and room_type not in GOLDRUSH_ROOM_TYPE_NAMES:
                continue
            if room_type == 2:
                room_label = "