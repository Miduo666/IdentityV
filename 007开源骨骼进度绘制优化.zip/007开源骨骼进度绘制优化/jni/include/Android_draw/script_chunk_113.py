"
        }
        payload["navigation_reference"] = {
            "maze_nav_system": "MazeNavSystem",
            "guideline_component": "UnitComponentType.GoldRushGuideLineTrail",
            "guideline_fields": ["path_points", "target_pos", "player_pos", "_smooth_points", "get_display_path", "screen_polyline"],
            "mark_component": "UnitComponentType.GoldRushMark",
            "minimap_runtime_chain": ["GoldRushMinimapStashSystem._icons", "MiniMap.draw_nav_path"],
            "path_runtime_chain": ["maze_object.rooms[*].paths", "maze.connected_path", "maze.side_door_path"]
        }
        payload["states"] = _build_table_entries('goldrush_state', ('camp', 'anim_name', 'anim_rate', 'ext_anim_name', 'ext_anim_rate', 'hide_handheld'))
        payload["skills"] = _build_table_entries('goldrush_skill', ('skill_type', 'skill_icon', 'skill_slot', 'skill_sound_id', 'skill_action', 'trigger_type', 'trigger_frame', 'state_conflict_col', 'state_conflict_row', 'is_attack'))
        global_table = _get_dm_table('goldrush_global_data')
        interesting_keys = (
            'survivor_jump_stamina_cost', 'survivor_low_stamina_threshold', 'survivor_run_stamina_cost',
            'survivor_run_stamina_recover', 'survivor_run_stamina_recover_interval',
            'survivor_stamina_cost_jump', 'survivor_stamina_cost_run',
            'butcher_run_stamina_cost', 'butcher_stamina_cost_run'
        )
        global_params = {}
        for key in interesting_keys:
            try:
                if key not in global_table:
                    continue
                value = global_table.get(key)
                if isinstance(value, (list, tuple)):
                    global_params[key] = [float(v) if isinstance(v, (int, float)) else _safe_uid_text(v) for v in value]
                elif isinstance(value, (int, float, bool)):
                    global_params[key] = value
                else:
                    global_params[key] = _safe_uid_text(value)
            except:
                pass
        payload["global_params"] = global_params
        payload["basecamp_ui"] = _build_table_entries('goldrush_base_camp_ui', ('icon_path', 'name_tid', 'interact_cd', 'interact_init_cd', 'ui_hint_distance', 'ui_interact_distance'))
        for entry in payload["basecamp_ui"]:
            entry["name"] = _resolve_tid_text(entry.get("name_tid", ''))
        payload["treasure_key_chain"] = {
            "music_box_item_id": GOLDRUSH_MUSIC_BOX_ITEM_ID,
            "music_box_item": _get_goldrush_item_names([GOLDRUSH_MUSIC_BOX_ITEM_ID]),
            "source_template_id": 109,
            "lock_template_id": 108,
            "harp_template_id": 116
        }
        payload["valid"] = bool(
            len(items) > 0 or payload["reward_boxes"] or payload["buffs"] or payload["states"] or
            payload["skills"] or payload["interact_types"] or payload["interact_conditions"] or
            payload["doorway_configs"]
        )
    except Exception as e:
        payload["error"] = str(e)
    return json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(',', ':'))

def _get_copycat_component_from_unit(unit, enum_name, keyword):
    if not unit:
        return None

    if hasattr(unit, 'get_component'):
        enum_value = getattr(UnitComponentType, enum_name, None)
        if enum_value is not None:
            try:
                comp = unit.get_component(enum_value)
                if comp:
                    return comp
            except:
                pass

        try:
            comp = unit.get_component(enum_name)
            if comp:
                return comp
        except:
            pass

    components = getattr(unit, 'components', None)
    if isinstance(components, dict):
        for comp_name, comp_obj in components.items():
            try:
                text = f"{comp_name} {type(comp_obj)}"
                if keyword.lower() in text.lower():
                    return comp_obj
            except:
                pass

    for attr in dir(unit):
        try:
            if keyword.lower() not in attr.lower():
                continue
            comp_obj = getattr(unit, attr)
            if comp_obj:
                return comp_obj
        except:
            pass

    return None

def _get_copycat_component(unit, combat_unit, enum_name, keyword):
    comp = _get_copycat_component_from_unit(combat_unit, enum_name, keyword)
    if comp:
        return comp
    return _get_copycat_component_from_unit(unit, enum_name, keyword)

def _get_components_dict(unit):
    components = getattr(unit, 'components', None)
    if isinstance(components, dict):
        return components
    return {}

def _get_copycat_role_id(unit, combat_unit=None):
    def detect_from_components(components):
        if not isinstance(components, dict):
            return -1
        for comp_name, comp in components.items():
            try:
                comp_name_str = str(comp_name)
                comp_type_str = str(type(comp))
                if 'IdentityComponent' not in comp_name_str and 'CopycatIdentityComponent' not in comp_type_str:
                    continue
                role_id = getattr(comp, 'identity_id', getattr(comp, 'role_type', -1))
                role_id = int(role_id)
                if role_id > 0:
                    return role_id
            except:
                pass
        return -1

    role_id = detect_from_components(_get_components_dict(combat_unit))
    if role_id > 0:
        return role_id
    role_id = detect_from_components(_get_components_dict(unit))
    if role_id > 0:
        return role_id

    identity_comp = _get_copycat_component(unit, combat_unit, 'CopycatIdentityComponent', 'IdentityComponent')
    if identity_comp:
        try:
            role_id = int(getattr(identity_comp, 'identity_id', getattr(identity_comp, 'role_type', -1)))
            if role_id > 0:
                return role_id
        except:
            pass

    return -1

def _get_copycat_identity_numbers(unit, combat_unit=None):
    def read_from_component(comp):
        if not comp:
            return (-1, -1, -1)
        try:
            role_id = _safe_int(getattr(comp, 'identity_id', getattr(comp, 'role_type', -1)), -1)
        except:
            role_id = -1
        try:
            camp_id = _safe_int(getattr(comp, 'camp_id', getattr(comp, 'camp', -1)), -1)
        except:
            camp_id = -1
        try:
            idx_value = getattr(comp, 'idx', getattr(comp, 'seat_idx', getattr(comp, 'index', -1)))
            idx_value = _safe_int(idx_value, -1)
            if idx_value >= 0:
                idx_value += 1
        except:
            idx_value = -1
        return (role_id, camp_id, idx_value)

    identity_comp = _get_copycat_component(unit, combat_unit, 'CopycatIdentityComponent', 'IdentityComponent')
    role_id, camp_id, idx_value = read_from_component(identity_comp)
    if role_id > 0 or camp_id > 0 or idx_value > 0:
        return (role_id, camp_id, idx_value)

    for holder in (combat_unit, unit):
        components = _get_components_dict(holder)
        if not isinstance(components, dict):
            continue
        for comp_name, comp in components.items():
            try:
                text = f"{comp_name} {type(comp)}"
                if 'identitycomponent' not in text.lower():
                    continue
                role_id, camp_id, idx_value = read_from_component(comp)
                if role_id > 0 or camp_id > 0 or idx_value > 0:
                    return (role_id, camp_id, idx_value)
            except:
                pass

    return (-1, -1, -1)

def _find_component_by_type_keyword(unit, combat_unit, keyword):
    for holder in (combat_unit, unit):
        components = _get_components_dict(holder)
        for _, comp in components.items():
            try:
                if keyword.lower() in str(type(comp)).lower():
                    return comp
            except:
                pass
    return None

def _get_copycat_player_units(player, room):
    result = []
    seen_uids = set()

    def append_unit(unit, fallback_uid=None):
        if not unit:
            return
        uid_text = get_player_uid(unit)
        if not uid_text or uid_text == "unknown":
            uid_text = _safe_uid_text(fallback_uid)
        if not uid_text or uid_text in seen_uids:
            return
        seen_uids.add(uid_text)
        result.append((uid_text, unit))

    try:
        gk_unit_mgr = getattr(GK, 'unit_mgr', None)
        if gk_unit_mgr and hasattr(gk_unit_mgr, 'get_copycat_player_units'):
            for unit in gk_unit_mgr.get_copycat_player_units() or []:
                append_unit(unit)
    except:
        pass

    room_unit_mgr = getattr(room, 'unit_mgr', None) if room else None
    if not result and room_unit_mgr:
        try:
            if hasattr(room_unit_mgr, 'get_copycat_player_units'):
                for unit in room_unit_mgr.get_copycat_player_units() or []:
                    append_unit(unit)
        except:
            pass

        player_dict = getattr(room_unit_mgr, 'player_dict', None)
        if isinstance(player_dict, dict):
            for dict_uid, unit in player_dict.items():
                append_unit(unit, dict_uid)

        if hasattr(room_unit_mgr, 'get_player_units'):
            try:
                for unit in room_unit_mgr.get_player_units() or []:
                    append_unit(unit)
            except:
                pass

    append_unit(player)
    return result

def _get_skill_entries(unit, combat_unit=None):
    for holder in (combat_unit, unit):
        skill_mgr = getattr(holder, 'ref_skill_mgr', getattr(holder, 'skill_mgr', None)) if holder else None
        if not skill_mgr:
            continue
        try:
            skill_dict = getattr(skill_mgr, 'skill_dct', getattr(skill_mgr, 'skill_dict', {}))
            iterator = skill_dict.items() if hasattr(skill_dict, 'items') else []
        except:
            iterator = []

        entries = []
        for skill_id, skill_obj in iterator:
            try:
                max_cd = 0.0
                if hasattr(skill_obj, 'get_cd_time'):
                    max_cd = _safe_float(skill_obj.get_cd_time(), 0.0)
                elif hasattr(skill_obj, 'skill_data'):
                    skill_data = getattr(skill_obj, 'skill_data', {}) or {}
                    if isinstance(skill_data, dict):
                        max_cd = _safe_float(skill_data.get('cd_time', 0.0), 0.0)

                current_cd = _safe_float(getattr(skill_obj, 'cd_delta', 0.0), 0.0)
                is_active = False
                activate_left = 0.0
                cd_comp = getattr(skill_obj, 'ref_cd_comp', None)
                if cd_comp and hasattr(cd_comp, 'is_in_activate'):
                    try:
                        is_active = bool(cd_comp.is_in_activate())
                    except:
                        is_active = False
                    if is_active and hasattr(cd_comp, 'get_left_activate_time'):
                        activate_left = _safe_float(cd_comp.get_left_activate_time(), 0.0)

                if max_cd <= 0.0 and current_cd <= 0.0 and not is_active:
                    continue

                entries.append({
                    "skill_id": _safe_uid_text(skill_id),
                    "current_cd": round(current_cd, 1),
                    "max_cd": round(max_cd, 1),
                    "is_active": bool(is_active),
                    "activate_left": round(activate_left, 1)
                })
            except:
                pass

        entries.sort(key=lambda item: item.get("skill_id", ""))
        return entries

    return []

def _build_copycat_advanced_payload_base():
    return {"type": "copycat_advanced", "valid": False, "players": []}

def _ensure_copycat_advanced_entry(entries_by_uid, uid):
    uid_text = str(uid or "")
    if not uid_text:
        return None
    if uid_text not in entries_by_uid:
        entries_by_uid[uid_text] = {
            "uid": uid_text,
            "role_id": -1,
            "identity_id": -1,
            "camp_id": -1,
            "idx": -1,
            "x": 0.0,
            "y": 0.0,
            "z": 0.0,
            "skill_cds": [],
            "tramp_infect_uids": [],
            "delivery_box_uids": [],
            "face_target_uid": "",
            "conspirator_guessed_identity_uids": [],
            "conspirator_left_guess_time": 0.0,
            "hunter_mark_uid": "",
            "police_bullet_count": -1,
            "chess_guess_right_count": -1
        }
    return entries_by_uid[uid_text]

def _start_incremental_copycat_advanced_collector():
    state = INCREMENTAL_COLLECTOR_STATE.get("copycat_advanced", {})
    state["active"] = True
    state["items"] = []
    state["index"] = 0
    state["entries_by_uid"] = {}
    try:
        player = getattr(GK, 'g_unit', None)
        room = getattr(player, 'room', None) if player else None
        if not player or not room:
            return
        combat_core = getattr(room, 'combat_core', None)
        ref_unit_mgr = getattr(combat_core, 'ref_unit_mgr', None) if combat_core else None
        for uid_text, unit in _get_copycat_player_units(player, room):
            combat_unit = None
            if ref_unit_mgr and hasattr(ref_unit_mgr, 'get_unit'):
                try:
                    combat_unit = ref_unit_mgr.get_unit(getattr(unit, 'uid', None) or uid_text)
                except:
                    combat_unit = None
            state["items"].append((uid_text, unit, combat_unit))
    except:
        pass

def _append_incremental_copycat_advanced_entry(entries_by_uid, uid_text, unit, combat_unit):
    entry = _ensure_copycat_advanced_entry(entries_by_uid, uid_text)
    if entry is None:
        return
    entry["skill_cds"] = _get_skill_entries(unit, combat_unit)
    identity_role_id, camp_id, idx_value = _get_copycat_identity_numbers(unit, combat_unit)
    role_id = _get_copycat_role_id(unit, combat_unit)
    if role_id <= 0 and identity_role_id > 0:
        role_id = identity_role_id
    entry["role_id"] = role_id
    entry["identity_id"] = identity_role_id if identity_role_id > 0 else role_id
    entry["camp_id"] = camp_id
    entry["idx"] = idx_value
    try:
        pos = unit.get_position3() if hasattr(unit, 'get_position3') else getattr(unit, 'position', None)
        if pos:
            entry["x"] = round(_safe_float(getattr(pos, 'x', 0.0), 0.0), 1)
            entry["y"] = round(_safe_float(getattr(pos, 'y', 0.0), 0.0), 1)
            entry["z"] = round(_safe_float(getattr(pos, 'z', 0.0), 0.0), 1)
    except:
        pass
    if role_id == 202:
        face_comp = _get_copycat_component(unit, combat_unit, 'CopycatFaceManComponent', 'FaceMan') or _find_component_by_type_keyword(unit, combat_unit, 'FaceManComponent')
        if face_comp:
            entry["face_target_uid"] = _safe_uid_text(getattr(face_comp, 'tar_uid', None))
    elif role_id == 203:
        conspirator_comp = _get_copycat_component(unit, combat_unit, 'CopycatConspiratorComponent', 'Conspirator') or _find_component_by_type_keyword(unit, combat_unit, 'ConspiratorComponent')
        if conspirator_comp:
            entry["conspirator_guessed_identity_uids"] = _normalize_uid_collection(getattr(conspirator_comp, 'has_guessed_identity', []))
            if hasattr(conspirator_comp, 'get_left_guess_time'):
                try:
                    entry["conspirator_left_guess_time"] = round(_safe_float(conspirator_comp.get_left_guess_time(), 0.0), 1)
                except:
                    pass
    elif role_id == 104:
        hunter_comp = _get_copycat_component(unit, combat_unit, 'CopycatHunterComponent', 'Hunter') or _find_component_by_type_keyword(unit, combat_unit, 'HunterComponent')
        if hunter_comp:
            entry["hunter_mark_uid"] = _safe_uid_text(getattr(hunter_comp, 'mark_uid', getattr(hunter_comp, 'target_uid', None)))
    elif role_id == 103:
        police_comp = _get_copycat_component(unit, combat_unit, 'CopycatPoliceComponent', 'Police') or _find_component_by_type_keyword(unit, combat_unit, 'PoliceComponent')
        if police_comp:
            entry["police_bullet_count"] = _safe_int(getattr(police_comp, 'bullet_count', -1), -1)
    elif role_id == 304:
        chess_comp = _get_copycat_component(unit, combat_unit, 'CopycatChessPlayerComponent', 'ChessPlayer') or _find_component_by_type_keyword(unit, combat_unit, 'ChessPlayerComponent')
        if chess_comp:
            entry["chess_guess_right_count"] = _safe_int(getattr(chess_comp, 'guess_right_count', 0), 0)
    delivery_comp = None
    if role_id == 302:
        delivery_comp = _get_copycat_component(unit, combat_unit, 'CopycatDeliveryManComponent', 'DeliveryMan')
    if not delivery_comp:
        delivery_comp = _find_component_by_type_keyword(unit, combat_unit, 'DeliveryManComponent')
    if delivery_comp and (role_id in (-1, 302)):
        entry["delivery_box_uids"] = _normalize_uid_collection(getattr(delivery_comp, 'round_box_uids', set()))
    tramp_comp = None
    if role_id == 301:
        tramp_comp = _get_copycat_component(unit, combat_unit, 'CopycatTrampComponent', 'Tramp')
    if not tramp_comp:
        tramp_comp = _find_component_by_type_keyword(unit, combat_unit, 'TrampComponent')
    if tramp_comp and (role_id in (-1, 301)):
        infect_uids = getattr(tramp_comp, 'infect_uids', None)
        if infect_uids is None:
            for attr in dir(tramp_comp):
                try:
                    if 'infect' not in attr.lower():
                        continue
                    candidate = getattr(tramp_comp, attr)
                    if isinstance(candidate, (set, list, tuple, dict)):
                        infect_uids = candidate
                        break
                except:
                    pass
        entry["tramp_infect_uids"] = _normalize_uid_collection(infect_uids)

def _run_incremental_copycat_advanced_collector(loop_now=None, start_new=False):
    state = INCREMENTAL_COLLECTOR_STATE.get("copycat_advanced", {})
    if start_new or not state.get("active"):
        _start_incremental_copycat_advanced_collector()
        state = INCREMENTAL_COLLECTOR_STATE.get("copycat_advanced", {})
    items = state.get("items", []) or []
    entries_by_uid = state.get("entries_by_uid", {}) or {}
    index = int(state.get("index", 0) or 0)
    end_index = min(len(items), index + INCREMENTAL_COPYCAT_ADVANCED_CHUNK_SIZE)
    for current_index in range(index, end_index):
        uid_text, unit, combat_unit = items[current_index]
        try:
            _append_incremental_copycat_advanced_entry(entries_by_uid, uid_text, unit, combat_unit)
        except:
            pass
    state["index"] = end_index
    state["entries_by_uid"] = entries_by_uid
    if end_index >= len(items):
        payload = _build_copycat_advanced_payload_base()
        payload["players"] = sorted(
            entries_by_uid.values(),
            key=lambda item: (int(item.get("idx", -1) if isinstance(item.get("idx", -1), int) else -1), item.get("uid", ""))
        )
        payload["valid"] = len(payload["players"]) > 0
        json_payload = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(',', ':'))
        _reset_incremental_collector("copycat_advanced")
        return json_payload
    return None

def collect_copycat_advanced_data():
    payload = None
    try:
        payload = _run_incremental_copycat_advanced_collector(None, True)
        while payload is None and _incremental_collector_active("copycat_advanced"):
            payload = _run_incremental_copycat_advanced_collector(None, False)
    except:
        payload = None
    return payload or json.dumps(_build_copycat_advanced_payload_base(), ensure_ascii=False, sort_keys=True, separators=(',', ':'))

def collect_copycat_meeting_data():
    payload = {
        "type": "copycat_meeting_state",
        "valid": False,
        "is_meeting": False,
        "scene_type": -1,
        "scene_name": "",
        "round_count": -1
    }

    try:
        player = getattr(GK, 'g_unit', None)
        room = getattr(player, 'room', None) if player else None
        combat_core = getattr(room, 'combat_core', None) if room else None
        if not combat_core:
            return json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(',', ':'))

        try:
            from common_cs.combat_core.enum_types.SystemType import SystemType
        except:
            SystemType = None
        try:
            from common_cs.combat_core.consts.copycat.CopycatConsts import SceneType
        except:
            SceneType = None
        if SystemType is None:
            return json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(',', ':'))

        round_system = None
        try:
            round_system = combat_core.get_system(SystemType.CopycatRound)
        except:
            round_system = None
        if not round_system:
            return json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(',', ':'))

        scene_type = -1
        scene_name = ""
        is_meeting = False

        try:
            if hasattr(round_system, 'is_meeting_round'):
                is_meeting = bool(round_system.is_meeting_round())
        except:
            is_meeting = False

        handler = getattr(round_system, 'sys_handler', None)
        try:
            scene_type = _safe_int(getattr(handler, 'scene_type', getattr(round_system, 'scene_type', -1)), -1)
        except:
            scene_type = -1

        if SceneType is not None and scene_type >= 0:
            try:
                for attr_name in dir(SceneType):
                    if attr_name.startswith('_'):
                        continue
                    try:
                        enum_value = getattr(SceneType, attr_name)
                        if _safe_int(enum_value, -9999) == scene_type:
                            scene_name = attr_name
                            break
                    except:
                        pass
            except:
                scene_name = ""

        review_system = None
        try:
            review_system = combat_core.get_system(SystemType.CopycatReview)
        except:
            review_system = None

        review_handler = getattr(review_system, 'sys_handler', review_system)
        round_count = _safe_int(getattr(review_handler, 'round_count', getattr(review_system, 'round_count', -1)), -1)

        payload["valid"] = True
        payload["is_meeting"] = bool(is_meeting)
        payload["scene_type"] = scene_type
        payload["scene_name"] = scene_name
        payload["round_count"] = round_count
    except Exception as e:
        payload["error"] = str(e)

    return json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(',', ':'))

def collect_self_debuff_data():
    payload = {
        "type": "self_debuff",
        "valid": False,
        "uid": "",
        "is_civilian": False,
        "water_power": 0.0,
        "cold_wax_progress": 0.0,
        "heat_wax_progress": 0.0
    }

    try:
        me = getattr(GK, 'g_unit', None)
        if not me:
            return json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(',', ':'))

        payload["uid"] = get_player_uid(me)
        payload["is_civilian"] = bool(getattr(me, 'is_civilian', False))
        if not payload["is_civilian"]:
            return json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(',', ':'))

        payload["water_power"] = round(_safe_float(getattr(me, 'water_power', 0.0), 0.0), 1)

        def _normalize_wax_progress(raw_value):
            raw = _safe_float(raw_value, 0.0)
            # 