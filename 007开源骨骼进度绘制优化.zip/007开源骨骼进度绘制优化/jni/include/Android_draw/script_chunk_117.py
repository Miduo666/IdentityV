")
        buff_items = []
        buff_objects = {}
        try:
            buff_dct = getattr(buff_mgr, 'buff_dct', None)
            if buff_dct:
                buff_items = list(buff_dct.items())
                for bid, buff_obj in buff_items:
                    buff_objects[bid] = buff_obj
        except:
            buff_items = []
            buff_objects = {}
        raw_buff_ids = []
        if not buff_items:
            try:
                getter = getattr(buff_mgr, 'get_buff_list', None)
                if getter:
                    raw_buff_ids = getter() or []
            except:
                raw_buff_ids = []
            if raw_buff_ids and not isinstance(raw_buff_ids, list):
                try:
                    raw_buff_ids = list(raw_buff_ids)
                except:
                    raw_buff_ids = []
        if not buff_items and not raw_buff_ids:
            try:
                fallback_list = getattr(buff_mgr, '_buff_list', None)
                if fallback_list:
                    raw_buff_ids = list(fallback_list)
            except:
                raw_buff_ids = []
        if not buff_items and not raw_buff_ids:
            return
        unit_entry = {
            "uid": uid,
            "pid": pid,
            "is_butcher": is_butcher,
            "is_civilian": is_civilian,
            "unit_type": unit_type_text,
            "buff_count": 0,
            "buffs": []
        }
        seen_buff_ids = set()
        iter_items = buff_items if buff_items else [(raw_buff_id, None) for raw_buff_id in raw_buff_ids]
        for raw_buff_id, buff_obj_from_items in iter_items:
            buff_id_text = str(raw_buff_id)
            if not buff_id_text or buff_id_text in seen_buff_ids:
                continue
            seen_buff_ids.add(buff_id_text)
            buff_entry = {"buff_id": buff_id_text}
            buff_obj = buff_obj_from_items
            buff_level_data = None
            try:
                if not buff_obj and raw_buff_id in buff_objects:
                    buff_obj = buff_objects.get(raw_buff_id)
                elif not buff_obj and buff_id_text in buff_objects:
                    buff_obj = buff_objects.get(buff_id_text)
            except:
                pass
            if not buff_obj:
                try:
                    get_buff = getattr(buff_mgr, 'get_buff', None)
                    if get_buff:
                        try:
                            buff_obj = get_buff(raw_buff_id)
                        except:
                            buff_obj = get_buff(buff_id_text)
                except:
                    buff_obj = None
            if buff_obj:
                try:
                    if hasattr(buff_obj, 'data') and hasattr(buff_obj, 'level'):
                        buff_level_data = buff_obj.data[buff_obj.level]
                    if utils and hasattr(utils, 'do_all_tid_replace') and buff_level_data:
                        raw_name_tid = ""
                        try:
                            raw_name_tid = buff_level_data.get('buff_name', '')
                        except:
                            raw_name_tid = ""
                        if raw_name_tid:
                            buff_entry["buff_name_tid"] = str(raw_name_tid)
                        if raw_name_tid:
                            buff_name = utils.do_all_tid_replace(raw_name_tid)
                            if buff_name:
                                buff_entry["buff_name"] = str(buff_name)
                except:
                    pass
                layer = getattr(buff_obj, 'layer', None)
                try:
                    resolved_left_time = _resolve_buff_remaining_seconds(buff_obj, buff_level_data, now_time)
                    if resolved_left_time is not None:
                        buff_entry["left_time"] = round(max(0.0, float(resolved_left_time)), 1)
                except:
                    pass
                try:
                    if layer is not None:
                        layer_value = float(layer)
                        buff_entry["layer"] = int(layer_value) if layer_value.is_integer() else layer_value
                except:
                    try:
                        if layer is not None:
                            buff_entry["layer"] = str(layer)
                    except:
                        pass
                try:
                    if isinstance(buff_level_data, dict):
                        fragrance_flag = buff_level_data.get('is_fragrance_can_back', None)
                        if fragrance_flag is not None:
                            buff_entry["is_fragrance_can_back"] = bool(fragrance_flag)
                        special_time = buff_level_data.get('special_time', None)
                        if special_time is not None:
                            special_time_value = float(special_time)
                            if special_time_value > 100.0:
                                special_time_value = special_time_value / 1000.0
                            buff_entry["special_time"] = round(max(0.0, special_time_value), 3)
                except:
                    pass
            unit_entry["buffs"].append(buff_entry)
        if unit_entry["buffs"]:
            unit_entry["buff_count"] = len(unit_entry["buffs"])
            payload["units"].append(unit_entry)
    except:
        pass

def _run_incremental_all_unit_buffs_collector(loop_now=None, start_new=False):
    state = INCREMENTAL_COLLECTOR_STATE.get("all_unit_buffs", {})
    if start_new or not state.get("active"):
        _start_incremental_all_unit_buffs_collector()
        state = INCREMENTAL_COLLECTOR_STATE.get("all_unit_buffs", {})
    payload = state.get("result") or _build_all_unit_buffs_payload_base()
    items = state.get("items", []) or []
    index = int(state.get("index", 0) or 0)
    end_index = min(len(items), index + INCREMENTAL_ALL_UNIT_BUFFS_CHUNK_SIZE)
    for current_index in range(index, end_index):
        _append_incremental_all_unit_buffs_unit(payload, items[current_index])
    state["index"] = end_index
    state["result"] = payload
    if end_index >= len(items):
        payload["buff_unit_count"] = len(payload["units"])
        payload["valid"] = payload["buff_unit_count"] > 0
        json_payload = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(',', ':'))
        _reset_incremental_collector("all_unit_buffs")
        return json_payload
    return None


def collect_all_unit_buffs_data():
    payload = None
    try:
        payload = _run_incremental_all_unit_buffs_collector(None, True)
        while payload is None and _incremental_collector_active("all_unit_buffs"):
            payload = _run_incremental_all_unit_buffs_collector(None, False)
    except:
        payload = None
    return payload or json.dumps(_build_all_unit_buffs_payload_base(), ensure_ascii=False, sort_keys=True, separators=(',', ':'))


import socket

HOOK_RUNTIME_IO_LOCK = threading.Lock()
HOOK_CONTROL_MAX_PACKETS_PER_TICK = 4
GOLDRUSH_HOOK_INSTALL_RETRY_SEC = 2.0
HOOK_RUNTIME_IO_STATE = {
    "sock": None,
    "server_addr": ('127.0.0.1', 55555),
    "bones_sock": None,
    "bones_server_addr": ('127.0.0.1', 55557),
    "control_sock": None,
    "control_addr": ('127.0.0.1', 55556),
    "last_sent_times": {},
    "last_panels_keepalive_time": 0.0,
    "last_panels_payload": "",
    "last_goldrush_scene_snapshot_token": 0,
    "last_goldrush_nav_request_token": 0,
    "pending_goldrush_night_view_token": 0,
    "pending_goldrush_scene_snapshot_token": 0,
    "pending_goldrush_nav_request_token": 0,
    "pending_goldrush_nav_targets": [],
    "info_old_timing_wait_since": 0.0,
    "goldrush_hook_installed": False,
    "goldrush_hook_last_attempt_at": 0.0
}

def _ensure_hook_runtime_io():
    try:
        with HOOK_RUNTIME_IO_LOCK:
            if HOOK_RUNTIME_IO_STATE.get("sock") is None:
                udp_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                try:
                    udp_sock.setblocking(False)
                except:
                    pass
                HOOK_RUNTIME_IO_STATE["sock"] = udp_sock
            if HOOK_RUNTIME_IO_STATE.get("bones_sock") is None:
                bones_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                try:
                    bones_sock.setblocking(False)
                except:
                    pass
                HOOK_RUNTIME_IO_STATE["bones_sock"] = bones_sock
            if HOOK_RUNTIME_IO_STATE.get("control_sock") is None:
                try:
                    control_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                    control_sock.bind(HOOK_RUNTIME_IO_STATE["control_addr"])
                    control_sock.setblocking(False)
                    HOOK_RUNTIME_IO_STATE["control_sock"] = control_sock
                except:
                    HOOK_RUNTIME_IO_STATE["control_sock"] = False
        return HOOK_RUNTIME_IO_STATE
    except:
        return HOOK_RUNTIME_IO_STATE

def _execute_force_invincibility():
    try:
        import game_kernel as GK
        from common_cs import ComuKeys
        if not hasattr(GK, 'g_world_mgr') or not GK.g_world_mgr.cur_world:
            return
        cur_world = GK.g_world_mgr.cur_world
        if not hasattr(cur_world, 'battle_event'):
            return
        if not hasattr(GK, 'g_unit') or not GK.g_unit:
            return
        cur_world.battle_event.send_battle_event(
            ComuKeys.GAME_BATTLE_EVENT_TYPE.SP_WILDMAN_EVENT,
            {
                'opt': ComuKeys.SP_WILDMAN_OPT.OTHER_USE_EXTRA,
                'uid': GK.g_unit.uid
            }
        )
    except:
        pass

def _poll_hook_control_packets():
    state = _ensure_hook_runtime_io()
    control_sock = state.get("control_sock")
    if not control_sock:
        return
    try:
        processed_count = 0
        while True:
            if processed_count >= HOOK_CONTROL_MAX_PACKETS_PER_TICK:
                break
            packet, _ = control_sock.recvfrom(4096)
            if not packet:
                break
            processed_count += 1
            msg = packet.decode('utf-8', errors='ignore')
            if msg == "FORCE_FAST_VAULT":
                try:
                    if p := getattr(GK, 'g_unit', None):
                        if hasattr(p, 'get_panel_span_type'):
                            p.get_panel_span_type = lambda *_: 2
                        if hasattr(p, 'get_span_type'):
                            p.get_span_type = lambda *_: 2
                except:
                    pass
            elif msg == "FORCE_INVINCIBILITY":
                _execute_force_invincibility()
            else:
                update_hook_control_state(msg)
    except BlockingIOError:
        pass
    except:
        pass

def _maybe_install_goldrush_player_late_tick_hook(loop_now):
    state = _ensure_hook_runtime_io()
    if bool(state.get("goldrush_hook_installed")):
        return True
    last_attempt_at = float(state.get("goldrush_hook_last_attempt_at", 0.0) or 0.0)
    if loop_now - last_attempt_at < GOLDRUSH_HOOK_INSTALL_RETRY_SEC:
        return False
    state["goldrush_hook_last_attempt_at"] = loop_now
    try:
        installed = bool(install_goldrush_player_late_tick_hook())
    except:
        installed = False
    if installed:
        state["goldrush_hook_installed"] = True
    return installed

def _queue_tick_misc_requests():
    state = _ensure_hook_runtime_io()
    try:
        with HOOK_CONTROL_LOCK:
            current_night_view_token = _safe_int(HOOK_CONTROL_STATE.get("goldrush_night_view_token", 0), 0)
            current_scene_snapshot_token = _safe_int(HOOK_CONTROL_STATE.get("goldrush_scene_snapshot_token", 0), 0)
            current_nav_request_token = _safe_int(HOOK_CONTROL_STATE.get("goldrush_nav_request_token", 0), 0)
            current_nav_targets = [dict(item) for item in (HOOK_CONTROL_STATE.get("goldrush_nav_targets", []) or [])]
    except:
        return state

    if current_night_view_token > 0 and current_night_view_token != _safe_int(state.get("pending_goldrush_night_view_token", 0), 0):
        state["pending_goldrush_night_view_token"] = current_night_view_token

    if current_scene_snapshot_token > 0 and current_scene_snapshot_token != _safe_int(state.get("last_goldrush_scene_snapshot_token", 0), 0):
        state["pending_goldrush_scene_snapshot_token"] = current_scene_snapshot_token

    if current_nav_request_token > 0 and current_nav_request_token != _safe_int(state.get("last_goldrush_nav_request_token", 0), 0):
        state["pending_goldrush_nav_request_token"] = current_nav_request_token
        state["pending_goldrush_nav_targets"] = current_nav_targets
    return state

def _drain_tick_misc_requests(loop_now):
    state = _ensure_hook_runtime_io()

    pending_night_view_token = _safe_int(state.get("pending_goldrush_night_view_token", 0), 0)
    if pending_night_view_token > 0 and pending_night_view_token != GOLDRUSH_NIGHT_VIEW_LAST_MANUAL_TOKEN:
        _maybe_run_goldrush_night_view_request(loop_now)
        state["pending_goldrush_night_view_token"] = 0
        return

    pending_scene_snapshot_token = _safe_int(state.get("pending_goldrush_scene_snapshot_token", 0), 0)
    if pending_scene_snapshot_token > 0 and pending_scene_snapshot_token != _safe_int(state.get("last_goldrush_scene_snapshot_token", 0), 0):
        try:
            goldrush_scene_snapshot_json = collect_goldrush_scene_snapshot_data()
            if goldrush_scene_snapshot_json:
                _set_tick_payload("goldrush_scene_snapshot", goldrush_scene_snapshot_json, loop_now)
        except:
            pass
        state["last_goldrush_scene_snapshot_token"] = pending_scene_snapshot_token
        state["pending_goldrush_scene_snapshot_token"] = 0
        return

    pending_nav_request_token = _safe_int(state.get("pending_goldrush_nav_request_token", 0), 0)
    if pending_nav_request_token > 0 and pending_nav_request_token != _safe_int(state.get("last_goldrush_nav_request_token", 0), 0):
        try:
            pending_nav_targets = [dict(item) for item in (state.get("pending_goldrush_nav_targets", []) or [])]
            goldrush_nav_paths_json = collect_goldrush_nav_paths_data(pending_nav_request_token, pending_nav_targets)
            if goldrush_nav_paths_json:
                _set_tick_payload("goldrush_nav_paths", goldrush_nav_paths_json, loop_now)
        except:
            pass
        state["last_goldrush_nav_request_token"] = pending_nav_request_token
        state["pending_goldrush_nav_request_token"] = 0
        state["pending_goldrush_nav_targets"] = []

def _run_tick_misc_collectors(loop_now, collector_start):
    _maybe_run_goldrush_fog_request(loop_now)
    _maybe_run_goldrush_seed_box_request(loop_now)
    state = _queue_tick_misc_requests()
    if _tick_due(loop_now, "misc_request_exec", RUN_TICK_MISC_REQUEST_INTERVAL_SEC):
        _drain_tick_misc_requests(loop_now)
    if _run_tick_budget_exceeded(collector_start):
        return

    if get_hook_control_flag("need_info") and _tick_due(loop_now, "info", _get_dynamic_tick_interval("info") or 0.45):
        try:
            info_readiness = probe_info_readiness(get_available_unit_mgr())
            use_full_info = bool(info_readiness.get('full_ready'))
            if not use_full_info and info_readiness.get('old_timing_ready'):
                if float(state.get("info_old_timing_wait_since", 0.0) or 0.0) <= 0.0:
                    state["info_old_timing_wait_since"] = loop_now
                if (loop_now - float(state.get("info_old_timing_wait_since", 0.0) or 0.0)) >= 2.5:
                    use_full_info = True
            else:
                state["info_old_timing_wait_since"] = 0.0

            if use_full_info:
                info_list = _run_incremental_info_collector(loop_now, info_readiness, True)
            else:
                info_list = collect_info(False, info_readiness)
            if info_list:
                _set_tick_payload("info", '\n'.join(info_list), loop_now)
        except:
            pass
    if _run_tick_budget_exceeded(collector_start):
        return

    copycat_advanced_cycle_active = _incremental_collector_active("copycat_advanced")
    if get_hook_control_flag("need_copycat_advanced") and (copycat_advanced_cycle_active or _tick_due(loop_now, "copycat_advanced", 0.28)):
        try:
            copycat_advanced_json = _run_incremental_copycat_advanced_collector(loop_now, not copycat_advanced_cycle_active)
            if copycat_advanced_json:
                _set_tick_payload("copycat_advanced", copycat_advanced_json, loop_now)
        except:
            pass
    if _run_tick_budget_exceeded(collector_start):
        return

    if get_hook_control_flag("need_goldrush_runtime") and _tick_due(loop_now, "goldrush_runtime", 0.50):
        try:
            goldrush_runtime_json = collect_goldrush_runtime_data()
            if goldrush_runtime_json:
                _set_tick_payload("goldrush_runtime", goldrush_runtime_json, loop_now)
        except:
            pass
    if _run_tick_budget_exceeded(collector_start):
        return

    if get_hook_control_flag("need_goldrush_monster_hp") and _tick_due(loop_now, "goldrush_monster_hp", 0.35):
        try:
            goldrush_monster_hp_json = collect_goldrush_monster_hp_data()
            if goldrush_monster_hp_json:
                _set_tick_payload("goldrush_monster_hp", goldrush_monster_hp_json, loop_now)
        except:
            pass
    if _run_tick_budget_exceeded(collector_start):
        return

    if get_hook_control_flag("need_goldrush_reference") and _tick_due(loop_now, "goldrush_reference", 2.5):
        try:
            goldrush_reference_json = collect_goldrush_reference_data()
            if goldrush_reference_json:
                _set_tick_payload("goldrush_reference", goldrush_reference_json, loop_now)
        except:
            pass
    if _run_tick_budget_exceeded(collector_start):
        return

    if _run_tick_budget_exceeded(collector_start):
        return

def _flush_tick_payloads(loop_now):
    state = _ensure_hook_runtime_io()
    sock = state.get("sock")
    bones_sock = state.get("bones_sock")
    if sock is None or bones_sock is None:
        return

    server_addr = state.get("server_addr")
    bones_server_addr = state.get("bones_server_addr")
    last_sent_times = state.setdefault("last_sent_times", {})

    _send_cached_payload(sock, server_addr, "actions", last_sent_times)

    if get_hook_control_flag("enable_auto_hook") and get_hook_control_flag("need_bones"):
        _send_cached_payload(bones_sock, bones_server_addr, "bones", last_sent_times)
    if get_hook_control_flag("need_matrix_raw"):
        _send_cached_payload(sock, server_addr, "matrix_raw", last_sent_times)
    if get_hook_control_flag("need_violin_notes"):
        _send_cached_payload(sock, server_addr, "violin_notes", last_sent_times)
    if get_hook_control_flag("need_wuchang_umbrella"):
        _send_cached_payload(sock, server_addr, "wuchang_umbrella", last_sent_times)
    if get_hook_control_flag("enable_auto_hook") and _hook_need_special_units_enabled():
        _send_cached_payload(sock, server_addr, "mary_mirror", last_sent_times)
        _send_cached_payload(sock, server_addr, "special_units", last_sent_times)
    if get_hook_control_flag("enable_auto_hook") and get_hook_control_flag("need_special_unit_bones"):
        _send_cached_payload(bones_sock, bones_server_addr, "special_unit_bones", last_sent_times)
    if get_hook_control_flag("need_knight_predictions"):
        _send_cached_payload(sock, server_addr, "knight_predictions", last_sent_times)
    if get_hook_control_flag("need_opera_hit_test"):
        _send_cached_payload(sock, server_addr, "opera_shadow_leap", last_sent_times)

    if get_hook_control_flag("need_panels"):
        panel_payload, panel_updated_at = _get_tick_payload("panels")
        if panel_payload:
            has_new_sample = panel_updated_at > float(last_sent_times.get("panels", 0.0) or 0.0)
            payload_changed = (panel_payload != state.get("last_panels_payload", ""))
            keepalive_due = (loop_now - float(state.get("last_panels_keepalive_time", 0.0) or 0.0) >= 0.75)
            send_ok = False
            if (has_new_sample and payload_changed) or (keepalive_due and state.get("last_panels_payload", "") == panel_payload):
                try:
                    sock.sendto(panel_payload.encode('utf-8'), server_addr)
                    state["last_panels_keepalive_time"] = loop_now
                    state["last_panels_payload"] = panel_payload
                    send_ok = True
                except BlockingIOError:
                    pass
                except:
                    pass
            if has_new_sample and (send_ok or not payload_changed):
                last_sent_times["panels"] = panel_updated_at

    if get_hook_control_flag("need_info"):
        _send_cached_payload(sock, server_addr, "info", last_sent_times)
    if get_hook_control_flag("need_qte_state"):
        _send_cached_payload(sock, server_addr, "qte_state", last_sent_times)
    _send_cached_payload(sock, server_addr, "goldrush_runtime", last_sent_times)
    if get_hook_control_flag("need_goldrush_monster_hp"):
        _send_cached_payload(sock, server_addr, "goldrush_monster_hp", last_sent_times)
    if get_hook_control_flag("need_goldrush_reference"):
        _send_cached_payload(sock, server_addr, "goldrush_reference", last_sent_times)
    if _safe_int(HOOK_CONTROL_STATE.get("goldrush_scene_snapshot_token", 0), 0) > 0:
        _send_cached_payload(sock, server_addr, "goldrush_scene_snapshot", last_sent_times)
    if _safe_int(HOOK_CONTROL_STATE.get("goldrush_nav_request_token", 0), 0) > 0:
        _send_cached_payload(sock, server_addr, "goldrush_nav_paths", last_sent_times)
    if get_hook_control_flag("need_copycat_advanced"):
        _send_cached_payload(sock, server_addr, "copycat_advanced", last_sent_times)
    if get_hook_control_flag("need_copycat_meeting"):
        _send_cached_payload(sock, server_addr, "copycat_meeting", last_sent_times)
    if get_hook_control_flag("need_self_debuff"):
        _send_cached_payload(sock, server_addr, "self_debuff", last_sent_times)
    if get_hook_control_flag("need_all_unit_buffs"):
        _send_cached_payload(sock, server_addr, "all_unit_buffs", last_sent_times)
    if get_hook_control_flag("need_batter_auto_cancel"):
        _send_cached_payload(sock, server_addr, "self_batter_skill", last_sent_times)
    if get_hook_control_flag("need_low_latency_hunter_actions"):
        _send_cached_payload(sock, server_addr, "hunter_fast_actions", last_sent_times)

def run_tick_collectors(now=None):
    try:
        loop_now = float(now if now is not None else time.time())
    except:
        loop_now = time.time()
    collector_start = time.time()
    _maybe_install_goldrush_player_late_tick_hook(loop_now)
    try:
        map_info = get_current_map_info() or {}
    except:
        map_info = {}
    is_goldrush_tick = bool(map_info.get("is_goldrush"))

    if _tick_due(loop_now, "hook_control_poll", RUN_TICK_CONTROL_POLL_INTERVAL_SEC):
        _poll_hook_control_packets()
    if _run_tick_budget_exceeded(collector_start):
        return

    try:
        if _tick_due(loop_now, "camera_control_apply", RUN_TICK_CAMERA_CONTROL_INTERVAL_SEC):
            apply_hook_camera_control()
    except:
        pass
    if _run_tick_budget_exceeded(collector_start):
        return

    try:
        if _tick_due(loop_now, "self_state_override_apply", RUN_TICK_SELF_STATE_OVERRIDE_INTERVAL_SEC):
            apply_self_state_override(loop_now)
    except:
        pass
    if _run_tick_budget_exceeded(collector_start):
        return

    if is_goldrush_tick:
        try:
            _run_tick_misc_collectors(loop_now, time.time())
        except:
            pass

    try:
        bones_cycle_active = _incremental_collector_active("bones")
        if get_hook_control_flag("enable_auto_hook") and get_hook_control_flag("need_bones") and (bones_cycle_active or _tick_due(loop_now, "bones", _get_dynamic_tick_interval("bones"))):
            bones_json = _run_incremental_bone_collector(loop_now, not bones_cycle_active)
            if bones_json and '""' not in bones_json:
                _set_tick_payload("bones", bones_json, loop_now)
        if _run_tick_budget_exceeded(collector_start):
            raise _TickCollectorBudgetStop()

        actions_cycle_active = _incremental_collector_active("actions")
        if actions_cycle_active or _tick_due(loop_now, "actions", _get_dynamic_tick_interval("actions")):
            action_json = _run_incremental_action_collector(loop_now, not actions_cycle_active)
            if action_json:
                _set_tick_payload("actions", action_json, loop_now)
        if _run_tick_budget_exceeded(collector_start):
            raise _TickCollectorBudgetStop()

        if get_hook_control_flag("need_low_latency_hunter_actions") and _tick_due(loop_now, "hunter_fast_actions", _get_dynamic_tick_interval("hunter_fast_actions")):
            hunter_fast_json = collect_hunter_fast_actions_data()
            if hunter_fast_json:
                _set_tick_payload("hunter_fast_actions", hunter_fast_json, loop_now)
        if _run_tick_budget_exceeded(collector_start):
            raise _TickCollectorBudgetStop()

        if should_collect_self_batter_auto_cancel() and _tick_due(loop_now, "self_batter_skill", 0.05):
            batter_skill_json = collect_self_batter_auto_cancel_data()
            if batter_skill_json:
                _set_tick_payload("self_batter_skill", batter_skill_json, loop_now)
        if _run_tick_budget_exceeded(collector_start):
            raise _TickCollectorBudgetStop()

        if get_hook_control_flag("need_matrix_raw") and _tick_due(loop_now, "matrix_raw", 0.14):
            matrix_json = collect_matrix_raw_data()
            if matrix_json:
                _set_tick_payload("matrix_raw", matrix_json, loop_now)
        if _run_tick_budget_exceeded(collector_start):
            raise _TickCollectorBudgetStop()

        if get_hook_control_flag("need_violin_notes") and _tick_due(loop_now, "violin_notes", 0.14):
            violin_json = collect_violin_note_data()
            if violin_json:
                _set_tick_payload("violin_notes", violin_json, loop_now)
        if _run_tick_budget_exceeded(collector_start):
            raise _TickCollectorBudgetStop()

        if get_hook_control_flag("need_wuchang_umbrella") and _tick_due(loop_now, "wuchang_umbrella", 0.14):
            umbrella_json = collect_wuchang_umbrella_data()
            if umbrella_json:
                _set_tick_payload("wuchang_umbrella", umbrella_json, loop_now)
        if _run_tick_budget_exceeded(collector_start):
            raise _TickCollectorBudgetStop()

        if get_hook_control_flag("enable_auto_hook") and _hook_need_special_units_enabled() and _tick_due(loop_now, "mary_mirror", _get_dynamic_tick_interval("mary_mirror")):
            mary_mirror_json = collect_mary_mirror_data()
            if mary_mirror_json:
                _set_tick_payload("mary_mirror", mary_mirror_json, loop_now)
        if _run_tick_budget_exceeded(collector_start):
            raise _TickCollectorBudgetStop()

        if get_hook_control_flag("enable_auto_hook") and _hook_need_special_units_enabled() and _tick_due(loop_now, "special_units", _get_dynamic_tick_interval("special_units")):
            special_units_json = collect_special_units_data()
            if special_units_json:
                _set_tick_payload("special_units", special_units_json, loop_now)
        if _run_tick_budget_exceeded(collector_start):
            raise _TickCollectorBudgetStop()

        if get_hook_control_flag("enable_auto_hook") and get_hook_control_flag("need_special_unit_bones") and _tick_due(loop_now, "special_unit_bones", 0.22):
            special_unit_bones_json = collect_special_unit_bones_data()
            if special_unit_bones_json:
                _set_tick_payload("special_unit_bones", special_unit_bones_json, loop_now)
        if _run_tick_budget_exceeded(collector_start):
            raise _TickCollectorBudgetStop()

        if get_hook_control_flag("need_knight_predictions") and _tick_due(loop_now, "knight_predictions", 0.14):
            knight_json = collect_knight_prediction_data()
            if knight_json:
                _set_tick_payload("knight_predictions", knight_json, loop_now)
        if _run_tick_budget_exceeded(collector_start):
            raise _TickCollectorBudgetStop()

        if get_hook_control_flag("need_opera_hit_test") and _tick_due(loop_now, "opera_shadow_leap", 0.14):
            opera_leap_json = collect_opera_singer_leap_data()
            if opera_leap_json:
                _set_tick_payload("opera_shadow_leap", opera_leap_json, loop_now)
        if _run_tick_budget_exceeded(collector_start):
            raise _TickCollectorBudgetStop()

        panels_cycle_active = _incremental_collector_active("panels")
        if get_hook_control_flag("need_panels") and (panels_cycle_active or _tick_due(loop_now, "panels", _get_dynamic_tick_interval("panels"))):
            panel_json = _run_incremental_panel_collector(loop_now, not panels_cycle_active)
            if panel_json:
                _set_tick_payload("panels", panel_json, loop_now)
        if _run_tick_budget_exceeded(collector_start):
            raise _TickCollectorBudgetStop()

        if get_hook_control_flag("need_self_debuff") and _tick_due(loop_now, "self_debuff", _get_dynamic_tick_interval("self_debuff")):
            self_debuff_json = collect_self_debuff_data()
            if self_debuff_json:
                _set_tick_payload("self_debuff", self_debuff_json, loop_now)
        if _run_tick_budget_exceeded(collector_start):
            raise _TickCollectorBudgetStop()

        qte_tick_interval = 0.03 if get_hook_control_flag("need_qte_state_fast") else 0.25
        if get_hook_control_flag("need_qte_state") and _tick_due(loop_now, "qte_state", qte_tick_interval):
            qte_state_json = collect_qte_state_data()
            if qte_state_json:
                _set_tick_payload("qte_state", qte_state_json, loop_now)
        if _run_tick_budget_exceeded(collector_start):
            raise _TickCollectorBudgetStop()

        all_unit_buffs_cycle_active = _incremental_collector_active("all_unit_buffs")
        if get_hook_control_flag("need_all_unit_buffs") and (all_unit_buffs_cycle_active or _tick_due(loop_now, "all_unit_buffs", 0.36)):
            all_unit_buffs_json = _run_incremental_all_unit_buffs_collector(loop_now, not all_unit_buffs_cycle_active)
            if all_unit_buffs_json:
                _set_tick_payload("all_unit_buffs", all_unit_buffs_json, loop_now)
        if _run_tick_budget_exceeded(collector_start):
            raise _TickCollectorBudgetStop()

        if get_hook_control_flag("need_copycat_meeting") and _tick_due(loop_now, "copycat_meeting", 0.28):
            copycat_meeting_json = collect_copycat_meeting_data()
            if copycat_meeting_json:
                _set_tick_payload("copycat_meeting", copycat_meeting_json, loop_now)
    except _TickCollectorBudgetStop:
        pass
    except:
        pass

    if get_hook_control_flag("need_info") and _incremental_collector_active("info"):
        try:
            info_list = _run_incremental_info_collector(loop_now, None, False)
            if info_list:
                _set_tick_payload("info", '\n'.join(info_list), loop_now)
        except:
            pass
        if _run_tick_budget_exceeded(collector_start):
            return

    if not is_goldrush_tick:
        try:
            _run_tick_misc_collectors(loop_now, time.time())
        except:
            pass

    try:
        if _tick_due(loop_now, "payload_flush", RUN_TICK_PAYLOAD_FLUSH_INTERVAL_SEC):
            _flush_tick_payloads(loop_now)
    except:
        pass

def _is_goldrush_local_player_instance(player):
    try:
        if not player or not hasattr(GK, 'g_unit') or not GK.g_unit:
            return False
        local_uid = str(getattr(GK.g_unit, 'uid', '') or '')
        player_uid = str(getattr(player, 'uid', '') or '')
        if not local_uid or not player_uid or local_uid != player_uid:
            return False
        map_info = get_current_map_info() or {}
        return bool(map_info.get("is_goldrush"))
    except:
        return False

def install_unitmanager_tick_hook():
    try:
        current_tick = getattr(UnitManager, 'tick', None)
        if current_tick is None:
            return False
        if getattr(current_tick, '__solo_tick_hook_installed__', False):
            return True

        @wraps(current_tick)
        def wrapper(self, *args, **kwargs):
            try:
                map_info = get_current_map_info() or {}
                if not map_info.get("is_goldrush"):
                    run_tick_collectors()
            except:
                pass
            return current_tick(self, *args, **kwargs)

        wrapper.__solo_tick_hook_installed__ = True
        UnitManager.tick = wrapper
        return True
    except:
        return False

def install_goldrush_player_late_tick_hook():
    try:
        target_class = None
        try:
            from common_cs.combat_core.entities.units_goldrush.GoldRushPlayerUnit import GoldRushPlayerUnit
            target_class = GoldRushPlayerUnit
        except:
            if hasattr(GK, 'g_unit') and GK.g_unit:
                target_class = getattr(GK.g_unit, '__class__', None)
        if target_class is None:
            return False

        current_tick = getattr(target_class, 'on_controller_late_tick', None)
        if current_tick is None:
            return False
        if getattr(current_tick, '__solo_goldrush_player_late_tick_installed__', False):
            return True

        @wraps(current_tick)
        def wrapper(self, *args, **kwargs):
            try:
                if _is_goldrush_local_player_instance(self):
                    run_tick_collectors()
            except:
                pass
            return current_tick(self, *args, **kwargs)

        wrapper.__solo_goldrush_player_late_tick_installed__ = True
        target_class.on_controller_late_tick = wrapper
        return True
    except:
        return False

def _send_cached_payload(sock, addr, cache_name, last_sent_times):
    payload, updated_at = _get_tick_payload(cache_name)
    if not payload or updated_at <= float(last_sent_times.get(cache_name, 0.0) or 0.0):
        return False
    try:
        encoded_payload = payload.encode('utf-8')
        if len(encoded_payload) > 60000 and cache_name == "goldrush_scene_snapshot":
            fallback_payload = json.dumps({
                "type": "goldrush_scene_snapshot",
                "valid": False,
                "error": "payload_too_large",
                "payload_bytes": len(encoded_payload)
            }, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode('utf-8')
            sock.sendto(fallback_payload, addr)
        else:
            sock.sendto(encoded_payload, addr)
        last_sent_times[cache_name] = updated_at
        return True
    except BlockingIOError:
        return False
    except:
        return False

try:
    tick_hook_ok = install_unitmanager_tick_hook()
    goldrush_tick_hook_ok = install_goldrush_player_late_tick_hook()
    if goldrush_tick_hook_ok:
        try:
            _ensure_hook_runtime_io()["goldrush_hook_installed"] = True
        except:
            pass
except Exception:
    pass
