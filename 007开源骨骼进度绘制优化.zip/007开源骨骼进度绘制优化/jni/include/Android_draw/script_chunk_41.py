:"):
            player_count_index = idx
            break
    if player_count_index < 0:
        return results + list(player_lines)
    insert_index = len(results)
    for idx in range(player_count_index + 1, len(results)):
        if results[idx] == "-" * 20:
            insert_index = idx
            break
    return results[:insert_index] + list(player_lines) + results[insert_index:]

def _run_incremental_info_collector(loop_now=None, readiness=None, start_new=False):
    state = INCREMENTAL_COLLECTOR_STATE.get("info", {})
    if start_new or not state.get("active"):
        base_results = collect_info(False, readiness)
        map_info = None
        try:
            map_info = get_current_map_info() or {}
        except:
            map_info = {}
        try:
            unit_mgr = get_available_unit_mgr()
            players = safe_get_units_from_mgr(unit_mgr, 'get_player_units') or []
        except:
            players = []
        state["active"] = True
        state["players"] = players
        state["index"] = 0
        state["base_results"] = list(base_results or [])
        state["player_lines"] = []
        state["is_goldrush"] = bool((map_info or {}).get('is_goldrush'))
    players = state.get("players", []) or []
    index = int(state.get("index", 0) or 0)
    end_index = min(len(players), index + INCREMENTAL_INFO_PLAYER_CHUNK_SIZE)
    for current_index in range(index, end_index):
        try:
            state["player_lines"].extend(_build_info_player_detail_lines(players[current_index], bool(state.get("is_goldrush"))))
        except:
            pass
    state["index"] = end_index
    if end_index >= len(players):
        results = _merge_info_base_with_player_lines(state.get("base_results", []), state.get("player_lines", []))
        _reset_incremental_collector("info")
        return results
    return None

def collect_info(include_player_details=True, readiness=None):
    results = []
    results.append(f"