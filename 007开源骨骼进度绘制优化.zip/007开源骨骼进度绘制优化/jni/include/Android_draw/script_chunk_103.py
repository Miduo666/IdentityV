"
            else:
                room_label = room_type_name
            points.append({
                "uid": _extract_entity_identity(room),
                "class_name": type(room).__name__,
                "room_id": _safe_int(getattr(room, 'room_id', -1), -1),
                "config_id": config_id,
                "room_index": room_index,
                "room_type": room_type,
                "room_type_name": room_type_name,
                "room_label": room_label,
                "room_map_path": _safe_uid_text(room_cfg.get('room_map_path', '')),
                "cannot_teleport": bool(getattr(room, 'cannot_teleport', room_cfg.get('cannot_teleport', False))),
                "pos": pos,
                "voxel_count": len(_iter_values(getattr(room, 'voxels', None))),
                "path_count": len(_iter_values(getattr(room, 'paths', None))),
                "outline_segment_count": len(outline_segments),
                "world_outline_segment_count": len(world_outline_segments),
                "world_path_segment_count": len(world_path_segments),
                "doorway_world_segment_count": len(doorway_world_segments),
                "voxel_points": voxel_points,
                "path_points": path_points,
                "path_wall_infos": wall_infos,
                "voxel_bounds": _build_room_voxel_bounds(voxel_points),
                "outline_segments": outline_segments,
                "world_outline_segments": world_outline_segments,
                "world_path_segments": world_path_segments,
                "doorway_world_segments": doorway_world_segments,
                "group_names": group_names[:12],
                "model_names": model_names[:12],
                "room_tags": room_tags,
                "is_side_door_room": is_side_door_room,
                "is_safe_room": is_safe_room,
                "is_piano_room": is_piano_room,
                "has_treasure_group": has_treasure_group,
                "has_core_lock_group": has_core_lock_group,
                "has_harp_group": has_harp_group
            })
        except:
            pass
    points.sort(key=lambda item: (item.get("room_type", -1), item.get("room_index", -1), item.get("uid", "")))
    return points

def _make_goldrush_segment_key(segment):
    if not isinstance(segment, dict):
        return None
    start_key = _make_world_point_key(segment.get("from", []))
    end_key = _make_world_point_key(segment.get("to", []))
    if start_key is None or end_key is None or start_key == end_key:
        return None
    floor_value = _safe_int(segment.get('floor', 0), 0)
    return (floor_value, start_key, end_key) if start_key <= end_key else (floor_value, end_key, start_key)

def _merge_goldrush_world_segments(room_entries, field_name, limit=4096):
    merged = []
    seen = set()
    for room_entry in room_entries or []:
        for segment in room_entry.get(field_name, []) or []:
            try:
                key = _make_goldrush_segment_key(segment)
                if key is None or key in seen:
                    continue
                seen.add(key)
                merged.append({
                    "from": list(key[1]),
                    "to": list(key[2]),
                    "floor": key[0],
                    "room_index": _safe_int(room_entry.get("room_index", -1), -1)
                })
                if len(merged) >= limit:
                    return merged
            except:
                pass
    return merged

def _build_goldrush_full_map_bounds(room_entries):
    voxel_min = None
    voxel_max = None
    world_min = None
    world_max = None
    for room_entry in room_entries or []:
        voxel_bounds = room_entry.get("voxel_bounds", {}) or {}
        voxel_min_point = voxel_bounds.get("min", None)
        voxel_max_point = voxel_bounds.get("max", None)
        if isinstance(voxel_min_point, (list, tuple)) and len(voxel_min_point) >= 3:
            current_min = [int(voxel_min_point[0]), int(voxel_min_point[1]), int(voxel_min_point[2])]
            voxel_min = current_min if voxel_min is None else [
                min(voxel_min[0], current_min[0]),
                min(voxel_min[1], current_min[1]),
                min(voxel_min[2], current_min[2])
            ]
        if isinstance(voxel_max_point, (list, tuple)) and len(voxel_max_point) >= 3:
            current_max = [int(voxel_max_point[0]), int(voxel_max_point[1]), int(voxel_max_point[2])]
            voxel_max = current_max if voxel_max is None else [
                max(voxel_max[0], current_max[0]),
                max(voxel_max[1], current_max[1]),
                max(voxel_max[2], current_max[2])
            ]
    if voxel_min is not None and voxel_max is not None:
        world_min = _goldrush_voxel_point_to_world(voxel_min, 'base')
        world_max = _goldrush_voxel_point_to_world([voxel_max[0] + 1, voxel_max[1] + 1, voxel_max[2] + 1], 'base')
    return {
        "voxel_min": voxel_min or [],
        "voxel_max": voxel_max or [],
        "world_min": world_min or [],
        "world_max": world_max or []
    }

def _build_goldrush_scene_geometry_refs(scene_id):
    def _pick_scene_cfg(cfg_id, label):
        cfg = _get_dm_row('goldrush_outdoor_scn_configs', cfg_id)
        if not cfg:
            return {}
        return {
            "label": label,
            "id": _safe_int(cfg.get("id", cfg_id), _safe_int(cfg_id, -1)),
            "scene_id": _safe_int(cfg.get("scene_id", -1), -1),
            "scn_path": _safe_uid_text(cfg.get("scn_path", "")),
            "ui_map_path": _safe_uid_text(cfg.get("ui_map_path", "")),
            "ui_map_scale": _safe_float(cfg.get("ui_map_scale", 0.0), 0.0),
            "ui_map_offset": _safe_uid_text(cfg.get("ui_map_offset", "")),
            "ui_map_border": _safe_uid_text(cfg.get("ui_map_border", "")),
            "door_tid": _safe_uid_text(cfg.get("door_tid", "")),
            "annotation": _safe_uid_text(cfg.get("annotation", ""))
        }
    return {
        "scene_id": _safe_int(scene_id, -1),
        "scene_reference": dict(GOLDRUSH_SCENE_REFERENCE),
        "outdoor_scene": _pick_scene_cfg(GOLDRUSH_SCENE_REFERENCE.get("outdoor_id", -1), "outdoor"),
        "camp_scene": _pick_scene_cfg(GOLDRUSH_SCENE_REFERENCE.get("camp_id", -1), "camp")
    }

def _collect_goldrush_full_map_model_refs(payload, limit=256):
    refs = []
    seen = set()

    def append_ref(ref_type, ref_value, **extra):
        ref_value = _safe_uid_text(ref_value)
        if not ref_value:
            return
        key = (ref_type, ref_value, tuple(sorted((k, _safe_uid_text(v) if not isinstance(v, (int, float, bool)) else v) for k, v in extra.items())))
        if key in seen:
            return
        seen.add(key)
        entry = {"type": ref_type, "value": ref_value}
        for field_name, field_value in extra.items():
            if isinstance(field_value, (int, float, bool)) or field_value is None:
                entry[field_name] = field_value
            else:
                entry[field_name] = _safe_uid_text(field_value)
        refs.append(entry)

    scene_refs = _build_goldrush_scene_geometry_refs(payload.get("scene_id", -1))
    for scene_key in ("outdoor_scene", "camp_scene"):
        scene_cfg = scene_refs.get(scene_key, {}) or {}
        append_ref("scene_path", scene_cfg.get("scn_path", ""), scene=scene_key)
        append_ref("ui_map_path", scene_cfg.get("ui_map_path", ""), scene=scene_key)

    for room_entry in payload.get("maze_rooms", []) or []:
        room_index = _safe_int(room_entry.get("room_index", -1), -1)
        append_ref("room_map_path", room_entry.get("room_map_path", ""), room_index=room_index, config_id=_safe_int(room_entry.get("config_id", -1), -1))
        for group_name in room_entry.get("group_names", []) or []:
            append_ref("room_group", group_name, room_index=room_index)
        for model_name in room_entry.get("model_names", []) or []:
            append_ref("room_model", model_name, room_index=room_index)
        for wall_info in room_entry.get("path_wall_infos", []) or []:
            append_ref("doorway_model", wall_info.get("model_name", ""), room_index=room_index, doorway_cfg_id=_safe_int(wall_info.get("doorway_cfg_id", -1), -1))

    for door_entry in payload.get("doors", []) or []:
        append_ref("door_model_path", door_entry.get("model_path", ""), room_index=_safe_int(door_entry.get("room_index", -1), -1), door_id=_safe_int(door_entry.get("door_id", -1), -1))
    for entry in payload.get("interactive_entities", []) or []:
        append_ref("interactive_model_path", entry.get("model_path", ""), template_id=_safe_int(entry.get("template_id", -1), -1), room_index=_safe_int(entry.get("room_index", -1), -1))
    for entry in payload.get("reward_boxes", []) or []:
        append_ref("reward_box_model_path", entry.get("config_model_path", ""), box_id=_safe_int(entry.get("box_id", -1), -1))
    for entry in payload.get("basecamp_points", []) or []:
        append_ref("basecamp_model_name", entry.get("model_name", ""), class_name=entry.get("class_name", ""))

    return refs[:limit]

def _get_goldrush_world_floor(world_pos):
    if not isinstance(world_pos, (list, tuple)) or len(world_pos) < 3:
        return 0
    return _safe_int(round(_safe_float(world_pos[1], 0.0) / GOLDRUSH_VOXEL_SIZE_Y), 0)

def _get_goldrush_room_floor_list(room_entry):
    voxel_bounds = room_entry.get("voxel_bounds", {}) or {}
    min_point = voxel_bounds.get("min", None)
    max_point = voxel_bounds.get("max", None)
    if not isinstance(min_point, (list, tuple)) or len(min_point) < 3:
        return []
    if not isinstance(max_point, (list, tuple)) or len(max_point) < 3:
        return []
    start_floor = _safe_int(min_point[1], 0)
    end_floor = _safe_int(max_point[1], start_floor)
    floor_list = []
    for floor_value in range(start_floor, end_floor + 1):
        floor_list.append(floor_value)
        if len(floor_list) >= 8:
            break
    return floor_list

def _get_world_segment_heading_info(segment):
    start_point = list((segment or {}).get("from", [0.0, 0.0, 0.0]))
    end_point = list((segment or {}).get("to", [0.0, 0.0, 0.0]))
    diff_x = round(_safe_float(end_point[0], 0.0) - _safe_float(start_point[0], 0.0), 2)
    diff_z = round(_safe_float(end_point[2], 0.0) - _safe_float(start_point[2], 0.0), 2)
    if abs(diff_x) >= abs(diff_z):
        line_axis = "X"
        line_label = "