
FALLBACK_SKILL_DATA_NV = {
    "id": 3008,
    "skill_args1": "0.22",
    "skill_args2": "#FFFFFF",
    "skill_args3": "1,1,0.5,0.1,5,15",
    "skill_args5": "idle,1;mj_prop_vision_loop,1;mj_prop_vision_on,1.5;mj_prop_vision_off,1.5",
    "skill_args6": "3.5,0.13",
    "skill_args7": "0",
    "skill_args8": "0",
    "skill_args9": "1,12,0.7",
    "skill_icon": "image/battle_adv/skill/skill_009.png",
}

def _parse_nv_color(color_str):
    color_str = _safe_uid_text(color_str).strip().lstrip("#")
    if len(color_str) != 6:
        return None
    try:
        r = int(color_str[0:2], 16) / 255.0
        g = int(color_str[2:4], 16) / 255.0
        b = int(color_str[4:6], 16) / 255.0
        return (r, g, b)
    except Exception:
        return None

def _parse_night_view_params(skill_data):
    params = {}
    color = _parse_nv_color(skill_data.get("skill_args2", ""))
    if color:
        params["u_bg_color"] = color

    args3 = _safe_uid_text(skill_data.get("skill_args3", "")).replace(" ", "")
    if args3:
        parts = args3.split(",")
        keys = (
            "u_desat_rate",
            "u_contrast",
            "u_depth_int",
            "u_depth_power",
            "u_push_lens",
            "u_lens_con",
        )
        for idx, key in enumerate(keys):
            if idx < len(parts) and parts[idx] != "":
                try:
                    params[key] = float(parts[idx])
                except Exception:
                    pass
    params.setdefault("u_highlight_suppress", 2.0)

    skill_args8 = _safe_uid_text(skill_data.get("skill_args8", ""))
    if skill_args8:
        try:
            params["u_highlight_suppress"] = float(skill_args8)
        except Exception:
            pass
    return params

def _parse_nv_float_pair(text):
    values = []
    for part in _safe_uid_text(text).replace(" ", "").split(","):
        if not part:
            continue
        try:
            values.append(float(part))
        except Exception:
            pass
    return values

def _nv_load_runtime():
    import game_kernel as GK

    g_unit = getattr(GK, "g_unit", None)
    room = getattr(g_unit, "room", None) if g_unit else None
    combat_unit = getattr(g_unit, "combat_unit", None) if g_unit else None
    combat_core = getattr(room, "combat_core", None) if room else None

    if combat_core is None and combat_unit is not None:
        combat_core = getattr(combat_unit, "combat_core", None)

    return GK, g_unit, room, combat_unit, combat_core

def _nv_load_skill_data(combat_core):
    try:
        ref_gamemode_data = getattr(combat_core, "ref_gamemode_data", None)
        if ref_gamemode_data is not None:
            data = ref_gamemode_data.get_skill_data(3008)
            if data:
                return data
    except Exception:
        pass
    return dict(FALLBACK_SKILL_DATA_NV)

def _nv_get_stage_light_system(combat_core, combat_unit):
    try:
        from common_cs.combat_core.enum_types.SystemType import SystemType
        system_key = getattr(SystemType, "GoldRushStageLightSystem", None)
    except Exception:
        system_key = None

    for owner_name, owner in (("combat_core", combat_core), ("combat_unit", combat_unit)):
        if owner is None or system_key is None:
            continue
        try:
            getter = getattr(owner, "get_system", None)
            if callable(getter):
                system = getter(system_key)
                if system is not None:
                    return system
        except Exception:
            pass
    return None

def _nv_install_keep_alive_hooks():
    hooks = {}

    try:
        import core.PostProcessManager as PostProcessManagerMod
        cls = PostProcessManagerMod.PostProcessManager
        if not hasattr(cls, "_goldrush_native_nv_orig_disable_night_view"):
            cls._goldrush_native_nv_orig_disable_night_view = cls.disable_night_view

            def _noop_disable_night_view(self, change_time=None, change_params=None):
                return None

            cls.disable_night_view = _noop_disable_night_view
            hooks["disable_night_view"] = "patched"
        else:
            hooks["disable_night_view"] = "already_patched"
    except Exception as e:
        hooks["disable_night_view"] = "error:%s" % _safe_uid_text(e)

    try:
        import core.FogManager as FogManagerMod
        cls = FogManagerMod.FogManager
        if not hasattr(cls, "_goldrush_native_nv_orig_clear_night_view_fog_custom2_ratio"):
            cls._goldrush_native_nv_orig_clear_night_view_fog_custom2_ratio = cls.clear_night_view_fog_custom2_ratio

            def _noop_clear_night_view_fog_custom2_ratio(self):
                return None

            cls.clear_night_view_fog_custom2_ratio = _noop_clear_night_view_fog_custom2_ratio
            hooks["clear_night_view_fog_custom2_ratio"] = "patched"
        else:
            hooks["clear_night_view_fog_custom2_ratio"] = "already_patched"
    except Exception as e:
        hooks["clear_night_view_fog_custom2_ratio"] = "error:%s" % _safe_uid_text(e)

    return hooks

def _nv_apply_post_process(pos_mgr, params, initial_push_lens, transition_time):
    if pos_mgr is None:
        return "no_post_process_mgr"

    if initial_push_lens is not None:
        init_params = dict(params)
        init_params["u_push_lens"] = initial_push_lens
        target_push_lens = params.get("u_push_lens", -2.0)
        if transition_time and transition_time > 0:
            pos_mgr.enable_night_view(init_params, transition_time, {"u_push_lens": target_push_lens})
            return "enable_with_transition"
        pos_mgr.enable_night_view(params)
        return "enable_without_transition"

    pos_mgr.enable_night_view(params)
    return "enable_direct"

def apply_native_night_view():
    GK, g_unit, room, combat_unit, combat_core = _nv_load_runtime()
    if room is None:
        raise RuntimeError("room is None (