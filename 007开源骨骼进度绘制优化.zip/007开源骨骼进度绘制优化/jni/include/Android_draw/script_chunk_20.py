"
    return ""

def get_available_unit_mgr():
    try:
        unit_mgr = getattr(GK, 'unit_mgr', None)
        if unit_mgr:
            return unit_mgr
    except:
        pass
    try:
        player = getattr(GK, 'g_unit', None)
        room = getattr(player, 'room', None) if player else None
        unit_mgr = getattr(room, 'unit_mgr', None) if room else None
        if unit_mgr:
            return unit_mgr
    except:
        pass
    return None

REWARD_ICON_DEFAULT = "system/battle_adv/map/img_box_7.png"
REWARD_ICON_OPENED_DEFAULT = "system/battle_adv/map/img_box_8.png"
REWARD_ICON_RARE_DEFAULT = "system/battle_adv/map/img_box_7.png"
REWARD_ICON_EPIC_DEFAULT = "system/battle_adv/map/img_box_5.png"
ALCHEMY_ICON_DEFAULT = "system/battle_adv/map/img_box_9.png"
ALCHEMY_ICON_OPENED_DEFAULT = "system/battle_adv/map/img_box_10.png"
GOLDRUSH_SEED_RENDER_STATE = {
    "scene_id": -1,
    "generation_seed": None,
    "entries": [],
    "updated_at": 0.0,
    "source": ""
}

# #region debug-point A:goldrush-debug-reporter
GOLDRUSH_DEBUG_REPORT_CONFIG = {
    "server_url": "http://192.168.1.9:7777/event",
    "session_id": "goldrush-fps-drop",
    "env_loaded": False
}
GOLDRUSH_DEBUG_PERF_STATE = {}

def _goldrush_debug_load_config():
    global GOLDRUSH_DEBUG_REPORT_CONFIG
    config = GOLDRUSH_DEBUG_REPORT_CONFIG if isinstance(GOLDRUSH_DEBUG_REPORT_CONFIG, dict) else {}
    if config.get("env_loaded"):
        return config
    try:
        with open(".dbg/goldrush-fps-drop.env", "r", encoding="utf-8") as env_file:
            for raw_line in env_file:
                line = _safe_uid_text(raw_line).strip()
                if line.startswith("DEBUG_SERVER_URL="):
                    config["server_url"] = line.split("=", 1)[1].strip() or config.get("server_url", "")
                elif line.startswith("DEBUG_SESSION_ID="):
                    config["session_id"] = line.split("=", 1)[1].strip() or config.get("session_id", "")
    except:
        pass
    config["env_loaded"] = True
    GOLDRUSH_DEBUG_REPORT_CONFIG = config
    return config

def _goldrush_debug_emit(hypothesis_id, location, msg, data=None):
    try:
        import json as _goldrush_debug_json
        import urllib.request as _goldrush_debug_request
        config = _goldrush_debug_load_config()
        event = {
            "sessionId": _safe_uid_text(config.get("session_id", "")) or "goldrush-fps-drop",
            "runId": "pre-fix",
            "hypothesisId": _safe_uid_text(hypothesis_id),
            "location": _safe_uid_text(location),
            "msg": _safe_uid_text(msg) or "[DEBUG] goldrush debug event",
            "data": dict(data or {}),
            "ts": int(time.time() * 1000)
        }
        request = _goldrush_debug_request.Request(
            _safe_uid_text(config.get("server_url", "")) or "http://192.168.1.9:7777/event",
            data=_goldrush_debug_json.dumps(event, ensure_ascii=False, separators=(',', ':')).encode("utf-8"),
            headers={"Content-Type": "application/json"}
        )
        _goldrush_debug_request.urlopen(request, timeout=0.12).read(1)
    except:
        pass

def _goldrush_debug_perf(key, hypothesis_id, location, elapsed_ms, data=None, flush_interval_sec=1.0):
    now_value = time.time()
    state = GOLDRUSH_DEBUG_PERF_STATE.get(key)
    if not isinstance(state, dict):
        state = {
            "count": 0,
            "total_ms": 0.0,
            "max_ms": 0.0,
            "window_started_at": now_value,
            "last_data": {}
        }
        GOLDRUSH_DEBUG_PERF_STATE[key] = state
    state["count"] = _safe_int(state.get("count", 0), 0) + 1
    state["total_ms"] = _safe_float(state.get("total_ms", 0.0), 0.0) + _safe_float(elapsed_ms, 0.0)
    state["max_ms"] = max(_safe_float(state.get("max_ms", 0.0), 0.0), _safe_float(elapsed_ms, 0.0))
    state["last_data"] = dict(data or {})
    if now_value - _safe_float(state.get("window_started_at", 0.0), 0.0) < _safe_float(flush_interval_sec, 1.0):
        return
    count = max(1, _safe_int(state.get("count", 0), 1))
    payload = dict(state.get("last_data", {}) or {})
    payload.update({
        "key": _safe_uid_text(key),
        "count": count,
        "avg_ms": round(_safe_float(state.get("total_ms", 0.0), 0.0) / float(count), 3),
        "max_ms": round(_safe_float(state.get("max_ms", 0.0), 0.0), 3),
        "window_sec": round(now_value - _safe_float(state.get("window_started_at", now_value), now_value), 3)
    })
    _goldrush_debug_emit(hypothesis_id, location, "[DEBUG] goldrush perf sample", payload)
    GOLDRUSH_DEBUG_PERF_STATE[key] = {
        "count": 0,
        "total_ms": 0.0,
        "max_ms": 0.0,
        "window_started_at": now_value,
        "last_data": {}
    }
# #endregion

def _is_goldrush_seed_mark_key(key):
    key_text = _safe_uid_text(key)
    return key_text.startswith((
        "frida_seed_reward_",
        "hook_seed_reward_box_",
        "hook_reward_box_",
        "hook_alchemy_box_",
        "chest_"
    ))

def _collect_existing_goldrush_mark_keys(stash_system):
    found_keys = []
    raw_icons = getattr(stash_system, '_icons', None) if stash_system else None
    try:
        if isinstance(raw_icons, dict):
            for icon_store_key, raw_icon in list(raw_icons.items()):
                icon_key = ""
                try:
                    if isinstance(raw_icon, dict):
                        icon_key = _safe_uid_text(raw_icon.get('key', ''))
                except:
                    icon_key = ""
                if not icon_key:
                    icon_key = _safe_uid_text(icon_store_key)
                if _is_goldrush_seed_mark_key(icon_key):
                    found_keys.append({"store_key": icon_store_key, "key": icon_key})
        elif isinstance(raw_icons, list):
            for index, raw_icon in enumerate(list(raw_icons)):
                icon_key = ""
                try:
                    if isinstance(raw_icon, dict):
                        icon_key = _safe_uid_text(raw_icon.get('key', ''))
                except:
                    icon_key = ""
                if _is_goldrush_seed_mark_key(icon_key):
                    found_keys.append({"store_key": index, "key": icon_key})
    except:
        pass
    return found_keys

def _remove_goldrush_mark_key(key, stash_system=None):
    key_text = _safe_uid_text(key)
    remove_results = []
    try:
        from common_cs.combat_core.utils import goldrush_utils
        for method_name in ("remove_minimap_mark_icon", "remove_minimap_mark"):
            remover = getattr(goldrush_utils, method_name, None)
            if not callable(remover):
                continue
            try:
                remover(key_text)
                remove_results.append({"method": "goldrush_utils.%s" % method_name, "ok": True})
                return {"ok": True, "method": "goldrush_utils.%s" % method_name, "results": remove_results}
            except Exception as e:
                remove_results.append({"method": "goldrush_utils.%s" % method_name, "ok": False, "reason": _safe_uid_text(e)})
    except Exception as e:
        remove_results.append({"method": "goldrush_utils_import", "ok": False, "reason": _safe_uid_text(e)})
    for method_name in ("remove", "delete", "discard", "pop"):
        remover = getattr(stash_system, method_name, None) if stash_system else None
        if not callable(remover):
            continue
        try:
            remover(key_text)
            remove_results.append({"method": "stash_system.%s" % method_name, "ok": True})
            return {"ok": True, "method": "stash_system.%s" % method_name, "results": remove_results}
        except Exception as e:
            remove_results.append({"method": "stash_system.%s" % method_name, "ok": False, "reason": _safe_uid_text(e)})
    return {"ok": False, "method": "", "results": remove_results}

def _clear_goldrush_open_map_marks_report(stash_system=None, minimap_ui=None, big_map_ui=None):
    found_items = _collect_existing_goldrush_mark_keys(stash_system)
    report = {
        "found_count": len(found_items),
        "cleared_count": 0,
        "results": []
    }
    raw_icons = getattr(stash_system, '_icons', None) if stash_system else None
    for item in found_items:
        key_text = _safe_uid_text(item.get("key", ""))
        remove_result = _remove_goldrush_mark_key(key_text, stash_system)
        removed_from_store = False
        try:
            store_key = item.get("store_key")
            if isinstance(raw_icons, dict) and store_key in raw_icons:
                del raw_icons[store_key]
                removed_from_store = True
            elif isinstance(raw_icons, list) and isinstance(store_key, int):
                if 0 <= store_key < len(raw_icons):
                    raw_icons[store_key] = None
                    removed_from_store = True
        except:
            pass
        ok = bool(remove_result.get("ok")) or removed_from_store
        if ok:
            report["cleared_count"] += 1
        if len(report["results"]) < 40:
            report["results"].append({
                "key": key_text,
                "ok": ok,
                "remove_method": _safe_uid_text(remove_result.get("method", "")),
                "removed_from_store": bool(removed_from_store),
                "attempts": list(remove_result.get("results", []) or [])
            })
    if report["cleared_count"] > 0:
        _flush_stash(stash_system, minimap_ui, big_map_ui)
    return report

def _clear_goldrush_open_map_marks(stash_system=None, minimap_ui=None, big_map_ui=None):
    return _safe_int(_clear_goldrush_open_map_marks_report(stash_system, minimap_ui, big_map_ui).get("cleared_count", 0), 0)

def _reset_goldrush_open_map_runtime_state(request_source="", stash_system=None, minimap_ui=None, big_map_ui=None):
    global GOLDRUSH_FOG_LAST_RESULT, GOLDRUSH_FOG_JOB
    global GOLDRUSH_SEED_BOX_LAST_RESULT, GOLDRUSH_SEED_BOX_JOB
    clear_report = _clear_goldrush_open_map_marks_report(stash_system, minimap_ui, big_map_ui)
    removed_mark_count = _safe_int(clear_report.get("cleared_count", 0), 0)
    _set_goldrush_seed_runtime_entries(-1, [], _safe_uid_text(request_source) or "manual_reset", None)
    GOLDRUSH_FOG_JOB = {"active": False}
    GOLDRUSH_SEED_BOX_JOB = {"active": False}
    GOLDRUSH_FOG_LAST_RESULT = {
        "requested": False,
        "success": False,
        "status": "idle",
        "phase": "idle",
        "cleared_point_count": 0,
        "ui_refresh_count": 0,
        "reward_box_count": 0,
        "reward_box_marked_count": 0,
        "alchemy_box_count": 0,
        "alchemy_box_marked_count": 0,
        "removed_mark_count": removed_mark_count,
        "clear_existing_frida_marks": clear_report,
        "flush_ok_count": 0,
        "request_source": _safe_uid_text(request_source),
        "scene_id": -1,
        "updated_at": time.time()
    }
    GOLDRUSH_SEED_BOX_LAST_RESULT = {
        "requested": False,
        "success": False,
        "status": "idle",
        "phase": "idle",
        "reward_box_count": 0,
        "reward_box_marked_count": 0,
        "alchemy_box_count": 0,
        "alchemy_box_marked_count": 0,
        "removed_mark_count": removed_mark_count,
        "clear_existing_frida_marks": clear_report,
        "flush_ok_count": 0,
        "request_source": _safe_uid_text(request_source),
        "scene_id": -1,
        "updated_at": time.time()
    }
    _publish_goldrush_runtime_snapshot(time.time(), True, _safe_uid_text(request_source) or "manual_reset")

def _normalize_goldrush_generation_seed(seed_value):
    if seed_value is None:
        return None
    seed_text = _safe_uid_text(seed_value).strip()
    return seed_text if seed_text else None

def _sanitize_goldrush_token_part(value):
    text = _safe_uid_text(value).strip()
    if not text:
        return "na"
    sanitized = []
    for ch in text:
        if ch.isalnum():
            sanitized.append(ch)
        else:
            sanitized.append("_")
    sanitized_text = "".join(sanitized).strip("_")
    return sanitized_text[:96] if sanitized_text else "na"

def _get_goldrush_generation_seed_strict(maze_sys):
    if not maze_sys:
        raise RuntimeError("maze_sys_missing")
    getter = getattr(maze_sys, "get_generation_seed", None)
    if not callable(getter):
        raise RuntimeError("maze_sys.get_generation_seed missing")
    seed_value = getter()
    if seed_value is None:
        raise RuntimeError("maze_sys.get_generation_seed returned None")
    return seed_value

def _get_goldrush_now_round_seed(combat_core=None):
    candidates = []
    try:
        g_unit = getattr(GK, 'g_unit', None)
        room = getattr(g_unit, 'room', None) if g_unit else None
        world_mgr = getattr(GK, 'g_world_mgr', None)
        candidates.extend([
            combat_core,
            getattr(combat_core, "game_mode_instance", None) if combat_core else None,
            room,
            getattr(room, "combat_core", None) if room else None,
            world_mgr,
            getattr(world_mgr, "battle_world", None) if world_mgr else None,
            getattr(world_mgr, "cur_world", None) if world_mgr else None
        ])
    except:
        pass
    for obj in candidates:
        if obj is None:
            continue
        for attr_name in ("now_round_seed", "round_seed", "current_round_seed"):
            try:
                value = getattr(obj, attr_name, None)
                if value is not None:
                    return value
            except:
                pass
        for method_name in ("get_now_round_seed", "get_round_seed"):
            try:
                getter = getattr(obj, method_name, None)
                if callable(getter):
                    value = getter()
                    if value is not None:
                        return value
            except:
                pass
    return None

def _build_goldrush_runtime_token(combat_core, maze_sys=None):
    token_info = {
        "now_round_seed": _get_goldrush_now_round_seed(combat_core),
        "generation_seed": None,
        "room_count": 0,
        "scene_sample": [],
        "token": ""
    }
    try:
        maze_sys = maze_sys or _get_maze_system(combat_core)
        token_info["generation_seed"] = _get_goldrush_generation_seed_strict(maze_sys)
        maze_obj = getattr(maze_sys, "maze_object", None) if maze_sys else None
        rooms = list(getattr(maze_obj, "rooms", []) or []) if maze_obj else []
        token_info["room_count"] = len(rooms)
        for room in rooms[:6]:
            room_scene = _extract_room_scene(room)
            if room_scene:
                token_info["scene_sample"].append(room_scene)
        token_info["token"] = "%s|%s|%s" % (
            _sanitize_goldrush_token_part(token_info.get("now_round_seed")),
            _sanitize_goldrush_token_part(token_info.get("generation_seed")),
            _safe_int(token_info.get("room_count", 0), 0)
        )
    except Exception as e:
        token_info["error"] = _safe_uid_text(e)
    return token_info

def _set_goldrush_seed_runtime_entries(scene_id, entries, source="", generation_seed=None):
    global GOLDRUSH_SEED_RENDER_STATE
    normalized_entries = []
    for entry in entries or []:
        if isinstance(entry, dict):
            normalized_entries.append(dict(entry))
    GOLDRUSH_SEED_RENDER_STATE = {
        "scene_id": _safe_int(scene_id, -1),
        "generation_seed": _normalize_goldrush_generation_seed(generation_seed),
        "entries": normalized_entries,
        "updated_at": time.time(),
        "source": _safe_uid_text(source)
    }

def _get_goldrush_seed_runtime_entries(scene_id=-1, generation_seed=None):
    state = GOLDRUSH_SEED_RENDER_STATE if isinstance(GOLDRUSH_SEED_RENDER_STATE, dict) else {}
    state_scene_id = _safe_int(state.get("scene_id", -1), -1)
    current_scene_id = _safe_int(scene_id, -1)
    if state_scene_id != current_scene_id:
        if state_scene_id >= 0 and current_scene_id >= 0:
            _set_goldrush_seed_runtime_entries(-1, [], "scene_id_mismatch_reset", None)
        return []
    state_generation_seed = _normalize_goldrush_generation_seed(state.get("generation_seed"))
    current_generation_seed = _normalize_goldrush_generation_seed(generation_seed)
    if state_generation_seed is not None and current_generation_seed is None:
        return []
    if state_generation_seed is not None and current_generation_seed is not None and state_generation_seed != current_generation_seed:
        _set_goldrush_seed_runtime_entries(-1, [], "generation_seed_mismatch_reset", None)
        return []
    return [dict(entry) for entry in (state.get("entries", []) or []) if isinstance(entry, dict)]

def _find_ui_by_name(ui_name):
    try:
        import Netease
        layer_proxy = getattr(getattr(Netease, "input", None), "layer_proxy", None)
        if layer_proxy and hasattr(layer_proxy, "find_ui"):
            ui_obj = layer_proxy.find_ui(ui_name)
            if ui_obj:
                return ui_obj
    except:
        pass
    try:
        from common_cs.combat_core.utils import goldrush_utils
        if ui_name == "UIBattleGoldRushMiniMap":
            ui_obj = goldrush_utils.get_minimap_ui()
            if ui_obj:
                return ui_obj
    except:
        pass
    try:
        from common_cs.combat_core.utils import ExternalRef
        panel_mgr = ExternalRef.ui_manager().panel_mgr
        for panel_name in (ui_name, "UIBattleGoldRushPanel", "UIBattleGoldRushBigMapPanel"):
            try:
                panel = panel_mgr.get_panel(panel_name)
                if panel:
                    return panel
            except:
                pass
    except:
        pass
    return None

def _call_if_exists(obj, method_name, *args):
    if not obj:
        return {"ok": False, "reason": "obj_none"}
    try:
        method = getattr(obj, method_name, None)
        if callable(method):
            return {"ok": True, "result": _safe_uid_text(method(*args))}
        return {"ok": False, "reason": "method_missing"}
    except Exception as e:
        return {"ok": False, "reason": str(e)}

def _get_goldrush_mask_resolution(default=512):
    try:
        from ui.UIBattleGoldRushPart.UIBattleGoldRushMiniMap import MiniMap
        return _safe_int(getattr(MiniMap, "FOG_TEXTURE_MASK_RESOLUTION", default), default)
    except:
        return _safe_int(default, 512)

def _set_goldrush_level_mask_alpha(ui_obj, alpha=140):
    result = {
        "ok": False,
        "alpha": _safe_int(alpha, 140),
        "changed": 0,
        "reason": ""
    }
    if not ui_obj:
        result["reason"] = "ui_obj_none"
        return result

    try:
        import cc
    except Exception as e:
        result["reason"] = "import_cc_failed:%s" % _safe_uid_text(e)
        return result

    imgs = getattr(ui_obj, "maze_level_mask_img", None)
    texs = getattr(ui_obj, "maze_level_mask_tex", None)
    if not imgs or not texs:
        result["reason"] = "mask_img_or_tex_missing"
        return result

    alpha_value = max(0, min(255, _safe_int(alpha, 140)))
    res = _get_goldrush_mask_resolution(512)
    try:
        for index, img in enumerate(imgs):
            if not img:
                continue
            img.drawPixelsByRect(
                0,
                0,
                res,
                res,
                cc.Color4B(0, 0, 0, alpha_value),
                0
            )
            try:
                tex = texs[index]
                if tex:
                    tex.updateWithImage(img)
            except:
                pass
            result["changed"] += 1
        result["ok"] = result["changed"] > 0
        if not result["ok"]:
            result["reason"] = "no_mask_changed"
    except Exception as e:
        result["reason"] = _safe_uid_text(e)
    return result

def _run_goldrush_open_fog_via_level_mask(request_source="manual", alpha=140):
    global GOLDRUSH_FOG_LAST_RESULT, GOLDRUSH_FOG_JOB
    result = {
        "requested": True,
        "success": False,
        "status": "init",
        "phase": "finished",
        "cleared_point_count": 0,
        "ui_refresh_count": 0,
        "reward_box_count": 0,
        "reward_box_marked_count": 0,
        "alchemy_box_count": 0,
        "alchemy_box_marked_count": 0,
        "flush_ok_count": 0,
        "request_source": _safe_uid_text(request_source),
        "scene_id": -1,
        "alpha": _safe_int(alpha, 140),
        "method": "level_mask_alpha",
        "updated_at": time.time()
    }
    GOLDRUSH_FOG_JOB = {"active": False}
    try:
        map_info = get_current_map_info() or {}
        result["scene_id"] = _safe_int(map_info.get("scene_id", -1), -1)
        if not map_info.get("is_goldrush"):
            result["status"] = "not_in_goldrush"
            GOLDRUSH_FOG_LAST_RESULT = result
            return result

        minimap_ui = _find_ui_by_name("UIBattleGoldRushMiniMap")
        mask_result = _set_goldrush_level_mask_alpha(minimap_ui, alpha)
        result["mask"] = mask_result
        result["ui_refresh_count"] = _safe_int(mask_result.get("changed", 0), 0)
        result["success"] = bool(mask_result.get("ok"))
        result["status"] = "ok" if result["success"] else (_safe_uid_text(mask_result.get("reason", "")) or "no_effect")
        GOLDRUSH_FOG_LAST_RESULT = result
        try:
            _publish_goldrush_runtime_snapshot(time.time(), False, result["status"])
        except:
            pass
        return result
    except Exception as e:
        result["status"] = "error:%s" % _safe_uid_text(e)
        result["error"] = _safe_uid_text(e)
        GOLDRUSH_FOG_LAST_RESULT = result
        return result

def _start_goldrush_seed_box_job(request_source="manual_seed_box"):
    global GOLDRUSH_SEED_BOX_LAST_RESULT, GOLDRUSH_SEED_BOX_JOB
    result = {
        "requested": True,
        "success": False,
        "status": "queued",
        "phase": "queued",
        "cleared_point_count": 0,
        "ui_refresh_count": 0,
        "reward_box_count": 0,
        "reward_box_marked_count": 0,
        "alchemy_box_count": 0,
        "alchemy_box_marked_count": 0,
        "flush_ok_count": 0,
        "request_source": _safe_uid_text(request_source),
        "scene_id": -1,
        "generation_seed": None,
        "now_round_seed": None,
        "selected_count": 0,
        "candidate_count": 0,
        "collected_candidate_count": 0,
        "postprocess_group_counts": {},
        "candidate_lookup_stats": {},
        "runtime_token_validation": {"stable": False},
        "reward_boxes_source": "",
        "reward_boxes_mark_key_prefix": "",
        "session_token": "",
        "updated_at": time.time(),
        "method": "seed_reward_boxes"
    }
    try:
        map_info = get_current_map_info() or {}
        result["scene_id"] = _safe_int(map_info.get("scene_id", -1), -1)
        if not map_info.get("is_goldrush"):
            result["status"] = "not_in_goldrush"
            result["phase"] = "finished"
            GOLDRUSH_SEED_BOX_LAST_RESULT = result
            return result

        combat_core = get_available_combat_core()
        entity_mgr = _get_entity_mgr(combat_core)
        stash_system = _get_stash_system(combat_core)
        minimap_ui = _find_ui_by_name("UIBattleGoldRushMiniMap")
        big_map_ui = _find_ui_by_name("UIBattleGoldRushBigMap")
        clear_report = _clear_goldrush_open_map_marks_report(stash_system, minimap_ui, big_map_ui)
        result["clear_existing_frida_marks"] = dict(clear_report or {})
        result["removed_mark_count"] = _safe_int((clear_report or {}).get("cleared_count", 0), 0)
        _set_goldrush_seed_runtime_entries(-1, [], _safe_uid_text(request_source) or "manual_seed_box_reset", None)
        GOLDRUSH_SEED_BOX_JOB = {
            "active": True,
            "phase": "wait_map_loading",
            "result": result,
            "combat_core": combat_core,
            "entity_mgr": entity_mgr,
            "stash_system": stash_system,
            "minimap_ui": minimap_ui,
            "big_map_ui": big_map_ui,
            "reward_seed_entries": [],
            "reward_index": 0,
            "reward_marked_count": 0,
            "alchemy_entities": [],
            "alchemy_index": 0,
            "alchemy_marked_count": 0,
            "fog_bitmap": None,
            "fog_raw_data": None,
            "fog_fill_total_len": 0,
            "fog_fill_offset": 0,
            "fog_fill_chunk_size": 0,
            "gm_clear_result": {"ok": False},
            "bitmap_result": {"ok": False, "clear_count": 0},
            "recover_results": [],
            "flush_results": [],
            "next_step_at": time.time(),
            "started_at": time.time(),
            "loading_deadline": time.time() + 10.0
        }
        result["status"] = "waiting_map_loading"
        result["phase"] = "wait_map_loading"
        GOLDRUSH_SEED_BOX_LAST_RESULT = dict(result)
    except Exception as e:
        result["status"] = "error:%s" % str(e)
        result["phase"] = "finished"
        result["success"] = False
        GOLDRUSH_SEED_BOX_JOB = {"active": False}
        GOLDRUSH_SEED_BOX_LAST_RESULT = result
    return result

def _finish_goldrush_seed_box_job(job, status_override=None):
    global GOLDRUSH_SEED_BOX_LAST_RESULT, GOLDRUSH_SEED_BOX_JOB
    result = dict(job.get("result", {}) or {})
    flush_results = job.get("flush_results", []) or []
    result["phase"] = "finished"
    result["updated_at"] = time.time()
    reward_seed_entries = job.get("reward_seed_entries", []) or []
    result["reward_box_count"] = len(reward_seed_entries)
    result["reward_box_marked_count"] = _safe_int(job.get("reward_marked_count", 0), 0)
    result["alchemy_box_count"] = len(job.get("alchemy_entities", []) or [])
    result["alchemy_box_marked_count"] = _safe_int(job.get("alchemy_marked_count", 0), 0)
    result["flush_ok_count"] = sum(1 for item in flush_results if item.get("ok"))

    mark_ok = result["reward_box_marked_count"] > 0 or result["alchemy_box_marked_count"] > 0
    flush_ok = result["flush_ok_count"] > 0
    result["success"] = mark_ok or flush_ok
    if status_override:
        result["status"] = status_override
    else:
        result["status"] = "ok" if result["success"] else "no_effect"
    GOLDRUSH_SEED_BOX_LAST_RESULT = result
    GOLDRUSH_SEED_BOX_JOB = {"active": False}
    publish_valid = bool(reward_seed_entries) or bool(result.get("success"))
    _publish_goldrush_runtime_snapshot(result.get("updated_at"), not publish_valid, result.get("status", ""))
    return result

def _advance_goldrush_seed_box_job(loop_now):
    global GOLDRUSH_SEED_BOX_LAST_RESULT, GOLDRUSH_SEED_BOX_JOB
    job = GOLDRUSH_SEED_BOX_JOB
    if not job.get("active"):
        return
    now_value = float(loop_now or time.time())
    if now_value < float(job.get("next_step_at", 0.0) or 0.0):
        return

    result = job.get("result", {}) or {}
    phase = job.get("phase", "finished")
    debug_started_at = time.time()
    debug_phase_in = _safe_uid_text(phase)
    result["phase"] = phase
    result["status"] = "running"
    result["updated_at"] = time.time()
    result["reward_box_marked_count"] = _safe_int(job.get("reward_marked_count", 0), 0)
    result["alchemy_box_marked_count"] = _safe_int(job.get("alchemy_marked_count", 0), 0)
    GOLDRUSH_SEED_BOX_LAST_RESULT = dict(result)

    try:
        if phase == "wait_map_loading":
            combat_core = get_available_combat_core() or job.get("combat_core")
            if combat_core:
                job["combat_core"] = combat_core
            if not _goldrush_map_loading_ready(combat_core):
                if now_value >= float(job.get("loading_deadline", 0.0) or 0.0):
                    _finish_goldrush_seed_box_job(job, "map_loading_timeout")
                    return
                result["status"] = "waiting_map_loading"
                GOLDRUSH_SEED_BOX_LAST_RESULT = dict(result)
            elif not _goldrush_replay_inputs_ready(combat_core):
                if now_value >= float(job.get("loading_deadline", 0.0) or 0.0):
                    _finish_goldrush_seed_box_job(job, "replay_inputs_timeout")
                    return
                result["status"] = "waiting_replay_inputs"
                GOLDRUSH_SEED_BOX_LAST_RESULT = dict(result)
            else:
                map_info = get_current_map_info() or {}
                refreshed_scene_id = _safe_int(map_info.get("scene_id", result.get("scene_id", -1)), -1)
                result["scene_id"] = refreshed_scene_id
                entity_mgr = _get_entity_mgr(combat_core) or job.get("entity_mgr")
                stash_system = _get_stash_system(combat_core) or job.get("stash_system")
                minimap_ui = _find_ui_by_name("UIBattleGoldRushMiniMap") or job.get("minimap_ui")
                big_map_ui = _find_ui_by_name("UIBattleGoldRushBigMap") or job.get("big_map_ui")
                removed_mark_count = _clear_goldrush_open_map_marks(stash_system, minimap_ui, big_map_ui)
                if removed_mark_count > 0:
                    result["removed_mark_count"] = _safe_int(result.get("removed_mark_count", 0), 0) + removed_mark_count
                job["entity_mgr"] = entity_mgr
                job["stash_system"] = stash_system
                job["minimap_ui"] = minimap_ui
                job["big_map_ui"] = big_map_ui
                seed_reward_entries = _build_seed_reward_box_runtime_entries(
                    combat_core,
                    refreshed_scene_id,
                    True
                )
                replay_result = {}
                if isinstance(seed_reward_entries, tuple):
                    seed_reward_entries, replay_result = seed_reward_entries
                result["generation_seed"] = replay_result.get("generation_seed")
                result["now_round_seed"] = replay_result.get("now_round_seed")
                result["selected_count"] = _safe_int(replay_result.get("selected_count", 0), 0)
                result["candidate_count"] = _safe_int(replay_result.get("candidate_count", 0), 0)
                result["collected_candidate_count"] = _safe_int(replay_result.get("collected_candidate_count", 0), 0)
                result["postprocess_group_counts"] = dict(replay_result.get("postprocess_group_counts", {}) or {})
                result["candidate_lookup_stats"] = dict(replay_result.get("candidate_lookup_stats", {}) or {})
                result["runtime_token_validation"] = dict(replay_result.get("runtime_token_validation", {}) or {})
                result["reward_boxes_source"] = _safe_uid_text(replay_result.get("source", ""))
                result["session_token"] = _build_goldrush_session_token(replay_result)
                result["reward_boxes_mark_key_prefix"] = "frida_seed_reward_%s_" % _sanitize_goldrush_token_part(result.get("session_token"))
                alchemy_entities = _get_entities_by_type(entity_mgr, "GoldRushAlchemyBox")
                _set_goldrush_seed_runtime_entries(
                    refreshed_scene_id,
                    seed_reward_entries,
                    "manual_seed_box",
                    result.get("generation_seed")
                )
                result["reward_box_count"] = len(seed_reward_entries)
                result["alchemy_box_count"] = len(alchemy_entities)
                job["reward_seed_entries"] = seed_reward_entries
                job["reward_mark_key_prefix"] = result.get("reward_boxes_mark_key_prefix", "")
                job["generation_seed"] = result.get("generation_seed")
                job["reward_index"] = 0
                job["reward_marked_count"] = 0
                job["alchemy_entities"] = alchemy_entities
                job["alchemy_index"] = 0
                job["alchemy_marked_count"] = 0
                job["phase"] = "reward_boxes"
        elif not _goldrush_fog_job_scene_valid(job, result):
            current_core = get_available_combat_core() or job.get("combat_core")
            current_stash = _get_stash_system(current_core) or job.get("stash_system")
            current_minimap = _find_ui_by_name("UIBattleGoldRushMiniMap") or job.get("minimap_ui")
            current_big_map = _find_ui_by_name("UIBattleGoldRushBigMap") or job.get("big_map_ui")
            _clear_goldrush_open_map_marks(current_stash, current_minimap, current_big_map)
            _set_goldrush_seed_runtime_entries(-1, [], "scene_changed_abort", None)
            _finish_goldrush_seed_box_job(job, "scene_changed_abort")
            return
        elif phase == "reward_boxes":
            reward_seed_entries = job.get("reward_seed_entries", []) or []
            if reward_seed_entries:
                finished = _mark_seed_reward_batch(job)
            else:
                finished = True
            if finished:
                job["phase"] = "alchemy_boxes"
        elif phase == "alchemy_boxes":
            if _mark_entity_batch(job, "alchemy_entities", "alchemy_index", "alchemy_marked_count", "hook_alchemy_box", _get_alchemy_icon):
                job["phase"] = "flush_minimap"
        elif phase == "flush_minimap":
            stash_system = job.get("stash_system")
            minimap_ui = job.get("minimap_ui")
            if stash_system and minimap_ui:
                try:
                    stash_system.flush_to(minimap_ui)
                    job["flush_results"].append({"ui": "minimap", "ok": True})
                except Exception as e:
                    job["flush_results"].append({"ui": "minimap", "ok": False, "reason": str(e)})
            job["phase"] = "flush_big_map"
        elif phase == "flush_big_map":
            stash_system = job.get("stash_system")
            big_map_ui = job.get("big_map_ui")
            if stash_system and big_map_ui:
                try:
                    stash_system.flush_to(big_map_ui)
                    job["flush_results"].append({"ui": "big_map", "ok": True})
                except Exception as e:
                    job["flush_results"].append({"ui": "big_map", "ok": False, "reason": str(e)})
            _finish_goldrush_seed_box_job(job)
            return
        else:
            _finish_goldrush_seed_box_job(job, "invalid_phase")
            return
        job["next_step_at"] = now_value + GOLDRUSH_FOG_STEP_DELAY_SEC
    except Exception as e:
        _finish_goldrush_seed_box_job(job, "error:%s" % str(e))
    finally:
        try:
            debug_phase_out = _safe_uid_text(job.get("phase", debug_phase_in))
            _goldrush_debug_perf(
                "seed_box_job_tick",
                "E",
                "main.cpp:_advance_goldrush_seed_box_job",
                (time.time() - debug_started_at) * 1000.0,
                {
                    "phase_in": debug_phase_in,
                    "phase_out": debug_phase_out,
                    "active": bool(job.get("active")),
                    "result_status": _safe_uid_text(result.get("status", "")),
                    "reward_index": _safe_int(job.get("reward_index", 0), 0),
                    "alchemy_index": _safe_int(job.get("alchemy_index", 0), 0)
                }
            )
        except:
            pass

def _get_system_type():
    try:
        from common_cs.combat_core.enum_types.SystemType import SystemType
        return SystemType
    except:
        return None

def _get_game_entity_type():
    try:
        from common_cs.combat_core.enum_types.GameEntityType import GameEntityType
        return GameEntityType
    except:
        return None

def _get_goldrush_area_system(combat_core):
    if not combat_core:
        return None
    system_type = _get_system_type()
    if system_type:
        for name in ("GoldRushArea", "GoldRushAreaSystem"):
            try:
                system_key = getattr(system_type, name, None)
                if system_key is not None:
                    obj = combat_core.get_system(system_key)
                    if obj:
                        return obj
            except:
                pass
    return None

def _get_maze_system(combat_core):
    if not combat_core:
        return None
    system_type = _get_system_type()
    if system_type:
        for name in ("MazeMapGeneration", "MazeMapGenerationSystem"):
            try:
                system_key = getattr(system_type, name, None)
                if system_key is not None:
                    obj = combat_core.get_system(system_key)
                    if obj:
                        return obj
            except:
                pass
    return None

def _goldrush_map_loading_ready(combat_core):
    try:
        maze_sys = _get_maze_system(combat_core)
        _get_goldrush_generation_seed_strict(maze_sys)
        return True
    except:
        return False

def _get_goldrush_current_generation_seed(combat_core):
    try:
        maze_sys = _get_maze_system(combat_core)
        return _get_goldrush_generation_seed_strict(maze_sys)
    except:
        return None

def _goldrush_fog_job_scene_valid(job, result):
    try:
        map_info = get_current_map_info() or {}
        if not map_info.get("is_goldrush"):
            return False
        current_scene_id = _safe_int(map_info.get("scene_id", -1), -1)
        expected_scene_id = _safe_int(result.get("scene_id", job.get("scene_id", -1)), -1)
        if current_scene_id >= 0 and expected_scene_id >= 0 and current_scene_id != expected_scene_id:
            return False
        current_seed = _normalize_goldrush_generation_seed(
            _get_goldrush_current_generation_seed(get_available_combat_core() or job.get("combat_core"))
        )
        expected_seed = _normalize_goldrush_generation_seed(result.get("generation_seed", job.get("generation_seed")))
        if expected_seed is not None and current_seed is not None and current_seed != expected_seed:
            return False
        return True
    except:
        return False

def _get_stash_system(combat_core):
    if not combat_core:
        return None
    system_type = _get_system_type()
    if system_type:
        for name in ("GoldRushMinimapStash", "GoldRushMinimapStashSystem"):
            try:
                system_key = getattr(system_type, name, None)
                if system_key is not None:
                    obj = combat_core.get_system(system_key)
                    if obj:
                        return obj
            except:
                pass
    return None

def _force_full_visible_via_bitmap(combat_core, enable_voxel_fallback=False):
    result = {
        "ok": False,
        "has_area_system": False,
        "has_fog_bitmap": False,
        "clear_count": 0,
        "data_len": 0,
        "data_fill_ok": False,
        "room_count": 0,
        "fallback_used": False
    }
    fog_bitmap = None
    area_sys = _get_goldrush_area_system(combat_core)
    result["has_area_system"] = bool(area_sys)
    try:
        fog_bitmap = getattr(area_sys, "maze_fog_bit_map", None) if area_sys else None
    except:
        fog_bitmap = None
    result["has_fog_bitmap"] = bool(fog_bitmap)
    if not fog_bitmap:
        return result, None

    raw_data = getattr(fog_bitmap, "_data", None)
    if raw_data and isinstance(raw_data, bytearray):
        result["data_len"] = len(raw_data)
        try:
            raw_data[:] = b"\xff" * len(raw_data)
            result["data_fill_ok"] = True
        except Exception as e:
            result["data_fill_error"] = str(e)

    if enable_voxel_fallback and not result["data_fill_ok"]:
        result["fallback_used"] = True
        maze_system = _get_maze_system(combat_core)
        maze_object = getattr(maze_system, "maze_object", None) if maze_system else None
        rooms = getattr(maze_object, "rooms", None) if maze_object else None
        room_list = _iter_values(rooms)
        result["room_count"] = len(room_list)
        for room in room_list:
            voxels = getattr(room, "voxels", None)
            for voxel in _iter_values(voxels):
                try:
                    x = float(getattr(voxel, "x", 0.0))
                    y = float(getattr(voxel, "y", 0.0))
                    z = float(getattr(voxel, "z", 0.0))
                    fog_bitmap.clear_fog_at(x, y, z)
                    result["clear_count"] += 1
                except:
                    pass
    result["ok"] = result["data_fill_ok"] or result["clear_count"] > 0
    return result, fog_bitmap

def _prepare_goldrush_fog_bitmap_plan(combat_core, reward_count=0, alchemy_count=0):
    plan = {
        "fog_bitmap": None,
        "fog_raw_data": None,
        "fog_fill_total_len": 0,
        "fog_fill_chunk_size": 0,
        "bitmap_result": {
            "ok": False,
            "has_area_system": False,
            "has_fog_bitmap": False,
            "clear_count": 0,
            "data_len": 0,
            "data_fill_ok": False,
            "room_count": 0,
            "fallback_used": False
        }
    }
    area_sys = _get_goldrush_area_system(combat_core)
    plan["bitmap_result"]["has_area_system"] = bool(area_sys)
    try:
        fog_bitmap = getattr(area_sys, "maze_fog_bit_map", None) if area_sys else None
    except:
        fog_bitmap = None
    plan["fog_bitmap"] = fog_bitmap
    plan["bitmap_result"]["has_fog_bitmap"] = bool(fog_bitmap)
    if not fog_bitmap:
        return plan

    raw_data = getattr(fog_bitmap, "_data", None)
    if raw_data and isinstance(raw_data, bytearray):
        total_len = len(raw_data)
        total_steps_budget = max(1, int(float(GOLDRUSH_FOG_TARGET_DURATION_SEC) / max(0.01, float(GOLDRUSH_FOG_STEP_DELAY_SEC))))
        reward_steps = (max(0, int(reward_count)) + GOLDRUSH_FOG_MARK_BATCH_SIZE - 1) // GOLDRUSH_FOG_MARK_BATCH_SIZE
        alchemy_steps = (max(0, int(alchemy_count)) + GOLDRUSH_FOG_MARK_BATCH_SIZE - 1) // GOLDRUSH_FOG_MARK_BATCH_SIZE
        reserved_steps = 7 + reward_steps + alchemy_steps
        fill_steps_budget = max(1, total_steps_budget - reserved_steps)
        chunk_size = max(1, (total_len + fill_steps_budget - 1) // fill_steps_budget)
        plan["fog_raw_data"] = raw_data
        plan["fog_fill_total_len"] = total_len
        plan["fog_fill_chunk_size"] = chunk_size
        plan["bitmap_result"]["data_len"] = total_len
    return plan

def _fill_goldrush_fog_bitmap_chunk(job):
    bitmap_result = job.get("bitmap_result", {}) or {}
    raw_data = job.get("fog_raw_data")
    total_len = int(job.get("fog_fill_total_len", 0) or 0)
    current_offset = int(job.get("fog_fill_offset", 0) or 0)
    chunk_size = max(1, int(job.get("fog_fill_chunk_size", 0) or 1))
    if not raw_data or not isinstance(raw_data, bytearray) or total_len <= 0:
        bitmap_result["ok"] = False
        job["bitmap_result"] = bitmap_result
        return True

    end_offset = min(total_len, current_offset + chunk_size)
    try:
        raw_data[current_offset:end_offset] = b"\xff" * (end_offset - current_offset)
        bitmap_result["has_fog_bitmap"] = True
        bitmap_result["data_len"] = total_len
        bitmap_result["clear_count"] = end_offset
        bitmap_result["data_fill_ok"] = end_offset >= total_len
        bitmap_result["ok"] = end_offset >= total_len
        job["fog_fill_offset"] = end_offset
        job["bitmap_result"] = bitmap_result
        return end_offset >= total_len
    except Exception as e:
        bitmap_result["data_fill_error"] = str(e)
        bitmap_result["ok"] = False
        job["bitmap_result"] = bitmap_result
        return True

def _get_entity_mgr(combat_core):
    if not combat_core:
        return None
    return getattr(combat_core, "ref_entity_mgr", None)

def _get_entities_by_type(entity_mgr, entity_type_name):
    result = []
    if not entity_mgr:
        return result
    game_entity_type = _get_game_entity_type()
    if not game_entity_type:
        return result
    try:
        entity_type = getattr(game_entity_type, entity_type_name, None)
        if entity_type is None:
            return result
        getter = getattr(entity_mgr, "get_entities_by_type", None)
        if not callable(getter):
            return result
        return _iter_values(getter(entity_type))
    except:
        return result

def _get_position3(entity):
    if not entity:
        return None
    try:
        pos = entity.get_position3()
        if pos:
            return pos
    except:
        pass
    return getattr(entity, "world_position", None)

def _vec3_add(pos, dy):
    try:
        import math3d
        world_pos = _make_vector(pos)
        if world_pos is None:
            return pos
        return world_pos + math3d.Vector3(0, dy, 0)
    except:
        return pos

def _make_vector(pos):
    if pos is None:
        return None
    try:
        if hasattr(pos, 'x') and hasattr(pos, 'y') and hasattr(pos, 'z'):
            return pos
    except:
        pass
    try:
        if isinstance(pos, (list, tuple)) and len(pos) >= 3:
            import math3d
            return math3d.vector(float(pos[0]), float(pos[1]), float(pos[2]))
    except:
        pass
    return None

def _vector_to_tuple(value):
    if value is None:
        return None
    try:
        return (
            round(float(getattr(value, "x")), 3),
            round(float(getattr(value, "y")), 3),
            round(float(getattr(value, "z")), 3)
        )
    except:
        pass
    try:
        if isinstance(value, (list, tuple)) and len(value) >= 3:
            return (
                round(float(value[0]), 3),
                round(float(value[1]), 3),
                round(float(value[2]), 3)
            )
    except:
        pass
    return None

def _dict_get(value, *names):
    for name in names:
        try:
            if isinstance(value, dict) and name in value:
                return value[name]
        except:
            pass
        try:
            getter = getattr(value, "get", None)
            if callable(getter):
                got = getter(name)
                if got is not None:
                    return got
        except:
            pass
        try:
            return value[name]
        except:
            pass
        try:
            return getattr(value, name)
        except:
            pass
    return None

def _safe_call(obj, name, *args):
    if obj is None:
        return None
    try:
        fn = getattr(obj, name, None)
    except:
        return None
    if not callable(fn):
        return None
    try:
        return fn(*args)
    except:
        return None

def _freeze_plain_value(value, depth=0):
    if depth >= 3:
        return _safe_uid_text(value)
    if value is None or isinstance(value, (bool, int, float, str)):
        return value
    if isinstance(value, dict):
        frozen = {}
        for key, item in value.items():
            frozen[_safe_uid_text(key)] = _freeze_plain_value(item, depth + 1)
        return frozen
    if isinstance(value, (list, tuple)):
        return [_freeze_plain_value(item, depth + 1) for item in value]
    return _safe_uid_text(value)

def _freeze_gen_info(gen_info):
    if gen_info is None:
        return {}
    if isinstance(gen_info, dict):
        return _freeze_plain_value(gen_info)
    frozen = {}
    for key in ("level", "reward_id", "box_id", "box_type", "weight"):
        value = _dict_get(gen_info, key)
        if value is not None:
            frozen[key] = _freeze_plain_value(value)
    return frozen

class _SeedTransform(object):
    def __init__(self, translation):
        self.translation = translation

class _ReplayEntity(object):
    def __init__(self, entity_id):
        self.entity_id = entity_id

class _ReplayEntityMgr(object):
    def __init__(self):
        self._next_entity_id = 900000000
        self.CreateAutoSync = True

    def _next_id(self):
        self._next_entity_id += 1
        return self._next_entity_id

    def create_add_entity_at_pos(self, entity_type, pos, params):
        return _ReplayEntity(self._next_id())

    def drop_item(self, item_id, pos, params):
        return None

class _ReplayMonsterBornSystem(object):
    def collect_boss_nav_info(self, world_pos):
        return None

    def collect_room_info(self, room, pos, forward, monster_id, monster_type, extra_info=None):
        return None

    def collect_outdoor_info(self, scene_group_proxy, pos, forward, monster_id):
        return None

class _ReplayRollItemSystem(object):
    def get_reward_by_reward_id(self, reward_id, by_player=None):
        return []

class _ReplayGameMode(object):
    def __init__(self, result):
        self._result = result

    def add_loading_task(self, func, *args):
        try:
            return func(*args)
        except Exception as e:
            self._result.setdefault("errors", []).append({
                "task": _safe_uid_text(getattr(func, "__qualname__", getattr(func, "__name__", func))),
                "error": _safe_uid_text(e)
            })
            raise

    def add_loading_task_delay(self, func, *args):
        self._result["delayed_task_skipped"] = self._result.get("delayed_task_skipped", 0) + 1
        return None

class _ReplayCore(object):
    def __init__(self, real_core, result, system_type_cls):
        self._real_core = real_core
        self._result = result
        self._SystemType = system_type_cls
        self.game_mode_instance = _ReplayGameMode(result)
        self.ref_entity_mgr = _ReplayEntityMgr()
        self._monster_born_system = _ReplayMonsterBornSystem()
        self._roll_item_system = _ReplayRollItemSystem()

    def is_server(self):
        return False

    def get_system(self, system_type):
        try:
            if system_type == getattr(self._SystemType, "GoldRushMonsterBornSystem", None):
                return self._monster_born_system
            if system_type == getattr(self._SystemType, "GoldRushRollItemSystem", None):
                return self._roll_item_system
        except:
            pass
        return self._real_core.get_system(system_type)

    def __getattr__(self, name):
        return getattr(self._real_core, name)

class _ReplayGenerationSystem(object):
    def __init__(self, real_system, replay_core):
        self._real_system = real_system
        self.core = replay_core
        self.ref_gamemode_data = getattr(real_system, "ref_gamemode_data", None)
        self.maze_object = getattr(real_system, "maze_object", None)

    def get_generation_seed(self):
        return _get_goldrush_generation_seed_strict(self._real_system)

    def register_room_panel_entity(self, room_index, entity_id):
        return None

    def ref_publish_event(self, event_type, payload):
        return None

    def __getattr__(self, name):
        return getattr(self._real_system, name)

class _ReplayRoomProxy(object):
    def __init__(self, real_room, replay_generation_system):
        self._real_room = real_room
        self.generation_system = replay_generation_system

    def __getattr__(self, name):
        return getattr(self._real_room, name)

class _ReplayMazeObjectProxy(object):
    def __init__(self, real_maze_obj, replay_generation_system):
        self._real_maze_obj = real_maze_obj
        self._room_proxy_map = {}
        self.rooms = []
        real_rooms = list(getattr(real_maze_obj, "rooms", []) or [])
        for room in real_rooms:
            proxy = _ReplayRoomProxy(room, replay_generation_system)
            self._room_proxy_map[id(room)] = proxy
            self.rooms.append(proxy)

    def get_position_room(self, pos):
        room = None
        try:
            room = self._real_maze_obj.get_position_room(pos)
        except:
            room = None
        if room is None:
            return None
        return self._room_proxy_map.get(id(room), room)

    def __getattr__(self, name):
        return getattr(self._real_maze_obj, name)

def _extract_room_scene(room):
    room_scene = _safe_uid_text(getattr(room, "ROOM_SCENE", "") or "")
    if room_scene:
        return room_scene
    proxy = getattr(room, "scene_group_proxy", None)
    if proxy:
        return _safe_uid_text(getattr(proxy, "scn_path", "") or "")
    return ""

def _load_scene_group_data(combat_core, room):
    room_scene = _extract_room_scene(room)
    result = {"scene_data": None, "group_names": {}, "model_name_to_data": {}}
    direct_scene = _safe_call(room, "get_group_name_data")
    if direct_scene is not None:
        result["scene_data"] = direct_scene
    if result["scene_data"] is None and room_scene:
        ref_gamemode_data = getattr(combat_core, "ref_gamemode_data", None) if combat_core else None
        scene_data = _safe_call(ref_gamemode_data, "get_maze_room_scn_group_data", room_scene)
        if scene_data is not None:
            result["scene_data"] = scene_data
    if result["scene_data"] is None:
        proxy = getattr(room, "scene_group_proxy", None)
        if proxy is not None:
            result["group_names"] = _dict_get(proxy, "group_names") or {}
            result["model_name_to_data"] = _dict_get(proxy, "model_name_to_data") or {}
        return result
    result["group_names"] = _dict_get(result["scene_data"], "group_names") or {}
    result["model_name_to_data"] = _dict_get(result["scene_data"], "model_name_to_data") or {}
    return result

def _load_group_name_transforms(room):
    transforms = _safe_call(room, "get_group_name_transforms")
    return transforms or {}

def _make_seed_transform(world_position):
    return _SeedTransform(world_position)

def _parse_int_tuple(text):
    if not text:
        return ()
    try:
        return tuple(int(x) for x in _safe_uid_text(text).split(",") if _safe_uid_text(x).strip())
    except:
        return ()

def _build_chest_candidates(combat_core, maze_sys):
    maze_obj = getattr(maze_sys, "maze_object", None) if maze_sys else None
    rooms = getattr(maze_obj, "rooms", []) if maze_obj else []
    candidates = []
    for room_index, room in enumerate(rooms):
        loaded = _load_scene_group_data(combat_core, room)
        group_names = loaded.get("group_names") or {}
        model_name_to_data = loaded.get("model_name_to_data") or {}
        group_name_transforms = _load_group_name_transforms(room)
        chest_names = _dict_get(group_names, "ChestGroup") or []
        for obj_name in _iter_values(chest_names):
            info = _dict_get(model_name_to_data, obj_name)
            if info is None:
                continue
            attr_extra = _dict_get(info, "AttrExtra") or {}
            level_str = _dict_get(attr_extra, "level") or ""
            if not level_str:
                continue
            allowed_levels = _parse_int_tuple(level_str)
            if not allowed_levels:
                continue
            ids_str = _dict_get(attr_extra, "id")
            custom_ids = _parse_int_tuple(ids_str) if ids_str else None
            level_by_box_id = {}
            if custom_ids and len(custom_ids) == len(allowed_levels):
                for idx, custom_id in enumerate(custom_ids):
                    try:
                        level_by_box_id[int(custom_id)] = int(allowed_levels[idx])
                    except:
                        pass
            fallback_level = 0
            if len(allowed_levels) == 1:
                try:
                    fallback_level = int(allowed_levels[0])
                except:
                    fallback_level = 0
            candidate_gen_info = {}
            if fallback_level > 0:
                candidate_gen_info["level"] = fallback_level
            elif len(level_by_box_id) == 1:
                try:
                    candidate_gen_info["level"] = int(next(iter(level_by_box_id.values())))
                except:
                    candidate_gen_info = {}
            try:
                weight = int(_dict_get(attr_extra, "weight") or 0)
            except:
                weight = 0
            chest_transforms = _dict_get(group_name_transforms, "ChestGroup") or {}
            transform_obj = _dict_get(chest_transforms, obj_name)
            if transform_obj is None:
                world_position = _vector_to_tuple(_dict_get(info, "world_position", "Position", "position", "translation"))
                if world_position is not None:
                    transform_obj = _make_seed_transform(world_position)
            if transform_obj is None:
                continue
            candidates.append({
                "model_name": _safe_uid_text(obj_name),
                "room_index": room_index,
                "allowed_levels": tuple(allowed_levels),
                "weight": weight,
                "transform": transform_obj,
                "custom_box_ids": tuple(custom_ids) if custom_ids else None,
                "gen_info": candidate_gen_info,
                "level_by_box_id": level_by_box_id,
                "fallback_level": fallback_level
            })
    return candidates

def _goldrush_replay_inputs_ready(combat_core):
    try:
        maze_sys = _get_maze_system(combat_core)
        if not maze_sys:
            return False
        maze_obj = getattr(maze_sys, "maze_object", None)
        rooms = list(getattr(maze_obj, "rooms", []) or []) if maze_obj else []
        if not rooms:
            return False
        return len(_build_chest_candidates(combat_core, maze_sys)) > 0
    except:
        return False

def _candidate_key(room_index, world_position, decimals=3):
    if room_index is None or world_position is None:
        return None
    rounded_position = _vector_to_tuple(world_position)
    if rounded_position is None:
        return None
    try:
        rounded_position = (
            round(float(rounded_position[0]), int(decimals)),
            round(float(rounded_position[1]), int(decimals)),
            round(float(rounded_position[2]), int(decimals))
        )
    except:
        return None
    return "%s|%s|%s|%s" % (
        int(room_index),
        _safe_uid_text(rounded_position[0]),
        _safe_uid_text(rounded_position[1]),
        _safe_uid_text(rounded_position[2])
    )

def _candidate_position(item):
    return _vector_to_tuple(_dict_get(_dict_get(item, "transform"), "translation"))

def _candidate_distance_sq(candidate, world_position):
    candidate_pos = _candidate_position(candidate)
    target_pos = _vector_to_tuple(world_position)
    if candidate_pos is None or target_pos is None:
        return None
    dx = _safe_float(candidate_pos[0], 0.0) - _safe_float(target_pos[0], 0.0)
    dy = _safe_float(candidate_pos[1], 0.0) - _safe_float(target_pos[1], 0.0)
    dz = _safe_float(candidate_pos[2], 0.0) - _safe_float(target_pos[2], 0.0)
    return dx * dx + dy * dy + dz * dz

def _pick_best_candidate(matches, world_position):
    best_candidate = None
    best_distance_sq = None
    for candidate in matches or []:
        distance_sq = _candidate_distance_sq(candidate, world_position)
        if distance_sq is None:
            continue
        if best_distance_sq is None or distance_sq < best_distance_sq:
            best_candidate = candidate
            best_distance_sq = distance_sq
    return best_candidate

def _build_candidate_lookup(candidates):
    lookup = {
        "exact": {},
        "by_room": {},
        "collision_count": 0,
        "collisions": []
    }
    for item in candidates or []:
        room_index = _dict_get(item, "room_index")
        world_position = _candidate_position(item)
        if room_index is None or world_position is None:
            continue
        room_key = _safe_uid_text(room_index)
        lookup["by_room"].setdefault(room_key, []).append(item)
        for decimals in (3, 2, 1):
            key = _candidate_key(room_index, world_position, decimals)
            if not key:
                continue
            bucket = lookup["exact"].setdefault(key, [])
            bucket.append(item)
            if len(bucket) == 2:
                lookup["collision_count"] += 1
                if len(lookup["collisions"]) < 20:
                    lookup["collisions"].append({
                        "key": key,
                        "decimals": decimals,
                        "room_index": _safe_int(room_index, -1),
                        "count": len(bucket)
                    })
    return lookup

def _match_candidate(lookup, room_index, world_position):
    if not isinstance(lookup, dict):
        return None
    for decimals in (3, 2, 1):
        key = _candidate_key(room_index, world_position, decimals)
        matches = (lookup.get("exact") or {}).get(key) or []
        picked = _pick_best_candidate(matches, world_position)
        if picked is not None:
            return picked
    room_candidates = (lookup.get("by_room") or {}).get(_safe_uid_text(room_index)) or []
    picked = _pick_best_candidate(room_candidates, world_position)
    if picked is None:
        return None
    distance_sq = _candidate_distance_sq(picked, world_position)
    if distance_sq is not None and distance_sq <= 1.5625:
        return picked
    return None

def _extract_selected_boxes_with_lookup(data_list, candidate_lookup=None):
    selected = []
    for point in _iter_values(data_list):
        gen_info = _dict_get(point, "gen_info")
        if not gen_info:
            continue
        transform = _dict_get(point, "transform")
        translation = getattr(transform, "translation", None) if transform else None
        world_position = _vector_to_tuple(translation)
        room_index = _dict_get(point, "room_index")
        candidate = _match_candidate(candidate_lookup, room_index, world_position) if candidate_lookup else None
        model_name = _safe_uid_text(_dict_get(point, "model_name"))
        if not model_name and candidate is not None:
            model_name = _safe_uid_text(_dict_get(candidate, "model_name"))
        box_id = _dict_get(point, "_box_id", "box_id")
        level_value = 0
        try:
            level_value = int(_dict_get(gen_info, "level") or 0)
        except:
            level_value = 0
        if level_value <= 0 and candidate is not None:
            # 