 100
            if abs(raw) <= 1.0:
                return raw * 10000.0
            return raw * 100.0

        wax_mgr = getattr(me, 'wax_progress_mgr', None)
        cold_progress = 0.0
        heat_progress = 0.0
        if wax_mgr:
            cold_wax_obj = getattr(wax_mgr, 'cold_wax', None)
            if cold_wax_obj and hasattr(cold_wax_obj, 'get_progress'):
                cold_progress = _normalize_wax_progress(cold_wax_obj.get_progress())
            elif hasattr(wax_mgr, 'get_cold_wax_progress'):
                cold_progress = _normalize_wax_progress(wax_mgr.get_cold_wax_progress())

            heat_wax_obj = getattr(wax_mgr, 'heat_wax', None)
            if heat_wax_obj and hasattr(heat_wax_obj, 'get_progress'):
                heat_progress = _normalize_wax_progress(heat_wax_obj.get_progress())
            elif hasattr(wax_mgr, 'get_heat_wax_progress'):
                heat_progress = _normalize_wax_progress(wax_mgr.get_heat_wax_progress())

        payload["cold_wax_progress"] = round(cold_progress, 1)
        payload["heat_wax_progress"] = round(heat_progress, 1)
        payload["valid"] = True
    except Exception as e:
        payload["error"] = str(e)

    return json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(',', ':'))

def collect_qte_state_data():
    payload = {
        "type": "qte_state",
        "valid": False,
        "ui_found": False,
        "ui_class_name": "",
        "ui_source": "",
        "ui_battle_qte": {
            "in_qte": False,
            "qte_visible_flag": False,
            "qte_hit_flag": False,
            "qte_fail_flag": False,
            "qte_kind": -1,
            "qte_uid": "",
            "qte_target_uid": "",
            "qte_needle_rotation": 0.0,
            "good_pos": 0.0,
            "perfect_pos": 0.0
        },
        "hold_item_count": 0,
        "musician_items": [],
        "qte_primary_path": "",
        "qte_from_gk_input": {},
        "qte_via_battle_ui": {},
        "musician_qte": {}
    }

    def _safe_text(value):
        if value is None:
            return ""
        try:
            return str(value)
        except:
            return ""

    def _safe_call(obj, name, *args):
        if obj is None:
            return None
        try:
            fn = getattr(obj, name, None)
        except:
            return None
        if not callable(fn):
            return None
        try:
            return fn(*args)
        except:
            return None

    def _safe_get(obj, name, default_value=None):
        try:
            return getattr(obj, name, default_value)
        except:
            return default_value

    def _safe_json(value):
        try:
            json.dumps(value, ensure_ascii=False)
            return value
        except:
            return _safe_text(value)

    def _pair_to_range(value):
        if value is None:
            return None
        try:
            if isinstance(value, (list, tuple)) and len(value) >= 2:
                return [float(value[0]), float(value[1])]
        except:
            pass
        return None

    def _safe_number(value, default_value=0.0):
        try:
            return float(value)
        except:
            try:
                return int(value)
            except:
                return default_value

    def _normalize_qte_length_list(value, default_values):
        result = []
        if isinstance(value, (list, tuple)):
            for entry in value:
                result.append(_safe_number(entry, -1.0))
        elif isinstance(value, str):
            for entry in value.split(','):
                entry = entry.strip()
                if not entry:
                    continue
                result.append(_safe_number(entry, -1.0))
        result = [entry for entry in result if entry > 0.0]
        if len(result) >= 3:
            return result[:3]
        return list(default_values)

    def _resolve_battle_now_time(item=None):
        if item is not None:
            current_time = _safe_call(item, 'game_time')
            current_time = _safe_number(current_time, -1.0)
            if current_time >= 0.0:
                return current_time

            item_room = _safe_get(item, 'room', None)
            if item_room is not None:
                current_time = _safe_call(item_room, 'game_time')
                if current_time is None:
                    current_time = _safe_get(item_room, 'game_time', None)
                current_time = _safe_number(current_time, -1.0)
                if current_time >= 0.0:
                    return current_time

        world_mgr = None
        try:
            world_mgr = getattr(GK, 'g_world_mgr', None)
        except:
            world_mgr = None

        candidates = []
        try:
            battle_world = getattr(world_mgr, 'battle_world', None) if world_mgr else None
            if battle_world is not None:
                candidates.append(battle_world)
        except:
            pass

        try:
            me = getattr(GK, 'g_unit', None)
            current_time = _safe_call(me, 'game_time') if me else None
            current_time = _safe_number(current_time, -1.0)
            if current_time >= 0.0:
                return current_time
            room = getattr(me, 'room', None) if me else None
            if room is not None:
                candidates.append(room)
        except:
            pass

        for world in candidates:
            current_time = _safe_call(world, 'game_time')
            if current_time is None:
                current_time = _safe_call(world, 'time_now')
            if current_time is None:
                current_time = _safe_get(world, 'game_time', None)
            if current_time is None:
                current_time = _safe_get(world, 'time_now', None)
            if current_time is None:
                current_time = _safe_get(world, 'now_time', None)
            current_time = _safe_number(current_time, -1.0)
            if current_time >= 0.0:
                return current_time
        return 0.0

    def _node_visible(node):
        if node is None:
            return False
        return _safe_bool(_safe_call(node, 'isVisible'))

    def _node_rotation(node):
        if node is None:
            return None
        return _safe_call(node, 'getRotation')

    def _dump_qte_obj(qte_obj):
        if qte_obj is None:
            return {}
        qte_needle = _safe_get(qte_obj, 'qte_zhizhen', None)
        good_range = _pair_to_range(_safe_get(qte_obj, 'good_pos', None))
        perfect_range = _pair_to_range(_safe_get(qte_obj, 'exce_pos', None))
        return {
            "class_name": _safe_text(_safe_get(_safe_get(qte_obj, '__class__', None), '__name__', type(qte_obj).__name__)),
            "in_qte": _safe_bool(_safe_get(qte_obj, '_in_qte', False)),
            "qte_visible_flag": _safe_bool(_safe_call(qte_obj, 'is_qte_visible')),
            "qte_visible_test": _safe_bool(_safe_call(qte_obj, 'is_qte_visible_test')),
            "qte_hit_flag": _safe_bool(_safe_get(qte_obj, 'qte_hit_flag', False)),
            "qte_fail_flag": _safe_bool(_safe_get(qte_obj, 'qte_fail_flag', False)),
            "qte_kind": _safe_int(_safe_get(qte_obj, 'qte_kind', -1), -1),
            "qte_uid": _safe_text(_safe_get(qte_obj, 'qte_uid', 0)),
            "qte_target_uid": _safe_text(_safe_get(qte_obj, 'qte_target_uid', 0)),
            "good_pos_raw": _safe_json(_safe_get(qte_obj, 'good_pos', None)),
            "perfect_pos_raw": _safe_json(_safe_get(qte_obj, 'exce_pos', None)),
            "good_range": good_range,
            "good_left": good_range[0] if good_range else None,
            "good_right": good_range[1] if good_range else None,
            "good_width": (good_range[1] - good_range[0]) if good_range else None,
            "perfect_range": perfect_range,
            "perfect_left": perfect_range[0] if perfect_range else None,
            "perfect_right": perfect_range[1] if perfect_range else None,
            "perfect_width": (perfect_range[1] - perfect_range[0]) if perfect_range else None,
            "inc_flag": _safe_bool(_safe_get(qte_obj, 'inc_flag', False)),
            "in_qte_alert": _safe_bool(_safe_call(qte_obj, 'is_in_qte_alert')),
            "needle_visible": _node_visible(qte_needle),
            "needle_rotation": _safe_number(_node_rotation(qte_needle), 0.0)
        }

    def _find_battle_qte_via_ui_mgr():
        result = {
            "ui_name": "",
            "battle_ui_class": "",
            "layer_proxy_class": "",
            "qte_ui": None,
            "error": ""
        }
        try:
            g_world_mgr = getattr(GK, 'g_world_mgr', None)
            battle_world = getattr(g_world_mgr, 'battle_world', None) if g_world_mgr else None
            ui_name = _safe_call(battle_world, 'get_ui_battle_name') if battle_world else None
            g_ui_mgr = getattr(GK, 'g_ui_mgr', None)
            battle_ui = _safe_call(g_ui_mgr, 'get_ui', ui_name) if (g_ui_mgr and ui_name) else None
            layer_proxy = getattr(battle_ui, 'layer_proxy', None) if battle_ui else None
            qte_ui = _safe_call(layer_proxy, 'find_ui', 'UIBattleQTE') if layer_proxy else None
            result["ui_name"] = _safe_text(ui_name)
            result["battle_ui_class"] = _safe_text(_safe_get(_safe_get(battle_ui, '__class__', None), '__name__', None))
            result["layer_proxy_class"] = _safe_text(_safe_get(_safe_get(layer_proxy, '__class__', None), '__name__', None))
            result["qte_ui"] = qte_ui
        except Exception as e:
            result["error"] = _safe_text(e)
        return result

    def _iter_hold_items():
        try:
            me = getattr(GK, 'g_unit', None)
            combat_unit = getattr(me, 'combat_unit', None) if me else None
            getter = getattr(combat_unit, 'get_hold_items', None) if combat_unit else None
            if callable(getter):
                items = getter()
                try:
                    return list(items)
                except:
                    return []
        except:
            pass
        return []

    def _iter_g_unit_items():
        try:
            me = getattr(GK, 'g_unit', None)
            item_lst = _safe_get(me, 'item_lst', None) if me else None
            if item_lst is None:
                return []
            try:
                return list(item_lst)
            except:
                return []
        except:
            pass
        return []

    def _find_musician_item():
        result = {
            "source": "",
            "item": None
        }

        try:
            cs_utils_battle = None
            try:
                import common_cs.cs_utils_battle as cs_utils_battle
            except:
                cs_utils_battle = None

            me = getattr(GK, 'g_unit', None)
            combat_unit = getattr(me, 'combat_unit', None) if me else None
            players = []
            if me is not None:
                players.append(me)
            if combat_unit is not None:
                players.append(combat_unit)

            if cs_utils_battle is not None:
                for player in players:
                    item = _safe_call(cs_utils_battle, 'get_music_stick_item', player)
                    if item is not None:
                        result["source"] = "cs_utils_battle.get_music_stick_item"
                        result["item"] = item
                        return result
        except:
            pass

        try:
            for item in _iter_hold_items():
                item_cls = _safe_text(_safe_get(_safe_get(item, '__class__', None), '__name__', None))
                if _safe_get(item, 'music_pool', None) is not None:
                    result["source"] = "combat_unit.get_hold_items"
                    result["item"] = item
                    return result
                if _safe_get(item, 'qte_mode', None) is not None or 'Music' in item_cls:
                    result["source"] = "combat_unit.get_hold_items"
                    result["item"] = item
                    return result
        except:
            pass

        try:
            for item in _iter_g_unit_items():
                item_cls = _safe_text(_safe_get(_safe_get(item, '__class__', None), '__name__', None))
                if _safe_get(item, 'music_pool', None) is not None:
                    result["source"] = "g_unit.item_lst"
                    result["item"] = item
                    return result
                if _safe_get(item, 'qte_mode', None) is not None or 'Music' in item_cls:
                    result["source"] = "g_unit.item_lst"
                    result["item"] = item
                    return result
        except:
            pass

        return result

    def _dump_music_container(container, item, now_time):
        if container is None:
            return {}
        seq = _safe_get(container, 'music_seq', None)
        seq_len = 0
        tail = None
        if seq is not None:
            try:
                seq_len = len(seq)
            except:
                seq_len = 0
            if seq_len > 0:
                try:
                    tail = seq[-1]
                except:
                    tail = None
        
        tail_info = {}
        if tail:
            begin_time = _safe_number(_safe_get(tail, 'begin_time', 0.0), 0.0)
            channel = _safe_int(_safe_get(tail, 'channel', 0), 0)
            note_type = _safe_int(_safe_get(tail, 'note_type', -1), -1)
            qte_mode = _safe_int(_safe_get(item, 'qte_mode', 0), 0)
            difficulty = _safe_int(_safe_get(item, 'difficulty', 0), 0)
            ability_lengths = [2.0, 1.6, 1.2]
            item_qte_length = _safe_number(_safe_get(item, 'music_qte_length_item', None), None)
            qte_length = _safe_number(_safe_get(tail, 'music_qte_length', None), None)
            track_kind = "