import re

data = open('1.so','rb').read()
strings = re.findall(rb'[\x20-\x7e]{7,}', data)
for s in strings[:400]:
    print(s.decode('ascii','ignore'))
