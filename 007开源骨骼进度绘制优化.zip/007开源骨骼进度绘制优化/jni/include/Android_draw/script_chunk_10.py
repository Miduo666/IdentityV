"
}

SPECIAL_UNIT_BONE_TYPES = {247, 248, 218}
SPECIAL_UNIT_PELVIS_BONE = 'Bip001 Pelvis'

def _get_unit_bone_pos(unit, bone_name=SPECIAL_UNIT_PELVIS_BONE):
    try:
        anim_data = getattr(unit, 'anim_data_component', None)
        if anim_data and hasattr(anim_data, 'get_bone_position'):
            bone_pos = anim_data.get_bone_position(bone_name=bone_name)
            if bone_pos:
                return bone_pos
    except:
        pass

    try:
        model = getattr(unit, 'model', None)
        if model and hasattr(model, 'get_bone_pos'):
            bone_pos = model.get_bone_pos(bone_name)
            if bone_pos:
                return bone_pos
    except:
        pass
    return None

def _vec3_to_list(vec):
    try:
        return [float(vec.x), float(vec.y), float(vec.z)]
    except:
        return [0.0, 0.0, 0.0]

def _get_special_unit_skill_ids(unit):
    result = []
    try:
        skill_mgr = getattr(unit, 'ref_skill_mgr', getattr(unit, 'skill_mgr', None))
        if skill_mgr:
            skill_dict = getattr(skill_mgr, 'skill_dct', getattr(skill_mgr, 'skill_dict', None))
            if skill_dict:
                try:
                    result = [str(key) for key in list(skill_dict.keys())]
                except:
                    result = []
    except:
        pass
    result = sorted([item for item in result if item])
    return result[:16]

def collect_special_units_data():
    payload = {
        "type": "special_units",
        "valid": False,
        "units": []
    }
    try:
        player = getattr(GK, 'g_unit', None)
        unit_mgr = get_available_unit_mgr()
        if not unit_mgr:
            return json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(',', ':'))

        include_debug_details = _hook_special_units_need_debug_details()
        units = []
        for unit_type, type_name in SPECIAL_UNIT_TYPE_NAMES.items():
            try:
                found_units = safe_get_units_by_type_from_mgr(unit_mgr, unit_type)
            except:
                found_units = []

            for unit in found_units:
                uid_text = get_player_uid(unit) if unit else "unknown"
                entry = {
                    "key": str(unit_type) + ":" + uid_text,
                    "uid": uid_text,
                    "unit_type": int(unit_type),
                    "unit_type_name": type_name,
                    "real_uid": "",
                    "pos_valid": False,
                    "pos": [0.0, 0.0, 0.0]
                }

                try:
                    if unit and hasattr(unit, 'get_position3'):
                        pos = unit.get_position3()
                        if pos:
                            entry["pos"] = _vec3_to_list(pos)
                            entry["pos_valid"] = True
                except:
                    pass

                if unit_type == 218:
                    entry["real_uid"] = _safe_uid_text(getattr(unit, 'out_photo_uid', None))

                if include_debug_details:
                    try:
                        pelvis = _get_unit_bone_pos(unit)
                        if pelvis:
                            entry["pelvis"] = _vec3_to_list(pelvis)
                            entry["pelvis_valid"] = True
                    except:
                        pass

                    entry["skill_ids"] = _get_special_unit_skill_ids(unit)
                units.append(entry)

        payload["units"] = units
        payload["valid"] = len(units) > 0
    except Exception as e:
        payload["error"] = str(e)

    return json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(',', ':'))

def collect_special_unit_bones_data():
    payload = {
        "type": "special_unit_bones",
        "valid": False,
        "data": {}
    }
    try:
        player = getattr(GK, 'g_unit', None)
        unit_mgr = get_available_unit_mgr()
        if not unit_mgr:
            return json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(',', ':'))

        for unit_type in SPECIAL_UNIT_BONE_TYPES:
            type_name = SPECIAL_UNIT_TYPE_NAMES.get(unit_type, str(unit_type))
            try:
                found_units = safe_get_units_by_type_from_mgr(unit_mgr, unit_type)
            except:
                found_units = []

            for unit in found_units:
                if not unit:
                    continue

                uid_text = get_player_uid(unit)
                key = str(unit_type) + ":" + uid_text
                entry = {
                    "uid": uid_text,
                    "unit_type": int(unit_type),
                    "unit_type_name": type_name,
                    "real_uid": "",
                    "bones": {}
                }
                if unit_type == 218:
                    entry["real_uid"] = _safe_uid_text(getattr(unit, 'out_photo_uid', None))

                for bone_name in TARGET_BONES:
                    try:
                        bone_pos = _get_unit_bone_pos(unit, bone_name)
                        if not bone_pos:
                            continue
                        entry["bones"][bone_name] = {
                            "world": _vec3_to_list(bone_pos),
                            "screen": [0, 0],
                            "visible": bool(check_bone_visibility(bone_pos))
                        }
                    except:
                        pass

                if entry["bones"]:
                    payload["data"][key] = entry

        payload["valid"] = len(payload["data"]) > 0
    except Exception as e:
        payload["error"] = str(e)

    return json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(',', ':'))

def collect_knight_prediction_data():
    knight_data = {
        "type": "knight_predictions",
        "valid": False,
        "predictions": []
    }
    try:
        if not hasattr(GK, 'g_unit') or not GK.g_unit:
            return json.dumps(knight_data)

        room = getattr(GK.g_unit, 'room', None)
        if not room:
            return json.dumps(knight_data)

        prophet_mgr = getattr(room, 'prophet_mgr', None)
        if not prophet_mgr:
            return json.dumps(knight_data)

        behavior_info = getattr(prophet_mgr, 'behavior_info', {})
        if behavior_info is None:
            return json.dumps(knight_data)

        ACTION_MAP = {
            512: "