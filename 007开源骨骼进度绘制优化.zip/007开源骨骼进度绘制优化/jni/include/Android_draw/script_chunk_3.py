"
                }
            except:
                state["hook_state_map"] = {}
        seen_runtime_keys = set()
        panel_unit_type = getattr(getattr(ComuKeys, 'UNIT_TYPE_CONF', None), 'PANEL', None)
        hook_unit_type = getattr(getattr(ComuKeys, 'UNIT_TYPE_CONF', None), 'HOOK', None)
        wood_unit_type = getattr(getattr(ComuKeys, 'UNIT_TYPE_CONF', None), 'WOOD', None)
        for mgr in manager_candidates:
            _append_unique_panel_runtime_items(state["items"], "panel", safe_get_units_from_mgr(mgr, 'get_panel_units'), seen_runtime_keys)
            _append_unique_panel_runtime_items(state["items"], "chair", safe_get_units_from_mgr(mgr, 'get_hook_units'), seen_runtime_keys)
            if hook_unit_type is not None:
                _append_unique_panel_runtime_items(state["items"], "chair", safe_get_units_by_type_from_mgr(mgr, hook_unit_type), seen_runtime_keys)
            _append_unique_panel_runtime_items(state["items"], "window", safe_get_units_from_mgr(mgr, 'get_wood_units'), seen_runtime_keys)
            if wood_unit_type is not None:
                _append_unique_panel_runtime_items(state["items"], "window", safe_get_units_by_type_from_mgr(mgr, wood_unit_type), seen_runtime_keys)
    except Exception as e:
        panel_data["error"] = str(e)

def _append_incremental_panel_item(result, item_kind, item_obj, state):
    try:
        if item_kind == "panel":
            uid_text = str(getattr(item_obj, 'uid', '