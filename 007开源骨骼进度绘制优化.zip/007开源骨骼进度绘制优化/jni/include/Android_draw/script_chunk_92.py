"
    return _get_goldrush_quality_label(quality_value)

def _get_goldrush_monster_type_name(monster_type):
    return GOLDRUSH_MONSTER_TYPE_NAMES.get(_safe_int(monster_type, -1), "")

def _get_goldrush_room_type_name(room_type):
    return GOLDRUSH_ROOM_TYPE_NAMES.get(_safe_int(room_type, -1), "")

def _get_goldrush_monster_cfg(monster_id):
    for table_name in ('goldrush_monster_data', 'goldrush_monster'):
        cfg = _get_dm_row(table_name, monster_id)
        if cfg:
            return cfg
    return {}

def _collect_numeric_values(value, output=None):
    if output is None:
        output = set()
    if value is None or isinstance(value, bool):
        return output
    if isinstance(value, (int, float)):
        output.add(int(value))
        return output
    if isinstance(value, dict):
        for child in value.values():
            _collect_numeric_values(child, output)
        return output
    if isinstance(value, (list, tuple, set)):
        for child in value:
            _collect_numeric_values(child, output)
        return output
    text = _safe_uid_text(value)
    if text:
        try:
            output.add(int(text))
        except:
            pass
    return output

def _extract_text_entries(value, include_dict_keys=False):
    if value is None:
        return []
    items = []
    if isinstance(value, dict):
        if include_dict_keys:
            items.extend(list(value.keys()))
        items.extend(list(value.values()))
    else:
        items.extend(_iter_values(value))
    results = []
    seen = set()
    for raw in items:
        try:
            text = _safe_uid_text(raw)
        except:
            text = ""
        if not text or text in seen:
            continue
        seen.add(text)
        results.append(text)
    return results

def _normalize_voxel_key(value):
    if value is None:
        return None
    if isinstance(value, dict):
        for key_names in (('x', 'y', 'z'), ('row', 'col', 'floor'), ('i', 'j', 'k')):
            if all(key in value for key in key_names[:2]):
                return (
                    _safe_int(value.get(key_names[0], 0), 0),
                    _safe_int(value.get(key_names[1], 0), 0),
                    _safe_int(value.get(key_names[2], 0), 0)
                )
        return None
    if isinstance(value, (list, tuple)):
        if len(value) >= 2:
            return (
                _safe_int(value[0], 0),
                _safe_int(value[1], 0),
                _safe_int(value[2], 0) if len(value) >= 3 else 0
            )
        return None
    for attr_names in (('x', 'y', 'z'), ('row', 'col', 'floor'), ('i', 'j', 'k')):
        if hasattr(value, attr_names[0]) and hasattr(value, attr_names[1]):
            return (
                _safe_int(getattr(value, attr_names[0], 0), 0),
                _safe_int(getattr(value, attr_names[1], 0), 0),
                _safe_int(getattr(value, attr_names[2], 0), 0)
            )
    return None

def _get_goldrush_maze_system(combat_core):
    try:
        from common_cs.combat_core.enum_types.SystemType import SystemType
        if combat_core and hasattr(combat_core, 'get_system'):
            return combat_core.get_system(SystemType.MazeMapGeneration)
    except:
        pass
    return None

def _extract_goldrush_side_door_room_indexes(maze_system, rooms):
    side_room_indexes = set()
    if not maze_system:
        return side_room_indexes
    side_door_path = getattr(maze_system, 'side_door_path', None)
    if not side_door_path:
        side_door_path = getattr(getattr(maze_system, 'owner', None), 'side_door_path', None)
    if not side_door_path:
        return side_room_indexes
    voxel_to_room_indexes = {}
    for room in _iter_values(rooms):
        room_index = _safe_int(getattr(room, 'room_index', getattr(room, 'index', -1)), -1)
        if room_index < 0:
            continue
        for voxel in _iter_values(getattr(room, 'voxels', None)):
            voxel_key = _normalize_voxel_key(voxel)
            if voxel_key is None:
                continue
            room_set = voxel_to_room_indexes.setdefault(voxel_key, set())
            room_set.add(room_index)
    for path_nodes in _iter_values(side_door_path):
        nodes = _iter_values(path_nodes)
        if not nodes:
            continue
        probe_nodes = [nodes[0]]
        if len(nodes) > 1:
            probe_nodes.append(nodes[-1])
        for node in probe_nodes:
            voxel_key = _normalize_voxel_key(node)
            if voxel_key is None:
                continue
            for room_index in voxel_to_room_indexes.get(voxel_key, ()):
                side_room_indexes.add(room_index)
    return side_room_indexes

def _extract_goldrush_room_group_names(room):
    names = []
    seen = set()
    holders = (
        room,
        getattr(room, 'room_data', None),
        getattr(room, 'scene_data', None),
        getattr(room, 'cfg', None),
        getattr(room, 'room_cfg', None)
    )
    for holder in holders:
        if not holder:
            continue
        for text in _extract_text_entries(getattr(holder, 'group_names', None)):
            if text in seen:
                continue
            seen.add(text)
            names.append(text)
    return names

def _extract_goldrush_room_model_names(room):
    names = []
    seen = set()
    holders = (
        room,
        getattr(room, 'room_data', None),
        getattr(room, 'scene_data', None),
        getattr(room, 'cfg', None),
        getattr(room, 'room_cfg', None)
    )
    for holder in holders:
        if not holder:
            continue
        for text in _extract_text_entries(getattr(holder, 'model_name_to_data', None), include_dict_keys=True):
            if text in seen:
                continue
            seen.add(text)
            names.append(text)
    return names

def _extract_goldrush_interact_condition_entries(template_id):
    entries = []
    table = _get_dm_table('goldrush_interact_condition')
    for raw_key, cfg in table.items():
        try:
            if not isinstance(cfg, dict):
                continue
            row_id = _safe_int(cfg.get('id', raw_key), _safe_int(raw_key, -1))
            if row_id <= 0 or int(row_id / 100) != _safe_int(template_id, -1):
                continue
            params = cfg.get('params', {})
            item_ids = sorted(item_id for item_id in _collect_numeric_values(params) if item_id > 0)
            entries.append({
                "id": row_id,
                "condition_type": _safe_int(cfg.get('condition_type', -1), -1),
                "start_state": _safe_int(cfg.get('start_state', -1), -1),
                "item_ids": item_ids,
                "raw_params": _safe_uid_text(params) if not isinstance(params, (dict, list, tuple, set)) else ""
            })
        except:
            pass
    entries.sort(key=lambda item: item.get("id", 0))
    return entries

def _extract_goldrush_interact_effect_entries(template_id):
    entries = []
    table = _get_dm_table('goldrush_interact_effect')
    for raw_key, cfg in table.items():
        try:
            if not isinstance(cfg, dict):
                continue
            row_id = _safe_int(cfg.get('id', raw_key), _safe_int(raw_key, -1))
            interact_type_id = _safe_int(cfg.get('interact_type_id', -1), -1)
            if interact_type_id != _safe_int(template_id, -1):
                continue
            params = cfg.get('params', {})
            item_ids = sorted(item_id for item_id in _collect_numeric_values(params) if item_id > 0)
            entries.append({
                "id": row_id,
                "effect_type": _safe_uid_text(cfg.get('effect_type', '')),
                "start_state": _safe_int(cfg.get('start_state', -1), -1),
                "target": _safe_uid_text(cfg.get('target', '')),
                "target_state": _safe_int(cfg.get('target_state', -1), -1),
                "item_ids": item_ids,
                "raw_params": _safe_uid_text(params) if not isinstance(params, (dict, list, tuple, set)) else ""
            })
        except:
            pass
    entries.sort(key=lambda item: item.get("id", 0))
    return entries

def _build_goldrush_interact_chain_info(template_id):
    condition_entries = _extract_goldrush_interact_condition_entries(template_id)
    effect_entries = _extract_goldrush_interact_effect_entries(template_id)
    required_item_ids = []
    produced_item_ids = []
    seen_required = set()
    seen_produced = set()
    for entry in condition_entries:
        for item_id in entry.get("item_ids", []):
            if item_id <= 0 or item_id in seen_required:
                continue
            seen_required.add(item_id)
            required_item_ids.append(item_id)
    for entry in effect_entries:
        for item_id in entry.get("item_ids", []):
            if item_id <= 0 or item_id in seen_produced:
                continue
            seen_produced.add(item_id)
            produced_item_ids.append(item_id)
    return {
        "condition_entries": condition_entries,
        "effect_entries": effect_entries,
        "required_item_ids": required_item_ids,
        "produced_item_ids": produced_item_ids
    }

def _get_goldrush_item_names(item_ids):
    names = []
    for item_id in item_ids or []:
        cfg = _get_goldrush_item_cfg(item_id)
        name_tid = _safe_uid_text(cfg.get('name', cfg.get('g_name', '')))
        names.append({
            "item_id": item_id,
            "name_tid": name_tid,
            "name": _resolve_tid_text(name_tid)
        })
    return names

def _serialize_voxel_list(value, limit=128):
    result = []
    for voxel in _iter_values(value):
        voxel_key = _normalize_voxel_key(voxel)
        if voxel_key is None:
            continue
        result.append([int(voxel_key[0]), int(voxel_key[1]), int(voxel_key[2])])
        if len(result) >= limit:
            break
    return result

def _serialize_path_list(value, path_limit=16, node_limit=16):
    result = []
    for path_nodes in _iter_values(value):
        nodes = []
        for node in _iter_values(path_nodes):
            voxel_key = _normalize_voxel_key(node)
            if voxel_key is None:
                continue
            nodes.append([int(voxel_key[0]), int(voxel_key[1]), int(voxel_key[2])])
            if len(nodes) >= node_limit:
                break
        if nodes:
            result.append(nodes)
        if len(result) >= path_limit:
            break
    return result

def _serialize_path_wall_infos(value, limit=24):
    result = []
    for item in _iter_values(value):
        entry = {"raw": _safe_uid_text(item)}
        if isinstance(item, (list, tuple)):
            if len(item) >= 1:
                entry["model_name"] = _safe_uid_text(item[0])
            if len(item) >= 2:
                if isinstance(item[1], (list, tuple, set)):
                    doorway_cfg_ids = []
                    for cfg_id in item[1]:
                        cfg_id_value = _safe_int(cfg_id, -1)
                        if cfg_id_value > 0:
                            doorway_cfg_ids.append(cfg_id_value)
                    entry["doorway_cfg_ids"] = doorway_cfg_ids
                    entry["doorway_cfg_id"] = doorway_cfg_ids[0] if doorway_cfg_ids else -1
                else:
                    entry["doorway_cfg_id"] = _safe_int(item[1], -1)
                    entry["doorway_cfg_ids"] = [entry["doorway_cfg_id"]] if entry["doorway_cfg_id"] > 0 else []
        result.append(entry)
        if len(result) >= limit:
            break
    return result

def _build_room_voxel_bounds(voxel_points):
    if not voxel_points:
        return {}
    xs = [point[0] for point in voxel_points]
    ys = [point[1] for point in voxel_points]
    zs = [point[2] for point in voxel_points]
    return {
        "min": [min(xs), min(ys), min(zs)],
        "max": [max(xs), max(ys), max(zs)],
        "size": [max(xs) - min(xs) + 1, max(ys) - min(ys) + 1, max(zs) - min(zs) + 1]
    }

def _build_room_outline_segments(voxel_points, limit=96):
    cells = set()
    for point in voxel_points:
        if isinstance(point, (list, tuple)) and len(point) >= 3:
            cells.add((int(point[0]), int(point[1]), int(point[2])))
    if not cells:
        return []
    segments = []
    for cell_x, cell_floor, cell_z in sorted(cells):
        checks = (
            ((-1, 0), [cell_x, cell_floor, cell_z], [cell_x, cell_floor, cell_z + 1]),
            ((1, 0), [cell_x + 1, cell_floor, cell_z], [cell_x + 1, cell_floor, cell_z + 1]),
            ((0, -1), [cell_x, cell_floor, cell_z], [cell_x + 1, cell_floor, cell_z]),
            ((0, 1), [cell_x, cell_floor, cell_z + 1], [cell_x + 1, cell_floor, cell_z + 1])
        )
        for offset, start_point, end_point in checks:
            neighbor = (cell_x + offset[0], cell_floor, cell_z + offset[1])
            if neighbor in cells:
                continue
            segments.append({
                "from": start_point,
                "to": end_point,
                "floor": cell_floor
            })
            if len(segments) >= limit:
                return segments
    return segments

def _get_direction_heading_info(direction_vec):
    vec = direction_vec if isinstance(direction_vec, (list, tuple)) else _vec3_to_list(direction_vec)
    if not isinstance(vec, (list, tuple)) or len(vec) < 3:
        return {"yaw_deg": 0.0, "axis": "", "label": ""}
    x_value = _safe_float(vec[0], 0.0)
    z_value = _safe_float(vec[2], 0.0)
    if abs(x_value) < 1e-6 and abs(z_value) < 1e-6:
        return {"yaw_deg": 0.0, "axis": "", "label": ""}
    yaw_deg = math.degrees(math.atan2(z_value, x_value))
    if abs(x_value) >= abs(z_value):
        axis = "X+" if x_value >= 0 else "X-"
    else:
        axis = "Z+" if z_value >= 0 else "Z-"
    label_map = {"X+": "+X", "X-": "-X", "Z+": "+Z", "Z-": "-Z"}
    return {"yaw_deg": yaw_deg, "axis": axis, "label": label_map.get(axis, axis)}

def _make_math3d_vector3(pos):
    if not isinstance(pos, (list, tuple)) or len(pos) < 3:
        return None
    try:
        import math3d
        vector_ctor = getattr(math3d, 'Vector3', None)
        if vector_ctor is None:
            vector_ctor = getattr(math3d, 'vector', None)
        if vector_ctor is None:
            return None
        return vector_ctor(float(pos[0]), float(pos[1]), float(pos[2]))
    except:
        return None

def _world_to_screen_point(world_pos):
    result = {
        "valid": False,
        "raw": [0.0, 0.0],
        "design": [0.0, 0.0],
        "visible": False
    }
    try:
        if not hasattr(GK, 'g_world_mgr') or not GK.g_world_mgr or not GK.g_world_mgr.cur_world:
            return result
        cam = getattr(GK.g_world_mgr.cur_world, 'cam', None)
        if not cam or not hasattr(cam, 'world_to_screen'):
            return result
        vector_pos = _make_math3d_vector3(world_pos)
        if not vector_pos:
            return result
        raw_x, raw_y = cam.world_to_screen(vector_pos)
        raw_x = float(raw_x)
        raw_y = float(raw_y)
        screen_size = getattr(GK, 'g_screen_size', None) or ()
        design_size = getattr(GK, 'g_design_size', None) or ()
        screen_w = float(screen_size[0]) if isinstance(screen_size, (list, tuple)) and len(screen_size) >= 2 and float(screen_size[0] or 0.0) > 0 else 0.0
        screen_h = float(screen_size[1]) if isinstance(screen_size, (list, tuple)) and len(screen_size) >= 2 and float(screen_size[1] or 0.0) > 0 else 0.0
        design_w = float(design_size[0]) if isinstance(design_size, (list, tuple)) and len(design_size) >= 2 and float(design_size[0] or 0.0) > 0 else screen_w
        design_h = float(design_size[1]) if isinstance(design_size, (list, tuple)) and len(design_size) >= 2 and float(design_size[1] or 0.0) > 0 else screen_h
        design_x = raw_x * design_w / screen_w if screen_w > 0 else raw_x
        design_y = design_h - raw_y * design_h / screen_h if screen_h > 0 else raw_y
        result = {
            "valid": True,
            "raw": [round(raw_x, 2), round(raw_y, 2)],
            "design": [round(design_x, 2), round(design_y, 2)],
            "visible": bool(screen_w > 0 and screen_h > 0 and 0.0 <= raw_x <= screen_w and 0.0 <= raw_y <= screen_h)
        }
    except:
        pass
    return result

def _build_screen_polyline(points, limit=128):
    result = {
        "raw_points": [],
        "design_points": [],
        "raw_segments": [],
        "design_segments": [],
        "visible_point_count": 0
    }
    last_raw = None
    last_design = None
    for world_pos in points or []:
        screen_point = _world_to_screen_point(world_pos)
        if not screen_point.get("valid"):
            last_raw = None
            last_design = None
            continue
        raw_point = list(screen_point.get("raw", [0.0, 0.0]))
        design_point = list(screen_point.get("design", [0.0, 0.0]))
        result["raw_points"].append(raw_point)
        result["design_points"].append(design_point)
        if screen_point.get("visible"):
            result["visible_point_count"] += 1
            if last_raw is not None:
                result["raw_segments"].append({"from": list(last_raw), "to": list(raw_point)})
            if last_design is not None:
                result["design_segments"].append({"from": list(last_design), "to": list(design_point)})
            last_raw = raw_point
            last_design = design_point
        else:
            last_raw = None
            last_design = None
        if len(result["raw_points"]) >= limit:
            break
    return result

def _goldrush_voxel_point_to_world(point, anchor='base'):
    if not isinstance(point, (list, tuple)) or len(point) < 3:
        return [0.0, 0.0, 0.0]
    voxel_x = _safe_float(point[0], 0.0)
    voxel_floor = _safe_float(point[1], 0.0)
    voxel_z = _safe_float(point[2], 0.0)
    world_x = voxel_x * GOLDRUSH_VOXEL_SIZE_X + GOLDRUSH_WORLD_OFFSET_X
    world_y = voxel_floor * GOLDRUSH_VOXEL_SIZE_Y
    world_z = voxel_z * GOLDRUSH_VOXEL_SIZE_Z
    if anchor == 'center':
        world_x += GOLDRUSH_VOXEL_SIZE_X * 0.5
        world_y += GOLDRUSH_VOXEL_SIZE_Y * 0.5
        world_z += GOLDRUSH_VOXEL_SIZE_Z * 0.5
    elif anchor == 'floor':
        world_x += GOLDRUSH_VOXEL_SIZE_X * 0.5
        world_z += GOLDRUSH_VOXEL_SIZE_Z * 0.5
    return [round(world_x, 2), round(world_y, 2), round(world_z, 2)]

def _build_world_segments_from_outline(outline_segments, limit=128):
    result = []
    for segment in outline_segments or []:
        result.append({
            "from": _goldrush_voxel_point_to_world(segment.get('from', []), 'base'),
            "to": _goldrush_voxel_point_to_world(segment.get('to', []), 'base'),
            "floor": _safe_int(segment.get('floor', 0), 0)
        })
        if len(result) >= limit:
            break
    return result

def _build_world_path_segments(path_points, limit=128):
    result = []
    for path_index, path_nodes in enumerate(path_points or []):
        nodes = list(path_nodes or [])
        if len(nodes) < 2:
            continue
        for node_index in range(len(nodes) - 1):
            result.append({
                "path_index": path_index,
                "from": _goldrush_voxel_point_to_world(nodes[node_index], 'floor'),
                "to": _goldrush_voxel_point_to_world(nodes[node_index + 1], 'floor')
            })
            if len(result) >= limit:
                return result
    return result

def _build_world_doorway_segments(path_points, path_wall_infos, limit=64):
    result = []
    for path_index, path_nodes in enumerate(path_points or []):
        nodes = list(path_nodes or [])
        if len(nodes) < 2:
            continue
        wall_info = path_wall_infos[path_index] if path_index < len(path_wall_infos or []) else {}
        doorway_cfg_ids = list((wall_info or {}).get('doorway_cfg_ids', []))
        doorway_entries = []
        for cfg_id in doorway_cfg_ids:
            cfg = _get_dm_row('goldrush_doorway_configs', cfg_id)
            doorway_entries.append({
                "id": cfg_id,
                "model": _safe_uid_text(cfg.get('model', '')),
                "theme": _safe_uid_text(cfg.get('theme', ''))
            })
        result.append({
            "path_index": path_index,
            "model_name": _safe_uid_text((wall_info or {}).get('model_name', '')),
            "doorway_cfg_ids": doorway_cfg_ids,
            "doorway_entries": doorway_entries,
            "from": _goldrush_voxel_point_to_world(nodes[0], 'floor'),
            "to": _goldrush_voxel_point_to_world(nodes[-1], 'floor')
        })
        if len(result) >= limit:
            break
    return result

def _serialize_runtime_vec_points(value, limit=128):
    points = []
    for raw in _iter_values(value):
        try:
            if isinstance(raw, (list, tuple)) and len(raw) >= 3:
                points.append([float(raw[0]), float(raw[1]), float(raw[2])])
            else:
                points.append(_vec3_to_list(raw))
        except:
            pass
        if len(points) >= limit:
            break
    return points

def _collect_goldrush_guideline_runtime(player):
    result = {}
    if not player:
        return result
    try:
        comp = _get_holder_component_by_keyword(
            player,
            'UnitComponentType',
            'GoldRushGuideLineTrail',
            'guidelinetrail',
            ('guide_line_trail_comp', 'guideline_trail_comp', 'ref_guideline_trail_comp')
        )
        if not comp:
            return result
        display_path = []
        try:
            if hasattr(comp, 'get_display_path'):
                display_path = _serialize_runtime_vec_points(comp.get_display_path(), 128)
        except:
            display_path = []
        path_points = _serialize_runtime_vec_points(getattr(comp, 'path_points', None), 128)
        result = {
            "component_name": type(comp).__name__,
            "target_pos": _vec3_to_list(getattr(comp, 'target_pos', None)),
            "player_pos": _vec3_to_list(getattr(comp, 'player_pos', None)),
            "path_points": path_points,
            "display_path": display_path,
            "smooth_points": _serialize_runtime_vec_points(getattr(comp, '_smooth_points', None), 128),
            "screen_polyline": _build_screen_polyline(display_path or path_points, 128),
            "head_distance": _safe_float(getattr(comp, 'head_distance', 0.0), 0.0),
            "is_finished": bool(getattr(comp, 'is_finished', False))
        }
    except:
        result = {}
    return result

def _collect_goldrush_minimap_icons(combat_core):
    icons = []
    try:
        from common_cs.combat_core.enum_types.SystemType import SystemType
        stash_system = combat_core.get_system(SystemType.GoldRushMinimapStash) if combat_core and hasattr(combat_core, 'get_system') else None
    except:
        stash_system = None
    if not stash_system:
        return icons
    raw_icons = getattr(stash_system, '_icons', None)
    for raw_icon in _iter_values(raw_icons):
        try:
            if not isinstance(raw_icon, dict):
                continue
            settings = raw_icon.get('settings', {})
            icons.append({
                "type": _safe_uid_text(raw_icon.get('type', '')),
                "world_position": _vec3_to_list(raw_icon.get('world_position', None)),
                "icon_path": _safe_uid_text(raw_icon.get('icon_path', '')),
                "text": _safe_uid_text(raw_icon.get('text', '')),
                "key": _safe_uid_text(raw_icon.get('key', '')),
                "settings": _safe_uid_text(settings) if not isinstance(settings, dict) else {
                    "floor": _safe_int(settings.get('floor', -1), -1),
                    "area": _safe_uid_text(settings.get('area', '')),
                    "uid": _safe_uid_text(settings.get('uid', ''))
                }
            })
        except:
            pass
    return icons

def _classify_reward_box_kind(model_name, config_model_path=""):
    text = (_safe_uid_text(model_name) + "|" + _safe_uid_text(config_model_path)).lower()
    if 'vase' in text:
        return "