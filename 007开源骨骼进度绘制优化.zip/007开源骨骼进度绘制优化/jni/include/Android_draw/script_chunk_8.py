')),
                "pos": [float(getattr(pos, 'x', 0.0) or 0.0), float(getattr(pos, 'y', 0.0) or 0.0), float(getattr(pos, 'z', 0.0) or 0.0)],
                "direction": [float(getattr(dir_vec, 'x', 0.0) or 0.0), float(getattr(dir_vec, 'y', 0.0) or 0.0), float(getattr(dir_vec, 'z', 0.0) or 0.0)]
            })
    except:
        pass

def _run_incremental_panel_collector(loop_now=None, start_new=False):
    state = INCREMENTAL_COLLECTOR_STATE.get("panels", {})
    if start_new or not state.get("active"):
        _start_incremental_panel_collector()
        state = INCREMENTAL_COLLECTOR_STATE.get("panels", {})
    result = state.get("result") or _build_panel_payload_base()
    items = state.get("items", []) or []
    index = int(state.get("index", 0) or 0)
    chunk_size = 2 if state.get("need_chair_runtime") else INCREMENTAL_PANEL_CHUNK_SIZE
    end_index = min(len(items), index + chunk_size)
    for current_index in range(index, end_index):
        item_kind, item_obj = items[current_index]
        _append_incremental_panel_item(result, item_kind, item_obj, state)
    state["index"] = end_index
    state["result"] = result
    if end_index >= len(items):
        if state.get("include_static_panels") and state.get("panel_context", {}).get("in_battle", False):
            PANEL_RUNTIME_CACHE["scene_id"] = _safe_int(state.get("panel_context", {}).get("scene_id", -1), -1)
            PANEL_RUNTIME_CACHE["world_type"] = _safe_int(state.get("panel_context", {}).get("world_type", -1), -1)
            PANEL_RUNTIME_CACHE["in_battle"] = True
            PANEL_RUNTIME_CACHE["static_panels"] = list(result.get("static_panels", []) or [])
        result["panels"].sort(key=lambda item: item.get("uid", ""))
        if "static_panels" in result and isinstance(result["static_panels"], list):
            result["static_panels"].sort(key=lambda item: item.get("uid", ""))
        result["chairs"].sort(key=lambda item: item.get("uid", ""))
        result["windows"].sort(key=lambda item: item.get("uid", ""))
        result["valid"] = bool(result["panels"] or result["chairs"] or result["windows"])
        payload = json.dumps(result, ensure_ascii=False, sort_keys=True, separators=(',', ':'))
        _reset_incremental_collector("panels")
        return payload
    return None

def collect_panel_data():
    payload = None
    try:
        payload = _run_incremental_panel_collector(None, True)
        while payload is None and _incremental_collector_active("panels"):
            payload = _run_incremental_panel_collector(None, False)
    except:
        payload = None
    return payload or json.dumps(_build_panel_payload_base(), ensure_ascii=False, sort_keys=True, separators=(',', ':'))

def get_item_type(item):
    """