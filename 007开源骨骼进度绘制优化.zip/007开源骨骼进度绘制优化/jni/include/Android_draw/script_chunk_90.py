: {len(copycat_players)}")
                    for uid_text, player in copycat_players:
                        try:
                            combat_unit = None
                            if ref_unit_mgr and hasattr(ref_unit_mgr, 'get_unit'):
                                try:
                                    combat_unit = ref_unit_mgr.get_unit(getattr(player, 'uid', None) or uid_text)
                                except:
                                    combat_unit = None
                            identity_id, camp_id, idx = _get_copycat_identity_numbers(player, combat_unit)
                            if identity_id <= 0:
                                continue
                            pos = player.get_position3() if hasattr(player, 'get_position3') else getattr(player, 'position', None)
                            if not pos:
                                continue
                            if idx <= 0:
                                idx = 0
                            results.append(f"Copycat [UID:{uid_text},ID:{identity_id},Camp:{camp_id},Idx:{idx},X:{pos.x:.1f},Y:{pos.y:.1f},Z:{pos.z:.1f}]")
                        except:
                            pass
            except:
                pass


    except Exception as e:
        results.append(f"Error: {str(e)}")
    
    return results

def _normalize_uid_collection(value):
    items = []
    try:
        if isinstance(value, dict):
            iterator = value.keys()
        elif isinstance(value, (set, list, tuple)):
            iterator = value
        else:
            return items

        for entry in iterator:
            if entry is None:
                continue
            text = str(entry)
            if not text:
                continue
            items.append(text)
    except:
        return []

    items = sorted(set(items))
    return items

def _safe_int(value, default_value=-1):
    try:
        return int(value)
    except:
        return default_value

def _safe_bool(value):
    try:
        return bool(value)
    except:
        return False

def _safe_float(value, default_value=0.0):
    try:
        return float(value)
    except:
        return default_value

def _safe_uid_text(value):
    if value is None:
        return ""
    try:
        text = str(value)
        return text if text else ""
    except:
        return ""

GOLDRUSH_LEVEL_REFERENCE = [
    {"level": 100, "map_config_id": 100, "outdoor_id": 10101, "camp_id": 10401, "alchemy_box_limit": [0, 0], "scene_panel_limit": 0, "tresure_room_id": 11001, "tresure_room_rate": 0.0},
    {"level": 101, "map_config_id": 101, "outdoor_id": 10101, "camp_id": 10401, "alchemy_box_limit": [1, 1], "scene_panel_limit": 4, "tresure_room_id": 11001, "tresure_room_rate": 0.1},
    {"level": 102, "map_config_id": 102, "outdoor_id": 10101, "camp_id": 10401, "alchemy_box_limit": [3, 3], "scene_panel_limit": 6, "tresure_room_id": 11001, "tresure_room_rate": 0.1},
    {"level": 103, "map_config_id": 103, "outdoor_id": 10101, "camp_id": 10401, "alchemy_box_limit": [4, 4], "scene_panel_limit": 10, "tresure_room_id": 11001, "tresure_room_rate": 0.1},
]

GOLDRUSH_SCENE_REFERENCE = {
    "default_level": 100,
    "scene_id": 2601,
    "scene_name_tid": "TID_SCENE_NAME_MOJIN_01",
    "scene_desc_tid": "TID_SCENE_DES_MOJIN_01",
    "outdoor_id": 10101,
    "camp_id": 10401
}

def _resolve_tid_text(value):
    text = _safe_uid_text(value)
    if not text:
        return ""
    try:
        if utils and text.startswith("TID_"):
            return utils.do_ui_tid_replace(text)
    except:
        pass
    return text

def _get_goldrush_item_data_table():
    try:
        dm = getattr(GK, 'DM', None)
        table = getattr(dm, 'goldrush_item_data', None) if dm else None
        if isinstance(table, dict):
            return table
    except:
        pass
    return {}

def _get_dm_table(table_name):
    try:
        dm = getattr(GK, 'DM', None)
        table = getattr(dm, table_name, None) if dm else None
        if isinstance(table, dict):
            return table
    except:
        pass
    return {}

def _get_dm_row(table_name, row_id):
    table = _get_dm_table(table_name)
    if not table:
        return {}
    for key in (row_id, _safe_uid_text(row_id)):
        try:
            if key in table:
                value = table.get(key)
                if isinstance(value, dict):
                    return value
        except:
            pass
    try:
        row_id_int = int(row_id)
        if row_id_int in table:
            value = table.get(row_id_int)
            if isinstance(value, dict):
                return value
    except:
        pass
    return {}

def _build_table_entries(table_name, field_names, id_key='id'):
    table = _get_dm_table(table_name)
    entries = []
    for raw_key, cfg in table.items():
        try:
            if not isinstance(cfg, dict):
                continue
            row_id = _safe_int(cfg.get(id_key, raw_key), _safe_int(raw_key, -1))
            entry = {"id": row_id}
            for field_name in field_names:
                value = cfg.get(field_name, None)
                if isinstance(value, (int, float, bool)) or value is None:
                    entry[field_name] = value
                else:
                    entry[field_name] = _safe_uid_text(value)
            entries.append(entry)
        except:
            pass
    entries.sort(key=lambda item: item.get("id", 0))
    return entries

def _get_goldrush_item_cfg(item_id):
    table = _get_goldrush_item_data_table()
    if not table:
        return {}
    try:
        if item_id in table:
            return table.get(item_id) or {}
    except:
        pass
    try:
        item_id_int = int(item_id)
        if item_id_int in table:
            return table.get(item_id_int) or {}
    except:
        pass
    try:
        item_id_str = str(item_id)
        if item_id_str in table:
            return table.get(item_id_str) or {}
    except:
        pass
    return {}

def _iter_values(value):
    if isinstance(value, dict):
        return list(value.values())
    if isinstance(value, (list, tuple, set)):
        return list(value)
    return []

def _collect_holder_item_objects(holder, output_list, seen_keys, depth=0):
    if not holder or depth > 2:
        return
    candidate_attrs = (
        'item_lst', 'items', 'item_list', 'item_data_list', 'item_dict', 'item_data_dict',
        'grid_item_dict', 'grid_items', 'bag_items', 'backpack_items', 'material_items'
    )
    child_attrs = (
        'grid_backpack', 'grid_materials', 'grid_tactical', 'backpack_grid',
        'material_grid', 'tactical_grid', 'bag_comp', 'ref_bag_comp'
    )
    for attr_name in candidate_attrs:
        try:
            value = getattr(holder, attr_name, None)
        except:
            value = None
        for item in _iter_values(value):
            if not item:
                continue
            unique_key = id(item)
            if unique_key in seen_keys:
                continue
            seen_keys.add(unique_key)
            output_list.append(item)
    for attr_name in child_attrs:
        try:
            child = getattr(holder, attr_name, None)
        except:
            child = None
        if child:
            _collect_holder_item_objects(child, output_list, seen_keys, depth + 1)

def _extract_goldrush_item_entry(item_obj):
    item_id = _safe_int(getattr(item_obj, 'item_id', getattr(item_obj, 'id', -1)), -1)
    if item_id <= 0:
        try:
            item_info = getattr(item_obj, 'item_info', None)
            if isinstance(item_info, dict):
                item_id = _safe_int(item_info.get('item_id', item_info.get('id', -1)), -1)
        except:
            item_id = -1
    if item_id <= 0:
        return None
    count = _safe_int(
        getattr(item_obj, 'item_num', getattr(item_obj, 'num', getattr(item_obj, 'count', getattr(item_obj, '_remain_use_times', 1)))),
        1
    )
    if count <= 0:
        count = 1
    durability = None
    try:
        remain_lifespan = getattr(item_obj, '_remain_lifespan', None)
        if remain_lifespan is not None:
            durability = round(float(remain_lifespan), 1)
    except:
        durability = None
    cfg = _get_goldrush_item_cfg(item_id)
    name_tid = _safe_uid_text(cfg.get('name', cfg.get('g_name', '')))
    name_text = _resolve_tid_text(name_tid)
    value = _safe_int(cfg.get('value', 0), 0)
    sold_price = _safe_int(cfg.get('sold_price', 0), 0)
    weight = _safe_float(cfg.get('weight', 0.0), 0.0)
    storage_type = _safe_int(cfg.get('storage_type', 0), 0)
    tag = _safe_uid_text(cfg.get('tag', ''))
    stack_limit = _safe_int(cfg.get('stack_limit', 0), 0)
    return {
        "item_id": item_id,
        "class_name": type(item_obj).__name__,
        "name_tid": name_tid,
        "name": name_text,
        "count": count,
        "value": value,
        "sold_price": sold_price,
        "weight": weight,
        "storage_type": storage_type,
        "tag": tag,
        "stack_limit": stack_limit,
        "durability": durability,
        "total_value": value * count,
        "total_sold_price": sold_price * count,
        "total_weight": round(weight * count, 1)
    }

def _collect_goldrush_self_items(me):
    items = []
    seen_keys = set()
    try:
        _collect_holder_item_objects(me, items, seen_keys, 0)
    except:
        pass
    entries = []
    seen_item_keys = set()
    for item_obj in items:
        entry = _extract_goldrush_item_entry(item_obj)
        if not entry:
            continue
        unique_key = (entry.get("item_id", -1), entry.get("count", 0), entry.get("durability", None), entry.get("class_name", ""))
        if unique_key in seen_item_keys:
            continue
        seen_item_keys.add(unique_key)
        entries.append(entry)
    entries.sort(key=lambda item: (-item.get("total_value", 0), item.get("item_id", 0)))
    return entries

def _get_holder_component_by_keyword(holder, enum_owner_name, enum_name, keyword, attr_candidates=()):
    if not holder:
        return None
    for attr_name in attr_candidates or ():
        try:
            comp = getattr(holder, attr_name, None)
            if comp:
                return comp
        except:
            pass
    if hasattr(holder, 'get_component'):
        try:
            enum_owner = globals().get(enum_owner_name, None)
            enum_value = getattr(enum_owner, enum_name, None) if enum_owner else None
            if enum_value is not None:
                comp = holder.get_component(enum_value)
                if comp:
                    return comp
        except:
            pass
        try:
            comp = holder.get_component(enum_name)
            if comp:
                return comp
        except:
            pass
    try:
        components = getattr(holder, 'components', None)
        if isinstance(components, dict):
            for comp_name, comp_obj in components.items():
                try:
                    text = f"{comp_name} {type(comp_obj)}"
                    if keyword.lower() in text.lower():
                        return comp_obj
                except:
                    pass
    except:
        pass
    for attr_name in dir(holder):
        try:
            if keyword.lower() not in attr_name.lower():
                continue
            comp = getattr(holder, attr_name, None)
            if comp:
                return comp
        except:
            pass
    return None

def _call_or_get(obj, attr_name, default=None):
    try:
        value = getattr(obj, attr_name, default)
        if callable(value):
            try:
                return value()
            except:
                return default
        return value
    except:
        return default

def _read_goldrush_health_state(unit):
    info = {"hp": -1.0, "max_hp": -1.0, "shield": 0.0, "stamina": -1.0, "max_stamina": -1.0, "game_state": -1, "is_alive": None, "is_dead": None}
    hp_comp = getattr(unit, 'ref_attribute_comp', None)
    if hp_comp and hasattr(hp_comp, 'get_attribute_value'):
        try:
            from common_cs.combat_core.attribute_sets.HealthSet import HealthSet
            info["hp"] = round(_safe_float(hp_comp.get_attribute_value(HealthSet.Hp), -1.0), 1)
            info["max_hp"] = round(_safe_float(hp_comp.get_attribute_value(HealthSet.MaxHp), -1.0), 1)
            info["shield"] = round(_safe_float(hp_comp.get_attribute_value(HealthSet.Shield), 0.0), 1)
        except:
            pass
        try:
            from common_cs.combat_core.attributes.goldrush.GoldRushSet import GoldRushSet
            info["stamina"] = round(_safe_float(hp_comp.get_attribute_value(GoldRushSet.Stamina), -1.0), 1)
            info["max_stamina"] = round(_safe_float(hp_comp.get_attribute_value(GoldRushSet.MaxStamina), -1.0), 1)
        except:
            pass
    stamina_comp = _get_holder_component_by_keyword(unit, 'UnitComponentType', 'Stamina', 'StaminaComponent', ('ref_stamina_comp', 'stamina_comp', 'stamina_component'))
    if stamina_comp:
        try:
            stamina_value = _call_or_get(stamina_comp, 'stamina', None)
            if stamina_value is not None:
                info["stamina"] = round(_safe_float(stamina_value, info["stamina"]), 1)
        except:
            pass
        try:
            max_stamina_value = _call_or_get(stamina_comp, 'max_stamina', None)
            if max_stamina_value is not None:
                info["max_stamina"] = round(_safe_float(max_stamina_value, info["max_stamina"]), 1)
        except:
            pass
    game_state_comp = getattr(unit, 'ref_game_state_comp', None)
    if not game_state_comp:
        game_state_comp = _get_holder_component_by_keyword(unit, 'UnitComponentType', 'GoldRushGameState', 'GameStateComponent', ('game_state_comp', 'ref_game_state_comp'))
    if game_state_comp:
        info["game_state"] = _safe_int(_call_or_get(game_state_comp, 'game_state', -1), -1)
        alive_value = _call_or_get(game_state_comp, 'is_alive', None)
        dead_value = _call_or_get(game_state_comp, 'is_dead', None)
        if alive_value is not None:
            info["is_alive"] = bool(alive_value)
        if dead_value is not None:
            info["is_dead"] = bool(dead_value)
    return info

def _extract_effect_show_component(effect_obj):
    if not effect_obj:
        return None
    for attr_name in ('effect_show_ui_comp', 'show_ui_comp', 'ui_comp', 'ref_show_ui_comp', 'effect_ui_comp'):
        try:
            comp = getattr(effect_obj, attr_name, None)
            if comp:
                return comp
        except:
            pass
    try:
        components = getattr(effect_obj, 'components', None)
        if isinstance(components, dict):
            for comp_name, comp_obj in components.items():
                try:
                    text = f"{comp_name} {type(comp_obj)}"
                    if 'effectshowuicomponent' in text.lower():
                        return comp_obj
                except:
                    pass
    except:
        pass
    return None

def _extract_goldrush_effect_entries(unit):
    effect_entries = []
    seen_effect_ids = set()
    buff_mgr = getattr(unit, 'buff_mgr', None)
    if buff_mgr:
        try:
            buff_dct = getattr(buff_mgr, 'buff_dct', None)
            iterator = list(buff_dct.items()) if buff_dct else []
        except:
            iterator = []
        if not iterator:
            try:
                raw_ids = getattr(buff_mgr, '_buff_list', None) or []
                iterator = [(raw_id, None) for raw_id in list(raw_ids)]
            except:
                iterator = []
        for raw_buff_id, buff_obj in iterator:
            buff_id_text = _safe_uid_text(raw_buff_id)
            if not buff_id_text or buff_id_text in seen_effect_ids:
                continue
            seen_effect_ids.add(buff_id_text)
            buff_name = ""
            left_time = None
            layer = None
            if buff_obj:
                try:
                    if utils and hasattr(utils, 'do_all_tid_replace') and hasattr(buff_obj, 'data') and hasattr(buff_obj, 'level'):
                        raw_name_tid = buff_obj.data[buff_obj.level].get('buff_name', '')
                        buff_name = _safe_uid_text(utils.do_all_tid_replace(raw_name_tid)) if raw_name_tid else ""
                except:
                    pass
                try:
                    left_time = round(_safe_float(getattr(buff_obj, 'left_time', 0.0), 0.0), 1)
                except:
                    left_time = None
                try:
                    layer = _safe_int(getattr(buff_obj, 'layer', 0), 0)
                except:
                    layer = None
            effect_entries.append({"effect_id": buff_id_text, "source": "buff_mgr", "name": buff_name, "remain_time": left_time, "layer": layer})
    effect_mgr = _get_holder_component_by_keyword(unit, 'EntityComponentType', 'GoldRushEffectManager', 'EffectManagerComponent', ('effect_mgr', 'ref_effect_mgr', 'effect_manager', 'ref_effect_manager'))
    if effect_mgr:
        effect_objects = []
        seen_objects = set()
        for attr_name in ('effect_dct', 'effect_dict', '_effect_dict', 'effects', '_effects', 'effect_list', '_effect_list'):
            try:
                value = getattr(effect_mgr, attr_name, None)
            except:
                value = None
            for effect_obj in _iter_values(value):
                if not effect_obj:
                    continue
                unique_key = id(effect_obj)
                if unique_key in seen_objects:
                    continue
                seen_objects.add(unique_key)
                effect_objects.append(effect_obj)
        for effect_obj in effect_objects:
            show_comp = _extract_effect_show_component(effect_obj)
            effect_id_text = _safe_uid_text(getattr(effect_obj, 'effect_id', getattr(effect_obj, 'id', getattr(effect_obj, '_effect_id', ''))))
            if not effect_id_text:
                effect_id_text = _safe_uid_text(id(effect_obj))
            unique_effect_key = f"effect:{effect_id_text}"
            if unique_effect_key in seen_effect_ids:
                continue
            seen_effect_ids.add(unique_effect_key)
            name_tid = ""
            desc_tid = ""
            icon_path = ""
            remain_time = None
            duration = None
            layer = None
            is_duration = None
            for holder in (show_comp, effect_obj):
                if not holder:
                    continue
                if not name_tid:
                    name_tid = _safe_uid_text(getattr(holder, 'name_tid', getattr(holder, '_name_tid', '')))
                if not desc_tid:
                    desc_tid = _safe_uid_text(getattr(holder, 'desc_tid', getattr(holder, '_desc_tid', '')))
                if not icon_path:
                    icon_path = _safe_uid_text(getattr(holder, 'icon_path', getattr(holder, '_icon_path', '')))
                if remain_time is None:
                    temp = getattr(holder, 'left_time', getattr(holder, 'remain_time', None))
                    if temp is not None:
                        remain_time = round(_safe_float(temp, 0.0), 1)
                if duration is None:
                    temp = getattr(holder, 'duration', getattr(holder, '_duration', None))
                    if temp is not None:
                        duration = round(_safe_float(temp, 0.0), 1)
                if layer is None:
                    temp = getattr(holder, 'layer', getattr(holder, '_layer', None))
                    if temp is not None:
                        layer = _safe_int(temp, 0)
                if is_duration is None:
                    temp = getattr(holder, 'is_duration', getattr(holder, '_is_duration', None))
                    if temp is not None:
                        is_duration = bool(temp)
            effect_entries.append({
                "effect_id": effect_id_text,
                "source": "effect_mgr",
                "name_tid": name_tid,
                "name": _resolve_tid_text(name_tid),
                "desc_tid": desc_tid,
                "desc": _resolve_tid_text(desc_tid),
                "icon_path": icon_path,
                "remain_time": remain_time,
                "duration": duration,
                "layer": layer,
                "is_duration": is_duration
            })
    effect_entries.sort(key=lambda item: (item.get("source", ""), item.get("effect_id", "")))
    return effect_entries

def _extract_entity_identity(unit):
    try:
        uid_value = getattr(unit, 'uid', None)
        if uid_value is not None:
            return _safe_uid_text(uid_value)
    except:
        pass
    return _safe_uid_text(id(unit))

def _extract_entity_position(unit):
    try:
        if hasattr(unit, 'get_position3'):
            pos = unit.get_position3()
            if pos:
                return pos
    except:
        pass
    for attr_name in ('position', '_position', 'pos', '_pos'):
        try:
            pos = getattr(unit, attr_name, None)
            if pos:
                return pos
        except:
            pass
    return None

def _extract_entity_direction(unit):
    for attr_name in ('direction', '_direction', 'forward', '_forward'):
        try:
            direction = getattr(unit, attr_name, None)
            if direction:
                return direction
        except:
            pass
    return None

def _extract_scan_info_dict(unit):
    scan_info = getattr(unit, '_scan_info', None)
    if isinstance(scan_info, dict):
        return scan_info
    return {}

def _safe_get_vec(holder, attr_name):
    try:
        value = getattr(holder, attr_name, None)
        if value:
            return _vec3_to_list(value)
    except:
        pass
    return [0.0, 0.0, 0.0]

def _iter_manager_units(unit_mgr):
    all_units = []
    seen_keys = set()
    if not unit_mgr:
        return all_units
    def append_from(value):
        for unit in _iter_values(value):
            if not unit:
                continue
            unique_key = id(unit)
            if unique_key in seen_keys:
                continue
            seen_keys.add(unique_key)
            all_units.append(unit)
    attr_names = ('unit_dict', 'player_dict', 'entity_dict', 'units', 'all_units', 'unit_dct', 'players', 'entities')
    for attr_name in attr_names:
        try:
            append_from(getattr(unit_mgr, attr_name, None))
        except:
            pass
    method_names = ('get_player_units', 'get_mode_player_units', 'get_generator_units', 'get_door_units', 'get_panel_units', 'get_hook_units', 'get_wood_units')
    for method_name in method_names:
        try:
            append_from(safe_get_units_from_mgr(unit_mgr, method_name))
        except:
            pass
    return all_units

def _extract_reward_box_entry(unit):
    scan_info = _extract_scan_info_dict(unit)
    box_id = _safe_int(getattr(unit, '_box_id', getattr(unit, 'box_id', -1)), -1)
    box_cfg = _get_dm_row('goldrush_reward_box', box_id)
    create_item_info = getattr(unit, '_create_item_info', None)
    if not isinstance(create_item_info, dict):
        create_item_info = {}
    return {
        "uid": _extract_entity_identity(unit),
        "class_name": type(unit).__name__,
        "pos": _vec3_to_list(_extract_entity_position(unit)),
        "scan_text": _resolve_tid_text(scan_info.get('text1', '')),
        "box_id": box_id,
        "box_type": _safe_int(getattr(unit, '_box_type', getattr(unit, 'box_type', box_cfg.get('box_type', -1))), -1),
        "reward_id": _safe_int(getattr(unit, 'reward_id', getattr(unit, '_reward_id', -1)), -1),
        "box_quality": _safe_int(getattr(unit, 'box_quality', getattr(unit, '_box_quality', -1)), -1),
        "box_level": _safe_int(getattr(unit, 'box_level', getattr(unit, '_box_level', -1)), -1),
        "class_level": _safe_int(getattr(unit, '_class_level', -1), -1),
        "display_item_quality": _safe_int(getattr(unit, '_display_item_quality', -1), -1),
        "gm_item_id": _safe_int(getattr(unit, '_gm_item_id', -1), -1),
        "gm_is_mega_gold": bool(getattr(unit, '_gm_is_mega_gold', False)),
        "gm_display_quality": _safe_int(getattr(unit, '_gm_display_quality', -1), -1),
        "override_reward_id": _safe_int(getattr(unit, '_override_reward_id', -1), -1),
        "ban_pre_open": bool(getattr(unit, '_ban_pre_open', False)),
        "room_index": _safe_int(getattr(unit, 'room_index', getattr(unit, '_room_index', -1)), -1),
        "model_name": _safe_uid_text(getattr(unit, 'model_name', getattr(unit, '_model_name', ''))),
        "config_box_anim_type": _safe_uid_text(box_cfg.get('box_anim_type', '')),
        "config_reward_id": _safe_int(box_cfg.get('reward_id', -1), -1),
        "config_box_quality": _safe_int(box_cfg.get('box_quality', -1), -1),
        "config_box_level": _safe_int(box_cfg.get('box_level', -1), -1),
        "drop_item_id": _safe_int(create_item_info.get('item_id', getattr(unit, '_gm_item_id', -1)), -1),
        "drop_item_num": _safe_int(create_item_info.get('num', 0), 0)
    }

def _extract_alchemy_box_entry(unit):
    scan_info = _extract_scan_info_dict(unit)
    box_data = getattr(unit, '_box_data', {}) or {}
    pending_result_items = [_safe_int(item, -1) for item in list(getattr(unit, '_pending_result_items', []) or [])]
    slot_items = [_safe_int(item, -1) for item in list(getattr(unit, '_slot_items', []) or [])]
    slot_grid_indices = [_safe_int(item, -1) for item in list(getattr(unit, '_slot_grid_indices', []) or [])]
    return {
        "uid": _extract_entity_identity(unit),
        "class_name": type(unit).__name__,
        "pos": _vec3_to_list(_extract_entity_position(unit)),
        "scan_text": _resolve_tid_text(scan_info.get('text1', box_data.get('name_tid', ''))),
        "class_level": _safe_int(getattr(unit, '_class_level', -1), -1),
        "operator_uid": _safe_uid_text(getattr(unit, '_operator_uid', '')),
        "is_done": bool(getattr(unit, '_is_done', False)),
        "is_synthesizing": bool(getattr(unit, '_is_synthesizing', False)),
        "pending_target_quality": _safe_int(getattr(unit, '_pending_target_quality', -1), -1),
        "pending_result_items": pending_result_items,
        "slot_items": slot_items,
        "slot_grid_indices": slot_grid_indices,
        "box_name_tid": _safe_uid_text(box_data.get('name_tid', '')),
        "box_name": _resolve_tid_text(box_data.get('name_tid', '')),
        "drop_pos": _safe_get_vec(unit, 'drop_pos'),
        "alchemy_spawn_pos": _safe_get_vec(unit, 'alchemy_spawn_pos'),
        "wuzi_socket_pos": _safe_get_vec(unit, '_wuzi_socket_pos')
    }

def _extract_scene_window_entry(unit):
    return {
        "uid": _extract_entity_identity(unit),
        "class_name": type(unit).__name__,
        "pos": _vec3_to_list(_extract_entity_position(unit)),
        "direction": _vec3_to_list(_extract_entity_direction(unit))
    }

def _extract_scene_panel_entry(unit):
    cover_pos = [0.0, 0.0, 0.0]
    vault_exit_pos = [0.0, 0.0, 0.0]
    try:
        if hasattr(unit, 'get_cover_position'):
            cover = unit.get_cover_position()
            if cover:
                cover_pos = _vec3_to_list(cover)
    except:
        pass
    try:
        if hasattr(unit, 'get_vault_exit_position'):
            vault_exit = unit.get_vault_exit_position()
            if vault_exit:
                vault_exit_pos = _vec3_to_list(vault_exit)
    except:
        pass
    return {
        "uid": _extract_entity_identity(unit),
        "class_name": type(unit).__name__,
        "pos": _vec3_to_list(_extract_entity_position(unit)),
        "room_index": _safe_int(getattr(unit, 'room_index', -1), -1),
        "model_name": _safe_uid_text(getattr(unit, 'model_name', '')),
        "cover_position": cover_pos,
        "vault_exit_position": vault_exit_pos,
        "destroyed_by_butcher": bool(getattr(unit, '_destroyed_by_butcher', False))
    }

def _extract_basecamp_entry(unit):
    camp_ui_data = getattr(unit, '_camp_ui_data', {}) or {}
    interact_pos = camp_ui_data.get('interact_pos', None)
    if isinstance(interact_pos, (list, tuple)) and len(interact_pos) >= 3:
        interact_pos_list = [float(interact_pos[0]), float(interact_pos[1]), float(interact_pos[2])]
    elif interact_pos:
        interact_pos_list = _vec3_to_list(interact_pos)
    else:
        interact_pos_list = [0.0, 0.0, 0.0]
    dest_pos = None
    try:
        if hasattr(unit, 'get_dest_pos'):
            dest_pos = unit.get_dest_pos()
    except:
        dest_pos = None
    if not dest_pos:
        try:
            dest_pos = getattr(unit, '_dest_pos', None)
        except:
            dest_pos = None
    enter_camp = None
    try:
        if hasattr(unit, 'get_enter_camp'):
            enter_camp = unit.get_enter_camp()
    except:
        enter_camp = None
    if enter_camp is None:
        enter_camp = getattr(unit, '_enter_camp', None)
    recover_info = {}
    try:
        if hasattr(unit, 'get_recover_info'):
            temp_info = unit.get_recover_info()
            if isinstance(temp_info, dict):
                recover_info = temp_info
    except:
        recover_info = {}
    return {
        "uid": _extract_entity_identity(unit),
        "class_name": type(unit).__name__,
        "pos": _vec3_to_list(_extract_entity_position(unit)),
        "interact_pos": interact_pos_list,
        "camp_ui_id": _safe_int(camp_ui_data.get('camp_ui_id', getattr(unit, '_camp_ui_id', -1)), -1),
        "icon_path": _safe_uid_text(camp_ui_data.get('icon_path', '')),
        "name_tid": _safe_uid_text(camp_ui_data.get('name_tid', '')),
        "name": _resolve_tid_text(camp_ui_data.get('name_tid', '')),
        "ui_hint_distance": _safe_float(camp_ui_data.get('ui_hint_distance', 0.0), 0.0),
        "ui_interact_distance": _safe_float(camp_ui_data.get('ui_interact_distance', 0.0), 0.0),
        "interact_cd": _safe_float(camp_ui_data.get('interact_cd', 0.0), 0.0),
        "interact_init_cd": _safe_float(camp_ui_data.get('interact_init_cd', 0.0), 0.0),
        "enabled": bool(getattr(unit, '_enabled', recover_info.get('enabled', True))),
        "uid_left_cd": _safe_float(recover_info.get('uid_left_cd', 0.0), 0.0),
        "total_cd": _safe_float(recover_info.get('total_cd', 0.0), 0.0),
        "cd_pre_blocked": bool(recover_info.get('cd_pre_blocked', getattr(unit, '_cd_pre_blocked', False))),
        "dest_pos": _vec3_to_list(dest_pos) if dest_pos else [0.0, 0.0, 0.0],
        "enter_camp": bool(enter_camp) if enter_camp is not None else False,
        "trigger_size": _safe_get_vec(unit, '_trigger_size'),
        "trigger_offset": _safe_get_vec(unit, '_trigger_offset'),
        "trigger_forward": _safe_get_vec(unit, '_trigger_forward'),
        "model_name": _safe_uid_text(getattr(unit, '_model_name', '')),
        "dest_dir": _safe_get_vec(unit, '_dest_dir'),
        "dest_euler_y": _safe_float(getattr(unit, '_dest_euler_y', 0.0), 0.0)
    }

def _build_goldrush_runtime_payload():
    # #region debug-point B:runtime-payload-start
    debug_started_at = time.time()
    # #endregion
    payload = {
        "type": "goldrush_runtime",
        "valid": False,
        "scene_id": -1,
        "generation_seed": None,
        "scene_name_tid": "",
        "scene_name": "",
        "world_type": -1,
        "world_type_name": "",
        "mode_name": "",
        "players": [],
        "team_uids": [],
        "monsters": [],
        "self_items": [],
        "reward_boxes": [],
        "alchemy_boxes": [],
        "scene_windows": [],
        "scene_panels": [],
        "basecamp_points": [],
        "summary": {}
    }
    try:
        map_info = get_current_map_info() or {}
        if not map_info or not map_info.get('is_goldrush'):
            return payload
        payload["scene_id"] = _safe_int(map_info.get('scene_id', -1), -1)
        payload["scene_name_tid"] = _safe_uid_text(map_info.get('scene_name_tid', ''))
        payload["scene_name"] = _safe_uid_text(map_info.get('scene_name', ''))
        payload["world_type"] = _safe_int(map_info.get('world_type', -1), -1)
        payload["world_type_name"] = _safe_uid_text(map_info.get('world_type_name', ''))
        payload["mode_name"] = _safe_uid_text(map_info.get('mode_name', ''))
        player = getattr(GK, 'g_unit', None)
        room = getattr(player, 'room', None) if player else None
        combat_core = getattr(room, 'combat_core', None) if room else None
        active_unit_mgr = get_available_ref_unit_mgr() or get_available_unit_mgr()
        if not room or not active_unit_mgr:
            return payload
        player_units = list(get_primary_player_units(prefer_mode=True) or [])
        for unit in player_units:
            try:
                pos = _extract_entity_position(unit)
                native_unit = unit.get_native_unit() if hasattr(unit, 'get_native_unit') else None
                hp_value = -1.0
                max_hp_value = -1.0
                try:
                    hp_comp = getattr(unit, 'ref_attribute_comp', None)
                    if hp_comp and hasattr(hp_comp, 'get_attribute_value'):
                        from common_cs.combat_core.attribute_sets.HealthSet import HealthSet
                        hp_value = round(_safe_float(hp_comp.get_attribute_value(HealthSet.Hp), -1.0), 1)
                        max_hp_value = round(_safe_float(hp_comp.get_attribute_value(HealthSet.MaxHp), -1.0), 1)
                except:
                    pass
                payload["players"].append({
                    "uid": get_player_uid(unit),
                    "pid": _safe_int(getattr(unit, 'pid', 0), 0),
                    "name": _safe_uid_text(getattr(native_unit, 'player_name', getattr(unit, 'player_name', ''))),
                    "is_ai": bool('ai' in type(unit).__name__.lower()),
                    "pos": _vec3_to_list(pos) if pos else [0.0, 0.0, 0.0],
                    "hp": hp_value,
                    "max_hp": max_hp_value
                })
            except:
                pass
        me_uid = get_player_uid(player)
        for player_entry, unit in zip(payload["players"], player_units):
            try:
                health_state = _read_goldrush_health_state(unit)
                effect_entries = _extract_goldrush_effect_entries(unit)
                player_entry["shield"] = health_state.get("shield", 0.0)
                player_entry["stamina"] = health_state.get("stamina", -1.0)
                player_entry["max_stamina"] = health_state.get("max_stamina", -1.0)
                player_entry["game_state"] = health_state.get("game_state", -1)
                player_entry["is_alive"] = health_state.get("is_alive", None)
                player_entry["is_dead"] = health_state.get("is_dead", None)
                player_entry["effects"] = effect_entries
                player_entry["effect_count"] = len(effect_entries)
                player_entry["is_self"] = (player_entry.get("uid", "") == me_uid)
            except:
                pass
        game_mode_instance = getattr(combat_core, 'game_mode_instance', None) if combat_core else None
        if game_mode_instance and hasattr(game_mode_instance, 'get_player_team_members'):
            try:
                payload["team_uids"] = [str(uid) for uid in list(game_mode_instance.get_player_team_members() or [])]
            except:
                payload["team_uids"] = []
        try:
            from common_cs import ComuKeys
            monster_type = getattr(ComuKeys.UNIT_TYPE_CONF, 'GOLD_RUSH_MONSTER', None)
            if monster_type is not None:
                for monster in safe_get_units_by_type_from_mgr(active_unit_mgr, monster_type):
                    pos = _extract_entity_position(monster)
                    payload["monsters"].append({
                        "uid": _extract_entity_identity(monster),
                        "class_name": type(monster).__name__,
                        "pos": _vec3_to_list(pos) if pos else [0.0, 0.0, 0.0]
                    })
        except:
            pass
        payload["self_items"] = _collect_goldrush_self_items(player)
        for unit in _iter_manager_units(active_unit_mgr):
            cls_name = type(unit).__name__
            try:
                if 'GoldRushRewardBox' in cls_name:
                    payload["reward_boxes"].append(_extract_reward_box_entry(unit))
                elif 'GoldRushAlchemyBox' in cls_name:
                    payload["alchemy_boxes"].append(_extract_alchemy_box_entry(unit))
                elif 'GoldRushSceneWindow' in cls_name:
                    payload["scene_windows"].append(_extract_scene_window_entry(unit))
                elif 'GoldRushScenePanel' in cls_name:
                    payload["scene_panels"].append(_extract_scene_panel_entry(unit))
                elif 'GoldRushBaseCamp' in cls_name:
                    payload["basecamp_points"].append(_extract_basecamp_entry(unit))
            except:
                pass
        payload["players"].sort(key=lambda item: (item.get("is_ai", False), item.get("uid", "")))
        payload["monsters"].sort(key=lambda item: item.get("uid", ""))
        payload["reward_boxes"].sort(key=lambda item: (item.get("box_level", -1), item.get("uid", "")))
        payload["alchemy_boxes"].sort(key=lambda item: item.get("uid", ""))
        payload["scene_windows"].sort(key=lambda item: item.get("uid", ""))
        payload["scene_panels"].sort(key=lambda item: item.get("uid", ""))
        payload["basecamp_points"].sort(key=lambda item: (item.get("class_name", ""), item.get("uid", "")))
        payload["summary"] = {
            "player_count": len(payload["players"]),
            "team_count": len(payload["team_uids"]),
            "monster_count": len(payload["monsters"]),
            "self_item_count": len(payload["self_items"]),
            "self_total_value": sum(int(item.get("total_value", 0) or 0) for item in payload["self_items"]),
            "self_total_weight": round(sum(float(item.get("total_weight", 0.0) or 0.0) for item in payload["self_items"]), 1),
            "self_effect_count": 0,
            "self_stamina": -1.0,
            "self_max_stamina": -1.0,
            "self_shield": 0.0,
            "reward_box_count": len(payload["reward_boxes"]),
            "alchemy_box_count": len(payload["alchemy_boxes"]),
            "scene_window_count": len(payload["scene_windows"]),
            "scene_panel_count": len(payload["scene_panels"]),
            "basecamp_point_count": len(payload["basecamp_points"]),
            "reward_box_known_drop_count": 0,
            "alchemy_busy_count": 0,
            "basecamp_enabled_count": 0,
            "minimap_icon_count": 0
        }
        for player_entry in payload["players"]:
            if player_entry.get("is_self"):
                payload["summary"]["self_effect_count"] = int(player_entry.get("effect_count", 0) or 0)
                payload["summary"]["self_stamina"] = _safe_float(player_entry.get("stamina", -1.0), -1.0)
                payload["summary"]["self_max_stamina"] = _safe_float(player_entry.get("max_stamina", -1.0), -1.0)
                payload["summary"]["self_shield"] = _safe_float(player_entry.get("shield", 0.0), 0.0)
                break
        payload["summary"]["reward_box_known_drop_count"] = sum(1 for item in payload["reward_boxes"] if int(item.get("drop_item_id", -1) or -1) > 0)
        payload["summary"]["alchemy_busy_count"] = sum(1 for item in payload["alchemy_boxes"] if item.get("is_synthesizing") or item.get("pending_result_items"))
        payload["summary"]["basecamp_enabled_count"] = sum(1 for item in payload["basecamp_points"] if item.get("enabled"))
        payload["summary"]["minimap_icon_count"] = len(_collect_goldrush_minimap_icons(combat_core))
        payload["fog_control"] = dict(GOLDRUSH_FOG_LAST_RESULT or {})
        payload["seed_box_control"] = dict(GOLDRUSH_SEED_BOX_LAST_RESULT or {})
        payload["valid"] = True
    except Exception as e:
        payload["error"] = str(e)
    return payload

def collect_goldrush_runtime_data():
    payload = _build_goldrush_runtime_payload()
    return json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(',', ':'))

def collect_goldrush_scene_snapshot_data():
    runtime_payload = _build_goldrush_runtime_payload()
    payload = {
        "type": "goldrush_scene_snapshot",
        "valid": False,
        "scene_id": runtime_payload.get("scene_id", -1),
        "scene_name_tid": runtime_payload.get("scene_name_tid", ""),
        "scene_name": runtime_payload.get("scene_name", ""),
        "world_type": runtime_payload.get("world_type", -1),
        "world_type_name": runtime_payload.get("world_type_name", ""),
        "mode_name": runtime_payload.get("mode_name", ""),
        "summary": dict(runtime_payload.get("summary", {}) or {}),
        "full_map_geometry": {}
    }
    try:
        if not runtime_payload.get("valid", False):
            return json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(',', ':'))
        full_map_geometry = _build_goldrush_full_map_geometry(runtime_payload)
        draw_pack = dict(full_map_geometry.get("draw_pack", {}) or {})
        compact_floor_groups = []
        for floor_entry in draw_pack.get("floor_groups", []) or []:
            compact_floor_groups.append({
                "floor": _safe_int(floor_entry.get("floor", 0), 0),
                "room_polygons": list(floor_entry.get("room_polygons", []) or []),
                "outline_segments": list(floor_entry.get("outline_segments", []) or []),
                "path_segments": list(floor_entry.get("path_segments", []) or []),
                "doorway_segments": list(floor_entry.get("doorway_segments", []) or []),
                "stats": dict(floor_entry.get("stats", {}) or {})
            })
        compact_draw_pack = {
            "floor_groups": compact_floor_groups,
            "door_markers": list(draw_pack.get("door_markers", []) or []),
            "polylines": list(draw_pack.get("polylines", []) or []),
            "polygons": list(draw_pack.get("polygons", []) or []),
            "markers": list(draw_pack.get("markers", []) or []),
            "esp_protocol": dict(draw_pack.get("esp_protocol", {}) or {}),
            "stats": dict(draw_pack.get("stats", {}) or {})
        }
        payload["full_map_geometry"] = {
            "draw_pack": compact_draw_pack,
            "stats": dict(full_map_geometry.get("stats", {}) or {})
        }
        stats = full_map_geometry.get("stats", {}) or {}
        payload["summary"]["draw_floor_group_count"] = _safe_int(stats.get("draw_floor_group_count", 0), 0)
        payload["summary"]["draw_room_polygon_count"] = _safe_int(stats.get("draw_room_polygon_count", 0), 0)
        payload["summary"]["draw_door_marker_count"] = _safe_int(stats.get("draw_door_marker_count", 0), 0)
        payload["summary"]["draw_polyline_count"] = _safe_int(stats.get("draw_polyline_count", 0), 0)
        payload["summary"]["draw_polygon_count"] = _safe_int(stats.get("draw_polygon_count", 0), 0)
        payload["summary"]["draw_marker_count"] = _safe_int(stats.get("draw_marker_count", 0), 0)
        payload["summary"]["visible_polyline_count"] = _safe_int(stats.get("visible_polyline_count", 0), 0)
        payload["summary"]["visible_polygon_count"] = _safe_int(stats.get("visible_polygon_count", 0), 0)
        payload["summary"]["visible_marker_count"] = _safe_int(stats.get("visible_marker_count", 0), 0)
        payload["valid"] = True
    except Exception as e:
        payload["error"] = str(e)
    return json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(',', ':'))

def collect_goldrush_reference_data():
    payload = {
        "type": "goldrush_reference",
        "valid": False,
        "scene": dict(GOLDRUSH_SCENE_REFERENCE),
        "levels": [dict(item) for item in GOLDRUSH_LEVEL_REFERENCE],
        "items": [],
        "item_count": 0,
        "reward_boxes": [],
        "buffs": [],
        "interact_effects": [],
        "states": [],
        "skills": [],
        "global_params": {},
        "basecamp_ui": []
    }
    try:
        table = _get_goldrush_item_data_table()
        items = []
        for raw_key, cfg in table.items():
            try:
                item_id = _safe_int(raw_key, _safe_int(cfg.get('id', -1), -1))
                if item_id <= 0:
                    continue
                name_tid = _safe_uid_text(cfg.get('name', cfg.get('g_name', '')))
                items.append({
                    "item_id": item_id,
                    "name_tid": name_tid,
                    "name": _resolve_tid_text(name_tid),
                    "value": _safe_int(cfg.get('value', 0), 0),
                    "sold_price": _safe_int(cfg.get('sold_price', 0), 0),
                    "weight": _safe_float(cfg.get('weight', 0.0), 0.0),
                    "storage_type": _safe_int(cfg.get('storage_type', 0), 0),
                    "tag": _safe_uid_text(cfg.get('tag', '')),
                    "stack_limit": _safe_int(cfg.get('stack_limit', 0), 0)
                })
            except:
                pass
        items.sort(key=lambda item: item.get("item_id", 0))
        payload["items"] = items
        payload["item_count"] = len(items)
        payload["reward_boxes"] = _build_table_entries('goldrush_reward_box', ('box_type', 'box_quality', 'box_level', 'reward_id', 'class_level', 'box_anim_type'))
        payload["buffs"] = _build_table_entries('goldrush_buff', ('buff_tid', 'buff_desc_tid', 'buff_icon_path', 'duration', 'show_type', 'show_priority', 'is_show', 'stack_type', 'target_type', 'time_stackable'))
        for entry in payload["buffs"]:
            entry["name"] = _resolve_tid_text(entry.get("buff_tid", ''))
            entry["desc"] = _resolve_tid_text(entry.get("buff_desc_tid", ''))
        payload["interact_effects"] = _build_table_entries('goldrush_interact_effect', ('effect_type', 'interact_type_id', 'priority', 'start_state', 'target', 'target_state'))
        payload["states"] = _build_table_entries('goldrush_state', ('camp', 'anim_name', 'anim_rate', 'ext_anim_name', 'ext_anim_rate', 'hide_handheld'))
        payload["skills"] = _build_table_entries('goldrush_skill', ('skill_type', 'skill_icon', 'skill_slot', 'skill_sound_id', 'skill_action', 'trigger_type', 'trigger_frame', 'state_conflict_col', 'state_conflict_row', 'is_attack'))
        global_table = _get_dm_table('goldrush_global_data')
        interesting_keys = (
            'survivor_jump_stamina_cost', 'survivor_low_stamina_threshold', 'survivor_run_stamina_cost',
            'survivor_run_stamina_recover', 'survivor_run_stamina_recover_interval',
            'survivor_stamina_cost_jump', 'survivor_stamina_cost_run',
            'butcher_run_stamina_cost', 'butcher_stamina_cost_run'
        )
        global_params = {}
        for key in interesting_keys:
            try:
                if key not in global_table:
                    continue
                value = global_table.get(key)
                if isinstance(value, (list, tuple)):
                    global_params[key] = [float(v) if isinstance(v, (int, float)) else _safe_uid_text(v) for v in value]
                elif isinstance(value, (int, float, bool)):
                    global_params[key] = value
                else:
                    global_params[key] = _safe_uid_text(value)
            except:
                pass
        payload["global_params"] = global_params
        payload["basecamp_ui"] = _build_table_entries('goldrush_base_camp_ui', ('icon_path', 'name_tid', 'interact_cd', 'interact_init_cd', 'ui_hint_distance', 'ui_interact_distance'))
        for entry in payload["basecamp_ui"]:
            entry["name"] = _resolve_tid_text(entry.get("name_tid", ''))
        payload["valid"] = bool(len(items) > 0 or payload["reward_boxes"] or payload["buffs"] or payload["states"] or payload["skills"])
    except Exception as e:
        payload["error"] = str(e)
    return json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(',', ':'))

GOLDRUSH_BOX_STATE_NAMES = {
    1: "Close",
    2: "UnLock",
    3: "IsOpening",
    4: "Opened",
    5: "Cancel",
    6: "ExtraStage"
}

GOLDRUSH_ITEM_QUALITY_LABELS = {
    1: "