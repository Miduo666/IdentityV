import re

data = open('1.so', 'rb').read()

# 找 PY_SCRIPT_CONTENT 符号指向的字符串
# 策略：找最长的连续 Python 代码块（包含 def/import/class 的大段文本）
# Python 脚本在 SO 里是一段连续的 ASCII 文本

# 找所有长度 > 100 的可读字符串段（中间可以有换行 \n = 0x0a）
chunks = re.findall(rb'(?:[\x09\x0a\x0d\x20-\x7e]){200,}', data)

print(f"找到 {len(chunks)} 个大文本块")
for i, chunk in enumerate(chunks):
    text = chunk.decode('ascii', 'ignore')
    # 判断是否是 Python 代码
    if ('def ' in text or 'import ' in text) and ('collect' in text or 'hook' in text or 'socket' in text):
        fname = f'script_chunk_{i}.py'
        with open(fname, 'w', encoding='utf-8') as f:
            f.write(text)
        print(f"[{i}] 保存到 {fname}，长度={len(text)} 字节")
        print(f"    前100字符: {repr(text[:100])}")
