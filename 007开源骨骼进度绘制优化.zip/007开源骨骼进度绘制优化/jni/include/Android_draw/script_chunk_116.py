":
                    if note_type == 3:
                        qte_length = 1.2
                    elif note_type == 2:
                        qte_length = 1.4
                    else:
                        qte_length = item_qte_length

            if qte_length is not None:
                qte_length = _safe_number(qte_length, item_qte_length)
                target_time = begin_time + qte_length
                time_left = target_time - now_time

                torrence = _safe_number(_safe_get(item, 'client_torrence', 0.16), 0.16)
                if torrence == 0.16:
                    torrence = _safe_number(_safe_get(item, 'valid_torrence', 0.16), 0.16)

                is_in_window = abs(time_left) <= torrence

                tail_info = {
                    "track_kind": track_kind,
                    "channel": channel,
                    "begin_time": round(begin_time, 3),
                    "qte_length": round(qte_length, 3),
                    "target_time": round(target_time, 3),
                    "time_left": round(time_left, 3),
                    "torrence": round(torrence, 3),
                    "is_in_window": is_in_window
                }
            else:
                tail_info = {
                    "track_kind": track_kind,
                    "channel": channel,
                    "begin_time": round(begin_time, 3)
                }

        node_ui = _safe_get(tail, 'node_ui', None) if tail else None
        return {
            "class_name": _safe_text(_safe_get(_safe_get(container, '__class__', None), '__name__', None)),
            "seq_len": seq_len,
            "tail_class": _safe_text(_safe_get(_safe_get(tail, '__class__', None), '__name__', None)) if tail else "",
            "tail_note_type": _safe_json(_safe_get(tail, 'note_type', None)) if tail else None,
            "tail_channel": _safe_json(_safe_get(tail, 'channel', None)) if tail else None,
            "tail_move_speed": _safe_json(_safe_get(tail, 'move_speed', None)) if tail else None,
            "tail_offset_adjust": _safe_json(_safe_get(tail, 'offset_adjust', None)) if tail else None,
            "node_ui_class": _safe_text(_safe_get(_safe_get(node_ui, '__class__', None), '__name__', None)) if node_ui else "",
            "node_ui_visible": _node_visible(node_ui),
            "node_ui_rotation": _safe_number(_node_rotation(node_ui), 0.0),
            "tail_info": tail_info
        }

    def _build_musician_item_data(item, index_value, source_text):
        item_cls = _safe_text(_safe_get(_safe_get(item, '__class__', None), '__name__', None))
        item_uid = _safe_text(_safe_get(item, 'uid', None))
        item_id = _safe_json(_safe_get(item, 'item_id', None))
        item_idx = _safe_json(_safe_get(item, 'item_idx', None))
        qte_mode = _safe_json(_safe_get(item, 'qte_mode', None))
        difficulty = _safe_int(_safe_get(item, 'difficulty', 0), 0)
        music_pool = _safe_get(item, 'music_pool', None)
        music_pool_class = _safe_text(_safe_get(_safe_get(music_pool, '__class__', None), '__name__', None)) if music_pool else ""
        music_pool_scores_id = _safe_json(_safe_get(music_pool, 'cur_music_scores_id', None)) if music_pool else None
        music_pool_mode = _safe_json(_safe_get(music_pool, '_mode', None)) if music_pool else None
        music_pool_show_qte = _safe_json(_safe_get(music_pool, 'is_show_qte_ui', None)) if music_pool else None
        
        ability_lengths = [2.0, 1.6, 1.2]
        current_ability_length = ability_lengths[difficulty] if difficulty >= 0 and difficulty < len(ability_lengths) else ability_lengths[0]
        ability_qte_length_0 = ability_lengths[0] if len(ability_lengths) > 0 else 2.0
        ability_qte_length_1 = ability_lengths[1] if len(ability_lengths) > 1 else ability_qte_length_0
        ability_qte_length_2 = ability_lengths[2] if len(ability_lengths) > 2 else ability_qte_length_1
        item_qte_length = _safe_number(_safe_get(item, 'music_qte_length_item', None), None)

        now_time = _resolve_battle_now_time(item)

        qte_container_1 = _dump_music_container(_safe_get(music_pool, 'qte_container_1', None), item, now_time) if music_pool else {}
        qte_container_2 = _dump_music_container(_safe_get(music_pool, 'qte_container_2', None), item, now_time) if music_pool else {}
        qte_container_3 = _dump_music_container(_safe_get(music_pool, 'qte_container_3', None), item, now_time) if music_pool else {}

        item_entry = {
            "source": source_text,
            "class_name": item_cls,
            "uid": item_uid,
            "item_id": item_id,
            "item_idx": item_idx,
            "qte_mode": qte_mode,
            "difficulty": difficulty,
            "music_qte_length_item": _safe_json(_safe_get(item, 'music_qte_length_item', None)),
            "music_qte_length_ability": _safe_json(_safe_get(item, 'music_qte_length_ability', None)),
            "music_pool_class": music_pool_class,
            "music_pool_cur_music_scores_id": music_pool_scores_id,
            "music_pool_mode": music_pool_mode,
            "music_pool_is_show_qte_ui": music_pool_show_qte,
            "qte_container_1": qte_container_1,
            "qte_container_2": qte_container_2,
            "qte_container_3": qte_container_3
        }

        runtime_attrs = {
            "source": _safe_text(source_text),
            "uid": item_uid,
            "item_id": _safe_text(item_id),
            "item_idx": _safe_text(item_idx),
            "qte_mode": _safe_text(qte_mode),
            "difficulty": _safe_text(difficulty),
            "music_qte_length_item": _safe_text(item_entry["music_qte_length_item"]),
            "music_qte_length_ability": _safe_text(item_entry["music_qte_length_ability"]),
            "ability_qte_length_0": _safe_text(ability_qte_length_0),
            "ability_qte_length_1": _safe_text(ability_qte_length_1),
            "ability_qte_length_2": _safe_text(ability_qte_length_2),
            "current_item_qte_length": _safe_text(item_qte_length),
            "current_ability_qte_length": _safe_text(current_ability_length),
            "music_pool_class": music_pool_class,
            "music_pool_cur_music_scores_id": _safe_text(music_pool_scores_id),
            "music_pool_mode": _safe_text(music_pool_mode),
            "music_pool_is_show_qte_ui": _safe_text(music_pool_show_qte)
        }
        for container_key in ("qte_container_1", "qte_container_2", "qte_container_3"):
            container_info = item_entry.get(container_key, {}) or {}
            if not container_info:
                continue
            runtime_attrs[container_key + "_seq_len"] = _safe_text(container_info.get("seq_len", 0))
            runtime_attrs[container_key + "_tail_class"] = _safe_text(container_info.get("tail_class", ""))
            runtime_attrs[container_key + "_tail_note_type"] = _safe_text(container_info.get("tail_note_type", ""))
            runtime_attrs[container_key + "_tail_channel"] = _safe_text(container_info.get("tail_channel", ""))
            runtime_attrs[container_key + "_tail_move_speed"] = _safe_text(container_info.get("tail_move_speed", ""))
            runtime_attrs[container_key + "_tail_offset_adjust"] = _safe_text(container_info.get("tail_offset_adjust", ""))
            runtime_attrs[container_key + "_node_ui_class"] = _safe_text(container_info.get("node_ui_class", ""))
            runtime_attrs[container_key + "_node_ui_visible"] = _safe_text(container_info.get("node_ui_visible", False))
            runtime_attrs[container_key + "_node_ui_rotation"] = _safe_text(container_info.get("node_ui_rotation", 0.0))
            
            tail_info = container_info.get("tail_info", {})
            if tail_info:
                runtime_attrs[container_key + "_track_kind"] = _safe_text(tail_info.get("track_kind", ""))
                runtime_attrs[container_key + "_channel"] = _safe_text(tail_info.get("channel", ""))
                runtime_attrs[container_key + "_begin_time"] = _safe_text(tail_info.get("begin_time", ""))
                runtime_attrs[container_key + "_qte_length"] = _safe_text(tail_info.get("qte_length", ""))
                runtime_attrs[container_key + "_target_time"] = _safe_text(tail_info.get("target_time", ""))
                runtime_attrs[container_key + "_torrence"] = _safe_text(tail_info.get("torrence", ""))
                runtime_attrs[container_key + "_time_left"] = _safe_text(tail_info.get("time_left", ""))
                runtime_attrs[container_key + "_is_in_window"] = _safe_text(tail_info.get("is_in_window", ""))
        runtime_attrs["battle_now_time"] = _safe_text(now_time)

        tracked_item = {
            "index": index_value,
            "class_name": item_cls or "UnknownItem",
            "owner_uid": item_uid,
            "runtime_attrs": runtime_attrs
        }
        return item_entry, tracked_item

    try:
        qte_from_gk_input = {}
        try:
            qte_from_gk_input = _dump_qte_obj(getattr(GK, 'input', None))
            payload["qte_primary_path"] = "GK.input"
            payload["qte_from_gk_input"] = qte_from_gk_input
        except Exception as e:
            payload["qte_from_gk_input"] = {"error": _safe_text(e)}

        try:
            ui_probe = _find_battle_qte_via_ui_mgr()
            payload["qte_via_battle_ui"] = {
                "ui_name": ui_probe.get("ui_name", ""),
                "battle_ui_class": ui_probe.get("battle_ui_class", ""),
                "layer_proxy_class": ui_probe.get("layer_proxy_class", ""),
                "qte_data": _dump_qte_obj(ui_probe.get("qte_ui", None)),
                "error": ui_probe.get("error", "")
            }
        except Exception as e:
            payload["qte_via_battle_ui"] = {"error": _safe_text(e)}

        primary_qte = payload["qte_from_gk_input"] if isinstance(payload["qte_from_gk_input"], dict) else {}
        fallback_qte = {}
        if isinstance(payload["qte_via_battle_ui"], dict):
            fallback_qte = payload["qte_via_battle_ui"].get("qte_data", {}) or {}
        active_qte = primary_qte if primary_qte.get("class_name") else fallback_qte

        if active_qte:
            payload["ui_found"] = True
            payload["ui_class_name"] = _safe_text(active_qte.get("class_name", ""))
            payload["ui_source"] = "GK.input" if active_qte is primary_qte else "battle_ui.layer_proxy"
            payload["ui_battle_qte"] = {
                "in_qte": _safe_bool(active_qte.get("in_qte", False)),
                "qte_visible_flag": _safe_bool(active_qte.get("qte_visible_flag", False)),
                "qte_hit_flag": _safe_bool(active_qte.get("qte_hit_flag", False)),
                "qte_fail_flag": _safe_bool(active_qte.get("qte_fail_flag", False)),
                "qte_kind": _safe_int(active_qte.get("qte_kind", -1), -1),
                "qte_uid": _safe_text(active_qte.get("qte_uid", "")),
                "qte_target_uid": _safe_text(active_qte.get("qte_target_uid", "")),
                "qte_needle_rotation": _safe_number(active_qte.get("needle_rotation", 0.0), 0.0),
                "good_left": _safe_number(active_qte.get("good_left", 0.0), 0.0),
                "good_right": _safe_number(active_qte.get("good_right", 0.0), 0.0),
                "good_width": _safe_number(active_qte.get("good_width", 0.0), 0.0),
                "perfect_left": _safe_number(active_qte.get("perfect_left", 0.0), 0.0),
                "perfect_right": _safe_number(active_qte.get("perfect_right", 0.0), 0.0),
                "perfect_width": _safe_number(active_qte.get("perfect_width", 0.0), 0.0),
                "good_range": active_qte.get("good_range", None),
                "perfect_range": active_qte.get("perfect_range", None)
            }

        items = _iter_hold_items()
        payload["hold_item_count"] = len(items)

        musician_qte = {}
        musician_items = []
        seen_musician_ids = {}

        def _append_musician_item(item, index_value, source_text):
            if item is None:
                return
            try:
                item_identity = id(item)
            except:
                item_identity = None
            if item_identity is not None and item_identity in seen_musician_ids:
                return

            item_cls = _safe_text(_safe_get(_safe_get(item, '__class__', None), '__name__', None))
            music_pool = _safe_get(item, 'music_pool', None)
            qte_mode = _safe_get(item, 'qte_mode', None)
            if music_pool is None and qte_mode is None and 'Music' not in item_cls:
                return

            item_entry, tracked_item = _build_musician_item_data(item, index_value, source_text)
            item_key = "Item_%s_%s" % (_safe_text(source_text or "unknown"), _safe_text(index_value))
            musician_qte[item_key] = item_entry
            musician_items.append(tracked_item)
            if item_identity is not None:
                seen_musician_ids[item_identity] = True

        primary_musician_probe = _find_musician_item()
        primary_musician_item = primary_musician_probe.get("item", None)
        primary_musician_source = _safe_text(primary_musician_probe.get("source", ""))
        if primary_musician_item is not None:
            primary_index = _safe_int(_safe_get(primary_musician_item, 'item_idx', -1), -1)
            _append_musician_item(primary_musician_item, primary_index, primary_musician_source or "primary_probe")

        for idx, item in enumerate(items):
            _append_musician_item(item, idx, "combat_unit.get_hold_items")

        for idx, item in enumerate(_iter_g_unit_items()):
            _append_musician_item(item, idx, "g_unit.item_lst")

        payload["musician_qte"] = musician_qte
        payload["musician_items"] = musician_items
        payload["valid"] = bool(payload["ui_found"] or musician_items)
    except Exception as e:
        payload["error"] = str(e)

    return json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(',', ':'))

def _build_all_unit_buffs_payload_base():
    return {
        "type": "all_unit_buffs",
        "valid": False,
        "room_ready": False,
        "world_source": "",
        "scanned_units": 0,
        "buff_unit_count": 0,
        "units": []
    }

def _start_incremental_all_unit_buffs_collector():
    state = INCREMENTAL_COLLECTOR_STATE.get("all_unit_buffs", {})
    payload = _build_all_unit_buffs_payload_base()
    state["active"] = True
    state["items"] = []
    state["index"] = 0
    state["result"] = payload
    room = None
    world_mgr = None
    try:
        world_mgr = getattr(GK, 'g_world_mgr', None)
    except:
        world_mgr = None
    try:
        battle_world = getattr(world_mgr, 'battle_world', None) if world_mgr else None
    except:
        battle_world = None
    if battle_world:
        room = battle_world
        payload["world_source"] = "battle_world"
    if not room:
        try:
            me = getattr(GK, 'g_unit', None)
            room = getattr(me, 'room', None) if me else None
            if room:
                payload["world_source"] = "g_unit.room"
        except:
            room = None
    if not room:
        try:
            room = getattr(world_mgr, 'cur_world', None) if world_mgr else None
            if room:
                payload["world_source"] = "cur_world"
        except:
            room = None
    if not room:
        return
    payload["room_ready"] = True
    unit_mgr = getattr(room, 'unit_mgr', None) or get_available_unit_mgr()
    if not unit_mgr:
        return
    if not payload["world_source"]:
        payload["world_source"] = "fallback_unit_mgr"
    all_units = safe_get_units_from_mgr(unit_mgr, 'get_all_units')
    payload["scanned_units"] = len(all_units)
    state["items"] = list(all_units or [])

def _append_incremental_all_unit_buffs_unit(payload, unit):
    try:
        if not unit:
            return
        now_time = _get_room_game_time_fallback()
        buff_mgr = getattr(unit, 'buff_mgr', None)
        if not buff_mgr:
            return
        uid = get_player_uid(unit)
        try:
            pid = int(getattr(unit, 'pid', 0) or 0)
        except:
            pid = 0
        is_butcher = bool(getattr(unit, 'is_butcher', False))
        is_civilian = bool(getattr(unit, 'is_civilian', False))
        unit_type_text = "