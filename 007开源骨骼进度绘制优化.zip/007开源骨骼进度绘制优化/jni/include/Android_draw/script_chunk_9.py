0
    return "0"

def get_player_uid(player):
    uid = "unknown"
    try:
        if hasattr(player, 'uid') and getattr(player, 'uid', None) is not None:
            uid = str(player.uid)
        if (uid == "unknown" or uid == "") and hasattr(player, 'warm_info') and player.warm_info:
            uid = str(player.warm_info.get('unique_id', 'unknown'))
        if (uid == "unknown" or uid == "") and hasattr(player, 'unique_id') and player.unique_id:
            uid = str(player.unique_id)
    except:
        pass
    return uid

def get_unit_model_full_path(unit):
    try:
        if not hasattr(unit, 'model'):
            return ""
        model = unit.model
        if not model:
            return ""
        if not getattr(model, 'valid', False):
            return ""
        filename = getattr(model, 'filename', '')
        if filename:
            return str(filename)
        for attr_name in ("file_name", "filepath", "full_path", "res_path", "resource_path", "prefab_path"):
            value = getattr(model, attr_name, None)
            if value:
                return str(value)
    except:
        pass
    return ""

SPECIAL_STATE_CACHE = {
    "struggle": {},
    "fragrance": {}
}

def _update_struggle_cache(uid, value, speed=None):
    try:
        uid_text = str(uid or '')
        if not uid_text:
            return
        cached = SPECIAL_STATE_CACHE["struggle"].get(uid_text, {})
        struggle_speed = cached.get("speed", 0.0) if speed is None else speed
        SPECIAL_STATE_CACHE["struggle"][uid_text] = {
            "value": float(value or 0.0),
            "speed": float(struggle_speed or 0.0),
            "update_time": _get_room_game_time_fallback()
        }
    except:
        pass

def _clear_struggle_cache(uid):
    try:
        uid_text = str(uid or '')
        if uid_text:
            SPECIAL_STATE_CACHE["struggle"].pop(uid_text, None)
    except:
        pass

def _update_fragrance_cache(uid, left_time, total_time=None):
    try:
        uid_text = str(uid or '')
        if not uid_text:
            return
        now_time = _get_room_game_time_fallback()
        left_seconds = _normalize_remaining_seconds(left_time)
        if left_seconds is None or left_seconds <= 0.0:
            return
        cache_entry = {
            "end_time": now_time + left_seconds,
            "update_time": now_time
        }
        total_seconds = _normalize_duration_seconds(total_time)
        if total_seconds is not None:
            cache_entry["total_time"] = total_seconds
        SPECIAL_STATE_CACHE["fragrance"][uid_text] = cache_entry
    except:
        pass

def _get_fragrance_cache_left_time(uid):
    try:
        uid_text = str(uid or '')
        if not uid_text:
            return None
        cached = SPECIAL_STATE_CACHE["fragrance"].get(uid_text)
        if not cached:
            return None
        now_time = _get_room_game_time_fallback()
        end_time = float(cached.get("end_time", 0.0) or 0.0)
        left_time = max(0.0, end_time - now_time)
        if left_time <= 0.0:
            SPECIAL_STATE_CACHE["fragrance"].pop(uid_text, None)
            return None
        return left_time
    except:
        return None

def _clear_fragrance_cache(uid):
    try:
        uid_text = str(uid or '')
        if uid_text:
            SPECIAL_STATE_CACHE["fragrance"].pop(uid_text, None)
    except:
        pass

def _get_room_game_time_fallback():
    try:
        battle_world = getattr(getattr(GK, 'g_world_mgr', None), 'battle_world', None)
        if battle_world and hasattr(battle_world, 'game_time'):
            return float(battle_world.game_time())
    except:
        pass
    try:
        if hasattr(GK, 'g_unit') and GK.g_unit:
            room = getattr(GK.g_unit, 'room', None)
            if room and hasattr(room, 'game_time'):
                return float(room.game_time())
    except:
        pass
    return 0.0

def _install_special_state_event_hook():
    try:
        room = getattr(getattr(GK, 'g_unit', None), 'room', None) if hasattr(GK, 'g_unit') and GK.g_unit else None
        combat_helper = getattr(room, 'combat_helper', None) if room else None
        if not combat_helper:
            return False
        if getattr(combat_helper, '_special_state_hook_installed', False):
            return True
        original_publish = getattr(combat_helper, 'ref_publish_event', None)
        if not original_publish:
            return False
        event_type_obj = getattr(combat_helper, 'ref_game_event_type', None)
        struggle_event = None
        try:
            struggle_event = getattr(getattr(event_type_obj, 'Civilian', None), 'StruggleProgressUpdate', None)
        except:
            struggle_event = None
        def _wrapped_publish(evt_name, evt_data=None, *args, **kwargs):
            try:
                if struggle_event is not None and str(evt_name) == str(struggle_event):
                    data = evt_data if isinstance(evt_data, dict) else {}
                    uid = str(data.get('uid', '') or '')
                    if uid:
                        SPECIAL_STATE_CACHE["struggle"][uid] = {
                            "value": float(data.get('value', 0.0) or 0.0),
                            "speed": float(data.get('speed', 0.0) or 0.0),
                            "update_time": _get_room_game_time_fallback()
                        }
            except:
                pass
            return original_publish(evt_name, evt_data, *args, **kwargs)
        combat_helper.ref_publish_event = _wrapped_publish
        combat_helper._special_state_hook_installed = True
        return True
    except:
        return False

def _install_special_state_unit_hooks():
    try:
        candidate_units = []
        unit_mgr = get_available_unit_mgr()
        for unit in safe_get_units_from_mgr(unit_mgr, 'get_player_units') or []:
            if unit:
                candidate_units.append(unit)
        try:
            if hasattr(GK, 'g_unit') and GK.g_unit:
                candidate_units.append(GK.g_unit)
        except:
            pass

        hooked_any = False
        seen_classes = set()
        for unit in candidate_units:
            try:
                target_class = getattr(unit, '__class__', None)
            except:
                target_class = None
            if target_class is None or target_class in seen_classes:
                continue
            seen_classes.add(target_class)

            current_set_struggle = getattr(target_class, 'set_struggle', None)
            if current_set_struggle is not None and not getattr(current_set_struggle, '__solo_struggle_hook_installed__', False):
                @wraps(current_set_struggle)
                def _wrapped_set_struggle(self, value, speed, *args, __orig=current_set_struggle, **kwargs):
                    try:
                        _update_struggle_cache(getattr(self, 'uid', ''), value, speed)
                    except:
                        pass
                    return __orig(self, value, speed, *args, **kwargs)
                _wrapped_set_struggle.__solo_struggle_hook_installed__ = True
                target_class.set_struggle = _wrapped_set_struggle
                hooked_any = True

            current_set_struggle_value_only = getattr(target_class, 'set_struggle_value_only', None)
            if current_set_struggle_value_only is not None and not getattr(current_set_struggle_value_only, '__solo_struggle_value_only_hook_installed__', False):
                @wraps(current_set_struggle_value_only)
                def _wrapped_set_struggle_value_only(self, value, *args, __orig=current_set_struggle_value_only, **kwargs):
                    try:
                        _update_struggle_cache(getattr(self, 'uid', ''), value, None)
                    except:
                        pass
                    return __orig(self, value, *args, **kwargs)
                _wrapped_set_struggle_value_only.__solo_struggle_value_only_hook_installed__ = True
                target_class.set_struggle_value_only = _wrapped_set_struggle_value_only
                hooked_any = True

            current_set_success_struggle = getattr(target_class, 'set_success_struggle', None)
            if current_set_success_struggle is not None and not getattr(current_set_success_struggle, '__solo_success_struggle_hook_installed__', False):
                @wraps(current_set_success_struggle)
                def _wrapped_set_success_struggle(self, *args, __orig=current_set_success_struggle, **kwargs):
                    try:
                        _clear_struggle_cache(getattr(self, 'uid', ''))
                    except:
                        pass
                    return __orig(self, *args, **kwargs)
                _wrapped_set_success_struggle.__solo_success_struggle_hook_installed__ = True
                target_class.set_success_struggle = _wrapped_set_success_struggle
                hooked_any = True

            current_recover_state_kill = getattr(target_class, 'recover_state_kill', None)
            if current_recover_state_kill is not None and not getattr(current_recover_state_kill, '__solo_recover_state_kill_hook_installed__', False):
                @wraps(current_recover_state_kill)
                def _wrapped_recover_state_kill(self, *args, __orig=current_recover_state_kill, **kwargs):
                    try:
                        for arg in args:
                            if not isinstance(arg, dict):
                                continue
                            struggle_info = arg.get('struggle_info')
                            if not isinstance(struggle_info, dict):
                                continue
                            _update_struggle_cache(
                                getattr(self, 'uid', ''),
                                struggle_info.get('struggle_value', 0.0),
                                struggle_info.get('struggle_speed', 0.0)
                            )
                            break
                    except:
                        pass
                    return __orig(self, *args, **kwargs)
                _wrapped_recover_state_kill.__solo_recover_state_kill_hook_installed__ = True
                target_class.recover_state_kill = _wrapped_recover_state_kill
                hooked_any = True
        return hooked_any
    except:
        return False

def _build_action_payload_base():
    actions_data = {"type": "actions", "self_uid": "unknown", "players": []}
    try:
        if hasattr(GK, 'g_unit') and GK.g_unit:
            actions_data["self_uid"] = get_player_uid(GK.g_unit)
    except:
        pass
    return actions_data

def _collect_action_unit_work_items():
    work_items = []
    try:
        _install_special_state_event_hook()
        _install_special_state_unit_hooks()
        unit_mgr = get_available_unit_mgr()
        for player in safe_get_units_from_mgr(unit_mgr, 'get_player_units') or []:
            if player:
                work_items.append({
                    "unit": player,
                    "forced_unit_type": None,
                    "forced_pid": None,
                    "is_yidhra_puppet": False,
                    "is_mary_mirror": False
                })
        try:
            from common_cs import ComuKeys
            room = getattr(GK.g_unit, 'room', None) if hasattr(GK, 'g_unit') and GK.g_unit else None
            room_unit_mgr = getattr(room, 'unit_mgr', None) if room else None
            if room_unit_mgr:
                puppets = safe_get_units_by_type_from_mgr(room_unit_mgr, ComuKeys.UNIT_TYPE_CONF.YIDHRA_PUPPET)
                for puppet in puppets or []:
                    try:
                        if puppet and getattr(puppet, 'is_yidhra_puppet', False):
                            work_items.append({
                                "unit": puppet,
                                "forced_unit_type": 1,
                                "forced_pid": 81,
                                "is_yidhra_puppet": True,
                                "is_mary_mirror": False
                            })
                    except:
                        pass
        except:
            pass
        try:
            room = getattr(GK.g_unit, 'room', None) if hasattr(GK, 'g_unit') and GK.g_unit else None
            room_unit_mgr = getattr(room, 'unit_mgr', None) if room else None
            if room_unit_mgr and get_hook_control_flag("need_special_units"):
                mary_images = safe_get_units_by_type_from_mgr(room_unit_mgr, 247)
                for image in mary_images or []:
                    try:
                        if image:
                            work_items.append({
                                "unit": image,
                                "forced_unit_type": 1,
                                "forced_pid": 85,
                                "is_yidhra_puppet": False,
                                "is_mary_mirror": True
                            })
                    except:
                        pass
        except:
            pass
    except:
        pass
    return work_items

def _iter_unit_hold_items(unit):
    try:
        combat_unit = getattr(unit, 'combat_unit', None)
        getter = getattr(combat_unit, 'get_hold_items', None) if combat_unit else None
        if callable(getter):
            items = getter() or []
            try:
                return list(items)
            except:
                return []
    except:
        pass
    try:
        item_lst = getattr(unit, 'item_lst', None)
        if item_lst is not None:
            try:
                return list(item_lst)
            except:
                return []
    except:
        pass
    return []

def _normalize_duration_seconds(value):
    try:
        seconds = float(value)
        if seconds <= 0.0:
            return None
        if seconds > 100.0:
            seconds = seconds / 1000.0
        if seconds <= 0.0 or seconds > 120.0:
            return None
        return seconds
    except:
        return None

def _normalize_remaining_seconds(value):
    try:
        seconds = float(value)
        if seconds < 0.0:
            return None
        if seconds > 100.0:
            seconds = seconds / 1000.0
        if seconds < 0.0 or seconds > 120.0:
            return None
        return seconds
    except:
        return None

def _read_first_reasonable_time_value(obj, attr_names, normalize_func):
    if not obj:
        return None
    for attr_name in attr_names:
        try:
            value = getattr(obj, attr_name, None)
            if callable(value):
                try:
                    value = value()
                except:
                    continue
            seconds = normalize_func(value)
            if seconds is not None:
                return seconds
        except:
            pass
    return None

def _read_first_timepoint_value(obj, attr_names):
    if not obj:
        return None
    for attr_name in attr_names:
        try:
            value = getattr(obj, attr_name, None)
            if callable(value):
                try:
                    value = value()
                except:
                    continue
            if value is None:
                continue
            return float(value)
        except:
            pass
    return None

def _normalize_timepoint_value(value, now_time=None):
    try:
        timepoint = float(value)
    except:
        return None
    if timepoint < 0.0:
        return None
    try:
        now_value = float(now_time) if now_time is not None else None
    except:
        now_value = None
    if now_value is not None and now_value >= 0.0:
        if timepoint > now_value + 120.0 and (timepoint / 1000.0) <= now_value + 120.0:
            timepoint = timepoint / 1000.0
    elif timepoint > 1000000.0:
        timepoint = timepoint / 1000.0
    return timepoint

def _get_room_ridiculous_time_fallback(unit=None):
    room = None
    try:
        room = getattr(unit, 'room', None) if unit else None
    except:
        room = None
    if room is not None:
        try:
            import common_cs.cs_utils_battle as cs_utils_battle
            ridiculous_time = getattr(cs_utils_battle, 'ridiculous_time', None)
            if callable(ridiculous_time):
                value = ridiculous_time(room)
                try:
                    return float(value)
                except:
                    pass
        except:
            pass
        try:
            getter = getattr(room, 'game_time', None)
            if callable(getter):
                return float(getter() or 0.0)
        except:
            pass
    return _get_room_game_time_fallback()

def _read_item_active_remaining_seconds(item):
    if not item:
        return None
    remain_attr_names = (
        '_remain_lifespan', 'remain_lifespan', 'left_time', 'remain_time',
        'remaining_time', '_left_time', '_remain_time'
    )
    remain_seconds = _read_first_reasonable_time_value(item, remain_attr_names, _normalize_remaining_seconds)
    if remain_seconds is not None:
        return remain_seconds

    total_attr_names = (
        '_init_lifespan', 'init_lifespan', 'life_time', 'duration', '_duration'
    )
    total_seconds = _read_first_reasonable_time_value(item, total_attr_names, _normalize_duration_seconds)
    if total_seconds is None:
        return None

    consumed_seconds = None
    try:
        consumed_seconds = _normalize_remaining_seconds(getattr(item, 'consume_cnt', None))
    except:
        consumed_seconds = None
    if consumed_seconds is not None:
        return max(0.0, total_seconds - consumed_seconds)
    return total_seconds

def _read_item_active_duration_seconds(item):
    if not item:
        return None
    return _read_first_reasonable_time_value(item, (
        '_init_lifespan', 'init_lifespan', 'life_time', 'duration', '_duration'
    ), _normalize_duration_seconds)

def _read_skill_active_remaining_seconds(skill_obj, unit=None):
    if not skill_obj:
        return None
    now_time = _get_room_ridiculous_time_fallback(unit)
    duration_seconds = _read_first_reasonable_time_value(skill_obj, (
        'skill_duration', 'duration', '_duration', 'total_time', 'max_time',
        'check_time', '_check_time'
    ), _normalize_duration_seconds)
    start_time = _read_first_timepoint_value(skill_obj, (
        'start_cast_time', '_start_cast_time', 'cast_time', '_cast_time',
        'start_time', '_start_time', 'begin_time'
    ))
    start_time = _normalize_timepoint_value(start_time, now_time)
    if duration_seconds is not None and start_time is not None and now_time > 0.0:
        return max(0.0, duration_seconds - max(0.0, now_time - start_time))

    logic_obj = getattr(skill_obj, 'logic', None)
    if logic_obj:
        duration_seconds = _read_first_reasonable_time_value(logic_obj, (
            'skill_duration', 'duration', '_duration', 'total_time', 'max_time',
            'check_time', '_check_time', 'special_time'
        ), _normalize_duration_seconds)
        start_time = _read_first_timepoint_value(logic_obj, (
            'start_cast_time', '_start_cast_time', 'cast_time', '_cast_time',
            'start_time', '_start_time', 'begin_time'
        ))
        start_time = _normalize_timepoint_value(start_time, now_time)
        if duration_seconds is not None and start_time is not None and now_time > 0.0:
            return max(0.0, duration_seconds - max(0.0, now_time - start_time))
    return None

def _resolve_buff_remaining_seconds(buff_obj, buff_level_data=None, now_time=None):
    if not buff_obj:
        return None
    remaining_attr_names = (
        'left_time', 'remain_time', 'remaining_time', '_left_time', '_remain_time',
        'rest_time', 'buff_left_time', 'effect_left_time', 'duration_left', 'time_left'
    )
    duration_attr_names = (
        'life_time', 'special_time', 'buff_time', 'effect_time', '_duration', 'duration',
        'total_time', 'max_time', 'keep_time', 'check_time', '_check_time'
    )
    start_attr_names = (
        'init_time', 'start_time', '_start_time', 'begin_time', '_begin_time',
        'cast_time', '_cast_time', 'create_time'
    )
    resolved_left_time = _read_first_reasonable_time_value(buff_obj, remaining_attr_names, _normalize_remaining_seconds)
    if resolved_left_time is not None:
        return resolved_left_time

    existence_time = None
    try:
        getter = getattr(buff_obj, 'get_existence_time', None)
        if callable(getter):
            existence_time = _normalize_remaining_seconds(getter())
    except:
        existence_time = None

    total_time = _read_first_reasonable_time_value(buff_obj, duration_attr_names, _normalize_duration_seconds)
    if total_time is None and isinstance(buff_level_data, dict):
        try:
            total_time = _normalize_duration_seconds(buff_level_data.get('special_time', None))
        except:
            total_time = None
        if total_time is None:
            try:
                total_time = _normalize_duration_seconds(buff_level_data.get('life_time', None))
            except:
                total_time = None

    start_time = _read_first_timepoint_value(buff_obj, start_attr_names)
    start_time = _normalize_timepoint_value(start_time, now_time)
    if total_time is not None and start_time is not None:
        if now_time is None or now_time <= 0.0:
            now_time = _get_room_game_time_fallback()
        if now_time > 0.0:
            return max(0.0, total_time - max(0.0, now_time - start_time))

    if total_time is not None and existence_time is not None:
        return max(0.0, total_time - existence_time)
    return None

def _append_fragrance_payload(player_info, unit):
    try:
        from common_cs import ComuKeys
    except:
        return
    try:
        now_time = _get_room_game_time_fallback()
        current_uid = str(getattr(unit, 'uid', '') or '')
        fragrance_debug_parts = []

        fragrance_item = None
        fragrance_type = int(getattr(getattr(ComuKeys, 'ITEM_TYPE_CONF', None), 'FRAGRANCE', 0) or 0)
        for item in _iter_unit_hold_items(unit):
            try:
                if int(getattr(item, 'type', 0) or 0) == fragrance_type:
                    fragrance_item = item
                    break
            except:
                pass

        skill_mgr = getattr(unit, 'skill_mgr', None)
        fragrance_back_skill = None
        fragrance_image_skill = None
        fragrance_item_skill = None
        try:
            getter = getattr(skill_mgr, 'get_skill_obj_with_type', None) if skill_mgr else None
            if callable(getter):
                back_list = getter(ComuKeys.SKILL_TYPE.CIVILIAN_FRAGRANCE_BACK)
                if back_list:
                    fragrance_back_skill = back_list[0]
                image_list = getter(ComuKeys.SKILL_TYPE.CIVILIAN_FRAGRANCE_IMAGE)
                if image_list:
                    fragrance_image_skill = image_list[0]
        except:
            pass
        try:
            if fragrance_item and skill_mgr:
                item_data = getattr(fragrance_item, 'data', None) or {}
                skill_ids = item_data.get('cvn_skill_id', None) if isinstance(item_data, dict) else None
                if skill_ids:
                    item_skill_id = int(skill_ids[0] or 0)
                    if item_skill_id:
                        skill_dict = getattr(skill_mgr, 'skill_dict', None) or {}
                        fragrance_item_skill = skill_dict.get(item_skill_id)
        except:
            pass

        active = False
        try:
            active = bool(getattr(unit, 'is_using_fragrance', False))
        except:
            active = False
        fragrance_debug_parts.append('unit_using=%d' % (1 if active else 0))
        try:
            if fragrance_item and bool(getattr(fragrance_item, 'b_in_use', False)):
                active = True
        except:
            pass
        try:
            if fragrance_back_skill and bool(getattr(fragrance_back_skill, 'is_casting', False)):
                active = True
        except:
            pass
        try:
            if fragrance_image_skill and bool(getattr(fragrance_image_skill, 'is_casting', False)):
                active = True
        except:
            pass
        try:
            if fragrance_item_skill and bool(getattr(fragrance_item_skill, 'is_casting', False)):
                active = True
        except:
            pass

        fragrance_image_exists = False
        fragrance_image_uid = None
        fragrance_need_create_again = None
        fragrance_alpha_speed = None
        fragrance_delay_cancel = None
        fragrance_dissolve_handler = None
        try:
            fragrance_image = getattr(unit, '_fragrance_image', None)
            fragrance_image_exists = bool(fragrance_image)
        except:
            fragrance_image_exists = False
        try:
            fragrance_image_uid = getattr(unit, '_fragrance_image_uid', None)
        except:
            fragrance_image_uid = None
        try:
            need_create_again = getattr(unit, 'need_create_image_again', None)
            if callable(need_create_again):
                fragrance_need_create_again = bool(need_create_again())
        except:
            fragrance_need_create_again = None
        try:
            fragrance_alpha_speed = getattr(unit, '_fragrance_alpha_speed', None)
        except:
            fragrance_alpha_speed = None
        try:
            fragrance_delay_cancel = getattr(unit, 'fragrance_delay_cancel', None)
        except:
            fragrance_delay_cancel = None
        try:
            fragrance_dissolve_handler = getattr(unit, 'fragrance_dissolve_handler', None)
        except:
            fragrance_dissolve_handler = None

        fragrance_left_time = None
        fragrance_total_time = None
        back_skill_left_time = None
        image_skill_left_time = None
        item_skill_left_time = None
        for skill_obj in (fragrance_back_skill, fragrance_image_skill, fragrance_item_skill):
            if not skill_obj:
                continue
            try:
                if not bool(getattr(skill_obj, 'is_casting', False)):
                    continue
            except:
                pass
            current_skill_left_time = _read_skill_active_remaining_seconds(skill_obj, unit)
            if skill_obj is fragrance_back_skill:
                back_skill_left_time = current_skill_left_time
            elif skill_obj is fragrance_image_skill:
                image_skill_left_time = current_skill_left_time
            elif skill_obj is fragrance_item_skill:
                item_skill_left_time = current_skill_left_time
            fragrance_left_time = current_skill_left_time
            if fragrance_left_time is not None and fragrance_left_time > 0.0:
                fragrance_total_time = _read_first_reasonable_time_value(skill_obj, (
                    'skill_duration', 'duration', '_duration', 'total_time', 'max_time',
                    'check_time', '_check_time'
                ), _normalize_duration_seconds)
                break

        item_left_time = None
        item_total_time = None
        item_b_in_use = False
        if fragrance_item:
            try:
                item_b_in_use = bool(getattr(fragrance_item, 'b_in_use', False))
            except:
                item_b_in_use = False
            item_left_time = _read_item_active_remaining_seconds(fragrance_item)
            item_total_time = _read_item_active_duration_seconds(fragrance_item)
            if item_left_time is not None and item_left_time > 0.0:
                if item_total_time is not None and item_left_time + 0.05 < item_total_time:
                    fragrance_left_time = item_left_time
                    fragrance_total_time = item_total_time
                    active = True
                elif active and item_total_time is not None and fragrance_left_time is None:
                    fragrance_left_time = item_total_time
                    fragrance_total_time = item_total_time

        if fragrance_left_time is None and fragrance_item and active and now_time > 0.0:
            try:
                item_cd_time = float(getattr(fragrance_item, 'item_cd_time', 0.0) or 0.0)
                cd_delta = item_cd_time - now_time
                if 0.0 <= cd_delta <= 10.0:
                    fragrance_left_time = cd_delta
                    fragrance_total_time = item_total_time
            except:
                pass

        if fragrance_left_time is None and active and item_total_time is not None and item_total_time > 0.0:
            fragrance_left_time = item_total_time
            fragrance_total_time = item_total_time

        legacy_left_time = fragrance_left_time
        cache_left_time = None
        trigger_using = False
        fragrance_cd_time = None
        cd_changed = False
        try:
            trigger_using = bool(getattr(unit, 'is_using_fragrance', False)) or bool(item_b_in_use)
        except:
            trigger_using = bool(item_b_in_use)
        try:
            if fragrance_item:
                fragrance_cd_time = float(getattr(fragrance_item, 'item_cd_time', 0.0) or 0.0)
        except:
            fragrance_cd_time = None

        if current_uid:
            fragrance_cache_entry = SPECIAL_STATE_CACHE["fragrance"].get(current_uid, {}) or {}
            previous_using = bool(fragrance_cache_entry.get("using_signal", False))
            previous_cd_time = fragrance_cache_entry.get("item_cd_time", None)
            try:
                if previous_cd_time is not None and fragrance_cd_time is not None and abs(float(previous_cd_time) - float(fragrance_cd_time)) > 0.01:
                    cd_changed = True
            except:
                cd_changed = False

            if cd_changed:
                fragrance_cache_entry["countdown_active"] = False
                fragrance_cache_entry["end_time"] = 0.0
            elif trigger_using and not previous_using:
                fragrance_cache_entry["countdown_active"] = True
                fragrance_cache_entry["end_time"] = now_time + 5.0

            if bool(fragrance_cache_entry.get("countdown_active", False)):
                cache_end_time = float(fragrance_cache_entry.get("end_time", 0.0) or 0.0)
                cache_left_time = max(0.0, cache_end_time - now_time)
                if cache_left_time <= 0.0:
                    fragrance_cache_entry["countdown_active"] = False
                    fragrance_cache_entry["end_time"] = 0.0
                    cache_left_time = None

            fragrance_cache_entry["using_signal"] = bool(trigger_using)
            fragrance_cache_entry["item_cd_time"] = fragrance_cd_time
            fragrance_cache_entry["last_seen_time"] = now_time
            SPECIAL_STATE_CACHE["fragrance"][current_uid] = fragrance_cache_entry

        fragrance_left_time = cache_left_time

        try:
            if back_skill_left_time is None and fragrance_back_skill:
                back_skill_left_time = _read_skill_active_remaining_seconds(fragrance_back_skill, unit)
        except:
            pass
        try:
            if image_skill_left_time is None and fragrance_image_skill:
                image_skill_left_time = _read_skill_active_remaining_seconds(fragrance_image_skill, unit)
        except:
            pass
        try:
            if item_skill_left_time is None and fragrance_item_skill:
                item_skill_left_time = _read_skill_active_remaining_seconds(fragrance_item_skill, unit)
        except:
            pass

        def _fmt_fragrance_debug_value(value):
            try:
                if value is None:
                    return 'None'
                return '%.2f' % float(value)
            except:
                return 'Err'

        def _fmt_fragrance_debug_text(value):
            try:
                if value is None:
                    return 'None'
                text = str(value)
                if len(text) > 24:
                    text = text[:24]
                return text
            except:
                return 'Err'

        fragrance_debug_parts.append('item=%d' % (1 if fragrance_item else 0))
        fragrance_debug_parts.append('item_in_use=%d' % (1 if item_b_in_use else 0))
        fragrance_debug_parts.append('item_left=%s' % _fmt_fragrance_debug_value(item_left_time))
        fragrance_debug_parts.append('item_total=%s' % _fmt_fragrance_debug_value(item_total_time))
        try:
            fragrance_debug_parts.append('item_raw_left=%s' % _fmt_fragrance_debug_value(getattr(fragrance_item, '_remain_lifespan', None) if fragrance_item else None))
            fragrance_debug_parts.append('item_raw_total=%s' % _fmt_fragrance_debug_value(getattr(fragrance_item, '_init_lifespan', None) if fragrance_item else None))
            fragrance_debug_parts.append('item_cd=%s' % _fmt_fragrance_debug_value(getattr(fragrance_item, 'item_cd_time', None) if fragrance_item else None))
            fragrance_debug_parts.append('life_cycle=%s' % _fmt_fragrance_debug_text(getattr(fragrance_item, 'life_cycle', None) if fragrance_item else None))
        except:
            pass
        try:
            item_data = getattr(fragrance_item, 'data', None) if fragrance_item else None
            skill_ids = item_data.get('cvn_skill_id', None) if isinstance(item_data, dict) else None
            fragrance_debug_parts.append('cvn=%s' % _fmt_fragrance_debug_text(skill_ids))
            fragrance_debug_parts.append('arg1=%s' % _fmt_fragrance_debug_text(item_data.get('item_arg1', None) if isinstance(item_data, dict) else None))
            fragrance_debug_parts.append('arg2=%s' % _fmt_fragrance_debug_text(item_data.get('item_arg2', None) if isinstance(item_data, dict) else None))
            fragrance_debug_parts.append('arg3=%s' % _fmt_fragrance_debug_text(item_data.get('item_arg3', None) if isinstance(item_data, dict) else None))
            fragrance_debug_parts.append('arg4=%s' % _fmt_fragrance_debug_text(item_data.get('item_arg4', None) if isinstance(item_data, dict) else None))
        except:
            pass
        fragrance_debug_parts.append('back_cast=%d' % (1 if fragrance_back_skill and bool(getattr(fragrance_back_skill, 'is_casting', False)) else 0))
        fragrance_debug_parts.append('back_left=%s' % _fmt_fragrance_debug_value(back_skill_left_time))
        fragrance_debug_parts.append('image_cast=%d' % (1 if fragrance_image_skill and bool(getattr(fragrance_image_skill, 'is_casting', False)) else 0))
        fragrance_debug_parts.append('image_left=%s' % _fmt_fragrance_debug_value(image_skill_left_time))
        fragrance_debug_parts.append('item_skill_cast=%d' % (1 if fragrance_item_skill and bool(getattr(fragrance_item_skill, 'is_casting', False)) else 0))
        fragrance_debug_parts.append('item_skill_left=%s' % _fmt_fragrance_debug_value(item_skill_left_time))
        fragrance_debug_parts.append('img=%d' % (1 if fragrance_image_exists else 0))
        fragrance_debug_parts.append('img_uid=%s' % _fmt_fragrance_debug_text(fragrance_image_uid))
        fragrance_debug_parts.append('img_again=%s' % _fmt_fragrance_debug_text(fragrance_need_create_again))
        fragrance_debug_parts.append('alpha_spd=%s' % _fmt_fragrance_debug_value(fragrance_alpha_speed))
        fragrance_debug_parts.append('delay=%s' % _fmt_fragrance_debug_text(fragrance_delay_cancel))
        fragrance_debug_parts.append('dissolve=%s' % _fmt_fragrance_debug_text(fragrance_dissolve_handler))
        fragrance_debug_parts.append('trigger=%d' % (1 if trigger_using else 0))
        fragrance_debug_parts.append('cd_changed=%d' % (1 if cd_changed else 0))
        fragrance_debug_parts.append('legacy_left=%s' % _fmt_fragrance_debug_value(legacy_left_time))
        fragrance_debug_parts.append('cache_left=%s' % _fmt_fragrance_debug_value(cache_left_time))
        fragrance_debug_parts.append('out_left=%s' % _fmt_fragrance_debug_value(fragrance_left_time))
        player_info["fragrance_debug"] = ' | '.join(fragrance_debug_parts)

        if fragrance_left_time is None or fragrance_left_time <= 0.0:
            return
        player_info["fragrance_active"] = True
        player_info["fragrance_left_time"] = round(max(0.0, float(fragrance_left_time)), 1)
    except:
        pass

def _append_action_unit_payload(actions_data, work_item, include_casting_skills, include_debug_vectors, capture_models):
    try:
        unit = (work_item or {}).get("unit")
        if not unit:
            return
        forced_unit_type = work_item.get("forced_unit_type")
        forced_pid = work_item.get("forced_pid")
        unit_type = forced_unit_type if forced_unit_type is not None else int(getattr(unit, 'unit_type', 0))
        player_info = {
            "pid": int(forced_pid if forced_pid is not None else getattr(unit, 'pid', 0)),
            "uid": get_action_unit_uid(unit),
            "unit_type": unit_type,
            "is_yidhra_puppet": bool(work_item.get("is_yidhra_puppet")),
            "is_mary_mirror": bool(work_item.get("is_mary_mirror")),
            "state": "",
            "pos": [0.0, 0.0, 0.0]
        }
        try:
            if hasattr(unit, 'get_position3'):
                pos = unit.get_position3()
                if pos:
                    player_info["pos"] = [float(pos.x), float(pos.y), float(pos.z)]
        except:
            pass
        try:
            if hasattr(unit, 'state_machine') and unit.state_machine:
                states = getattr(unit.state_machine, 'state', None)
                if states is not None:
                    player_info["state"] = str(states)
        except:
            pass
        if _hook_need_special_countdown_enabled():
            try:
                current_uid = str(player_info.get("uid", "") or "")
                struggle_cache = SPECIAL_STATE_CACHE.get("struggle", {}).get(current_uid)
                if struggle_cache:
                    struggle_value = float(struggle_cache.get("value", 0.0) or 0.0)
                    struggle_speed = float(struggle_cache.get("speed", 0.0) or 0.0)
                    update_time = float(struggle_cache.get("update_time", 0.0) or 0.0)
                    now_time = _get_room_game_time_fallback()
                    if now_time > 0.0 and update_time > 0.0:
                        delta_time = max(0.0, now_time - update_time)
                        struggle_value = struggle_value + struggle_speed * delta_time
                    struggle_value = max(0.0, min(100.0, struggle_value))
                    player_info["struggle_flag"] = struggle_value > 0.0 and struggle_value < 100.0
                    player_info["struggle_value"] = round(struggle_value, 1)
                    player_info["struggle_speed"] = round(struggle_speed, 3)
            except:
                pass
            try:
                marionette_mgr = getattr(unit, 'marionette_mgr', None)
                if marionette_mgr:
                    marionette_hp = getattr(marionette_mgr, 'marionette_hp', None)
                    marionette_hp_max = getattr(marionette_mgr, 'marionette_hp_max', None)
                    marionette_progress = getattr(marionette_mgr, 'change_progress_acc', None)
                    marionette_duration = getattr(marionette_mgr, 'marionette_retention_duration', None)
                    visual_ex_hp = getattr(marionette_mgr, 'visual_ex_hp', None)
                    could_cast_immune = getattr(marionette_mgr, 'could_cast_immune', None)
                    if marionette_hp is not None:
                        marionette_hp = float(marionette_hp)
                        player_info["marionette_hp"] = round(marionette_hp, 1)
                    else:
                        marionette_hp = None
                    if marionette_hp_max is not None:
                        marionette_hp_max = float(marionette_hp_max)
                        player_info["marionette_hp_max"] = round(marionette_hp_max, 1)
                    else:
                        marionette_hp_max = None
                    if marionette_progress is not None:
                        marionette_progress = max(0.0, min(1.0, float(marionette_progress)))
                        player_info["marionette_progress"] = round(marionette_progress, 4)
                    else:
                        marionette_progress = None
                    if marionette_duration is not None:
                        marionette_duration = max(0.0, float(marionette_duration))
                        player_info["marionette_duration"] = round(marionette_duration, 3)
                    else:
                        marionette_duration = None
                    if visual_ex_hp is not None:
                        player_info["marionette_visual_hp"] = round(float(visual_ex_hp), 1)
                    marionette_ready = False
                    if could_cast_immune is not None:
                        marionette_ready = bool(could_cast_immune)
                        player_info["marionette_could_cast_immune"] = marionette_ready
                    marionette_left_time = None
                    if marionette_duration is not None and marionette_progress is not None:
                        marionette_left_time = max(0.0, marionette_duration * (1.0 - marionette_progress))
                    if (marionette_left_time is None or marionette_left_time <= 0.05) and marionette_ready and marionette_duration is not None:
                        marionette_left_time = max(0.0, float(marionette_duration))
                    if marionette_left_time is not None:
                        player_info["marionette_left_time"] = round(marionette_left_time, 1)

                    active_marionette = False
                    if marionette_progress is not None and marionette_progress > 0.0001 and marionette_progress < 0.999:
                        active_marionette = True
                    elif marionette_left_time is not None and marionette_left_time > 0.05 and not marionette_ready:
                        active_marionette = True
                    elif marionette_hp is not None and marionette_hp > 0.0 and not marionette_ready:
                        active_marionette = True

                    if active_marionette:
                        player_info["marionette_active"] = True
                    if marionette_ready:
                        player_info["marionette_ready"] = True
            except:
                pass
            try:
                _append_fragrance_payload(player_info, unit)
            except:
                pass
        if include_casting_skills:
            try:
                player_info["casting_skills"] = build_unit_casting_skills(unit)
            except:
                pass
        if include_debug_vectors:
            try:
                if hasattr(unit, 'get_direction3'):
                    dir_vec = unit.get_direction3()
                    if dir_vec:
                        player_info["direction"] = [float(dir_vec.x), float(dir_vec.y), float(dir_vec.z)]
            except:
                pass
            try:
                if hasattr(unit, 'speed_real'):
                    player_info["speed_real"] = float(getattr(unit, 'speed_real', 0.0) or 0.0)
            except:
                pass
        if capture_models:
            try:
                player_info["model_path"] = get_unit_model_full_path(unit)
            except:
                pass
        actions_data["players"].append(player_info)
    except:
        pass

def _run_incremental_action_collector(loop_now=None, start_new=False):
    state = INCREMENTAL_COLLECTOR_STATE.get("actions", {})
    if start_new or not state.get("active"):
        state["active"] = True
        state["pending_units"] = _collect_action_unit_work_items()
        state["index"] = 0
        state["result"] = _build_action_payload_base()
        state["include_casting_skills"] = _hook_actions_need_casting_skills()
        state["include_debug_vectors"] = _hook_actions_need_debug_vectors()
        state["capture_models"] = get_hook_control_flag("need_capture_player_models")
    pending_units = state.get("pending_units", []) or []
    result = state.get("result") or _build_action_payload_base()
    index = int(state.get("index", 0) or 0)
    end_index = min(len(pending_units), index + INCREMENTAL_ACTION_CHUNK_SIZE)
    for current_index in range(index, end_index):
        _append_action_unit_payload(
            result,
            pending_units[current_index],
            bool(state.get("include_casting_skills")),
            bool(state.get("include_debug_vectors")),
            bool(state.get("capture_models"))
        )
    state["index"] = end_index
    state["result"] = result
    if end_index >= len(pending_units):
        payload = json.dumps(result)
        _reset_incremental_collector("actions")
        return payload
    return None

def collect_action_data():
    actions_data = _build_action_payload_base()
    try:
        include_casting_skills = _hook_actions_need_casting_skills()
        include_debug_vectors = _hook_actions_need_debug_vectors()
        capture_models = get_hook_control_flag("need_capture_player_models")
        for work_item in _collect_action_unit_work_items():
            _append_action_unit_payload(actions_data, work_item, include_casting_skills, include_debug_vectors, capture_models)
    except:
        pass
    return json.dumps(actions_data)

def collect_hunter_fast_actions_data():
    payload = {"type": "hunter_fast_actions", "players": []}
    try:
        unit_mgr = get_available_unit_mgr()
        players = safe_get_units_from_mgr(unit_mgr, 'get_player_units')

        def append_hunter_action_unit(unit, forced_unit_type=None, forced_pid=None, is_yidhra_puppet=False, is_mary_mirror=False):
            if not unit:
                return
            uid = get_action_unit_uid(unit)
            if uid == "unknown" or uid == "":
                return

            unit_type = forced_unit_type
            if unit_type is None:
                unit_type = int(getattr(unit, 'unit_type', 0))

            player_info = {
                "pid": int(forced_pid if forced_pid is not None else getattr(unit, 'pid', 0)),
                "uid": uid,
                "unit_type": unit_type,
                "is_yidhra_puppet": bool(is_yidhra_puppet),
                "is_mary_mirror": bool(is_mary_mirror),
                "casting_skills": [],
                "pos": [0.0, 0.0, 0.0]
            }

            try:
                if hasattr(unit, 'get_position3'):
                    pos = unit.get_position3()
                    if pos:
                        player_info["pos"] = [float(pos.x), float(pos.y), float(pos.z)]
            except:
                pass

            try:
                player_info["casting_skills"] = build_unit_casting_skills(unit)
            except:
                pass

            payload["players"].append(player_info)

        for player in players or []:
            try:
                unit_type = int(getattr(player, 'unit_type', 0))
            except:
                unit_type = 0
            if unit_type == 1 or bool(getattr(player, 'is_butcher', False)):
                append_hunter_action_unit(player)

        try:
            from common_cs import ComuKeys
            room = getattr(GK.g_unit, 'room', None) if hasattr(GK, 'g_unit') and GK.g_unit else None
            room_unit_mgr = getattr(room, 'unit_mgr', None) if room else None
            if room_unit_mgr:
                puppets = safe_get_units_by_type_from_mgr(room_unit_mgr, ComuKeys.UNIT_TYPE_CONF.YIDHRA_PUPPET)
                for puppet in puppets or []:
                    try:
                        if puppet and getattr(puppet, 'is_yidhra_puppet', False):
                            append_hunter_action_unit(puppet, forced_unit_type=1, forced_pid=81, is_yidhra_puppet=True)
                    except:
                        pass
        except:
            pass

        try:
            room = getattr(GK.g_unit, 'room', None) if hasattr(GK, 'g_unit') and GK.g_unit else None
            room_unit_mgr = getattr(room, 'unit_mgr', None) if room else None
            if room_unit_mgr:
                mary_images = safe_get_units_by_type_from_mgr(room_unit_mgr, 247)
                for image in mary_images or []:
                    try:
                        if image:
                            append_hunter_action_unit(image, forced_unit_type=1, forced_pid=85, is_mary_mirror=True)
                    except:
                        pass
        except:
            pass
    except:
        pass
    return json.dumps(payload)

def collect_self_batter_auto_cancel_data():
    payload = {"type": "self_batter_skill", "valid": False, "uid": "unknown", "pid": 0, "casting_skills": []}
    try:
        me = getattr(GK, 'g_unit', None)
        if not me:
            return json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(',', ':'))

        pid = int(getattr(me, 'pid', 0) or 0)
        payload["uid"] = get_player_uid(me)
        payload["pid"] = pid
        if pid != 106:
            return json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(',', ':'))

        casting_skills = []
        try:
            if hasattr(me, 'skill_mgr') and me.skill_mgr and hasattr(me.skill_mgr, 'get_casting_skill'):
                skill_list = me.skill_mgr.get_casting_skill()
                if skill_list:
                    for skill in skill_list:
                        skill_id = str(getattr(skill, 'skill_id', ''))
                        skill_type = str(getattr(skill, 'skill_type', ''))
                        if skill_id and skill_type:
                            casting_skills.append({
                                "skill_id": skill_id,
                                "skill_type": skill_type
                            })
        except:
            pass

        if not casting_skills:
            try:
                if hasattr(me, 'skill_mgr') and me.skill_mgr:
                    current_ids = list(getattr(me.skill_mgr, 'current_skill_ex', set()) or [])
                    current_ids.sort()
                    for skill_id in current_ids:
                        skill_type = ''
                        try:
                            so = me.skill_mgr.get_skill_obj(skill_id)
                            if so:
                                skill_type = str(getattr(so, 'skill_type', ''))
                        except:
                            pass
                        if not skill_type:
                            try:
                                sd = me.get_skill_data(skill_id)
                                if sd:
                                    skill_type = str(sd.get('skill_type', ''))
                            except:
                                pass
                        if skill_type:
                            casting_skills.append({
                                "skill_id": str(skill_id),
                                "skill_type": skill_type
                            })
            except:
                pass

        payload["casting_skills"] = casting_skills
        payload["valid"] = True
    except Exception as e:
        payload["error"] = str(e)

    return json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(',', ':'))

def should_collect_self_batter_auto_cancel():
    try:
        if not get_hook_control_flag("need_batter_auto_cancel"):
            return False
        me = getattr(GK, 'g_unit', None)
        if not me:
            return False
        return int(getattr(me, 'pid', 0) or 0) == 106
    except:
        return False

def collect_matrix_raw_data():
    matrix_data = {"type": "matrix_raw", "valid": False}
    try:
        if not hasattr(GK, 'g_world_mgr') or not GK.g_world_mgr or not GK.g_world_mgr.cur_world:
            return json.dumps(matrix_data)

        cam = getattr(GK.g_world_mgr.cur_world, 'cam', None)
        if not cam:
            return json.dumps(matrix_data)

        world_mat = getattr(cam, 'transformation', None)
        proj_mat = getattr(cam, 'projection_matrix', None)
        if not world_mat or not proj_mat:
            return json.dumps(matrix_data)

        right = getattr(world_mat, 'right', None)
        up = getattr(world_mat, 'up', None)
        forward = getattr(world_mat, 'forward', None)
        translation = getattr(world_mat, 'translation', None)
        if not right or not up or not forward or not translation:
            return json.dumps(matrix_data)

        projection = []
        if hasattr(proj_mat, 'm11'):
            projection = [
                float(proj_mat.m11), float(proj_mat.m12), float(proj_mat.m13), float(proj_mat.m14),
                float(proj_mat.m21), float(proj_mat.m22), float(proj_mat.m23), float(proj_mat.m24),
                float(proj_mat.m31), float(proj_mat.m32), float(proj_mat.m33), float(proj_mat.m34),
                float(proj_mat.m41), float(proj_mat.m42), float(proj_mat.m43), float(proj_mat.m44)
            ]
        elif hasattr(proj_mat, 'get'):
            for i in range(4):
                for j in range(4):
                    projection.append(float(proj_mat.get(i, j)))

        if len(projection) != 16:
            return json.dumps(matrix_data)

        matrix_data = {
            "type": "matrix_raw",
            "valid": True,
            "right": [float(right.x), float(right.y), float(right.z)],
            "up": [float(up.x), float(up.y), float(up.z)],
            "forward": [float(forward.x), float(forward.y), float(forward.z)],
            "translation": [float(translation.x), float(translation.y), float(translation.z)],
            "projection": projection
        }
    except:
        pass

    return json.dumps(matrix_data)

def collect_violin_note_data():
    note_data = {
        "type": "violin_notes",
        "valid": False,
        "first_valid": False,
        "second_valid": False,
        "first": [0.0, 0.0, 0.0],
        "second": [0.0, 0.0, 0.0]
    }
    try:
        player = getattr(GK, 'g_unit', None)
        if not player:
            return json.dumps(note_data)

        if not hasattr(GK, 'g_world_mgr') or not GK.g_world_mgr or not GK.g_world_mgr.cur_world:
            return json.dumps(note_data)

        world = GK.g_world_mgr.cur_world
        note_mgr = getattr(world, 'violin_note_mgr', None)

        if note_mgr and hasattr(note_mgr, 'get_first_note'):
            first_note = note_mgr.get_first_note(player.uid)
            if first_note and hasattr(first_note, 'get_target_point'):
                pos = first_note.get_target_point()
                if pos:
                    note_data["first_valid"] = True
                    note_data["first"] = [float(pos.x), float(pos.y), float(pos.z)]

        if hasattr(player, 'skill_mgr') and player.skill_mgr:
            casting_skills = player.skill_mgr.get_casting_skill()
            if casting_skills:
                for skill in casting_skills:
                    visual = getattr(skill, 'visual', None)
                    if visual:
                        indicator = getattr(visual, 'casting_indicator', None)
                        if indicator and hasattr(indicator, 'get_result'):
                            pos = indicator.get_result('pos')
                            if pos:
                                note_data["second_valid"] = True
                                note_data["second"] = [float(pos.x), float(pos.y), float(pos.z)]
                                break

        note_data["valid"] = note_data["first_valid"] or note_data["second_valid"]
    except:
        pass

    return json.dumps(note_data)

def collect_wuchang_umbrella_data():
    umbrella_data = {
        "type": "wuchang_umbrella",
        "valid": False,
        "source": "",
        "pos": [0.0, 0.0, 0.0]
    }
    try:
        player = getattr(GK, 'g_unit', None)
        if not player:
            return json.dumps(umbrella_data)

        found = False

        if hasattr(player, 'skill_mgr') and player.skill_mgr:
            casting_skills = player.skill_mgr.get_casting_skill()
            if casting_skills:
                for skill in casting_skills:
                    visual = getattr(skill, 'visual', None)
                    if visual:
                        indicator = getattr(visual, 'casting_indicator', None)
                        if indicator and hasattr(indicator, 'get_result'):
                            target_pos = indicator.get_result('pos')
                            if target_pos:
                                umbrella_data["valid"] = True
                                umbrella_data["source"] = "casting_indicator"
                                umbrella_data["pos"] = [float(target_pos.x), float(target_pos.y), float(target_pos.z)]
                                found = True
                                break

        if not found and hasattr(player, 'imper_umbrella_position') and player.imper_umbrella_position:
            pos = player.imper_umbrella_position
            umbrella_data["valid"] = True
            umbrella_data["source"] = "imper_umbrella_position"
            umbrella_data["pos"] = [float(pos.x), float(pos.y), float(pos.z)]
    except:
        pass

    return json.dumps(umbrella_data)

def collect_mary_mirror_data():
    mirror_data = {
        "type": "mary_mirror",
        "valid": False,
        "aiming_valid": False,
        "placed_valid": False,
        "image_valid": False,
        "aiming_pos": [0.0, 0.0, 0.0],
        "mirror_pos": [0.0, 0.0, 0.0],
        "image_pos": [0.0, 0.0, 0.0]
    }
    try:
        unit = getattr(GK, 'g_unit', None)
        if not unit or not hasattr(unit, 'skill_mgr') or not unit.skill_mgr:
            return json.dumps(mirror_data)

        room = getattr(unit, 'room', None)
        unit_mgr = get_available_unit_mgr()

        casting_skills = []
        if hasattr(unit.skill_mgr, 'get_casting_skill'):
            casting_skills = unit.skill_mgr.get_casting_skill()

        for skill in casting_skills or []:
            indicator = getattr(skill, 'casting_indicator', None)
            if not indicator and hasattr(skill, 'visual'):
                indicator = getattr(skill.visual, 'casting_indicator', None)

            if indicator and hasattr(indicator, 'get_result'):
                target_pos = indicator.get_result('pos')
                if target_pos:
                    mirror_data["aiming_valid"] = True
                    mirror_data["aiming_pos"] = [float(target_pos.x), float(target_pos.y), float(target_pos.z)]
                    mirror_data["valid"] = True
                    break

        if unit_mgr:
            try:
                mirrors = safe_get_units_by_type_from_mgr(unit_mgr, 246)
                if mirrors:
                    for m in mirrors:
                        if hasattr(m, 'get_position3'):
                            m_pos = m.get_position3()
                            if m_pos:
                                mirror_data["placed_valid"] = True
                                mirror_data["mirror_pos"] = [float(m_pos.x), float(m_pos.y), float(m_pos.z)]
                                mirror_data["valid"] = True
                                break
            except:
                pass

            try:
                images = safe_get_units_by_type_from_mgr(unit_mgr, 247)
                if images:
                    for img in images:
                        if hasattr(img, 'get_position3'):
                            i_pos = img.get_position3()
                            if i_pos:
                                mirror_data["image_valid"] = True
                                mirror_data["image_pos"] = [float(i_pos.x), float(i_pos.y), float(i_pos.z)]
                                mirror_data["valid"] = True
                                break
            except:
                pass
    except:
        pass

    return json.dumps(mirror_data)

SPECIAL_UNIT_TYPE_NAMES = {
    246: "