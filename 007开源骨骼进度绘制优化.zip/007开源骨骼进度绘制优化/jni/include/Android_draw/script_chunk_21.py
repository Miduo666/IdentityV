
            try:
                candidate_gen_info = _dict_get(candidate, "gen_info") or {}
                candidate_level = int(_dict_get(candidate_gen_info, "level") or 0)
                if candidate_level > 0:
                    gen_info = dict(candidate_gen_info) if isinstance(candidate_gen_info, dict) else {"level": candidate_level}
                    level_value = candidate_level
            except:
                pass
        if level_value <= 0 and candidate is not None:
            fallback_level = 0
            try:
                level_by_box_id = _dict_get(candidate, "level_by_box_id") or {}
                fallback_level = int(level_by_box_id.get(_safe_int(box_id, -1), 0) or 0)
            except:
                fallback_level = 0
            if fallback_level <= 0:
                fallback_level = _safe_int(_dict_get(candidate, "fallback_level"), 0)
            if fallback_level > 0:
                patched_gen_info = {}
                try:
                    patched_gen_info = dict(gen_info) if isinstance(gen_info, dict) else {}
                except:
                    patched_gen_info = {}
                patched_gen_info["level"] = fallback_level
                gen_info = patched_gen_info
        gen_info = _freeze_gen_info(gen_info)
        selected.append({
            "model_name": model_name,
            "room_index": room_index,
            "world_position": world_position,
            "gen_info": gen_info,
            "box_id": box_id
        })
    return selected

def _run_seed_a_plus_replay(combat_core):
    # #region debug-point D:seed-replay-start
    debug_started_at = time.time()
    # #endregion
    result = {
        "ok": False,
        "selected_count": 0,
        "generation_seed": None,
        "now_round_seed": None,
        "candidate_count": 0,
        "collected_candidate_count": 0,
        "postprocess_group_counts": {},
        "candidate_lookup_stats": {},
        "runtime_token_validation": {"stable": False},
        "items": [],
        "errors": [],
        "reason": ""
    }
    try:
        maze_sys = _get_maze_system(combat_core)
        if not combat_core or not maze_sys:
            result["reason"] = "combat_core_or_maze_sys_missing"
            return result
        runtime_token_before = _build_goldrush_runtime_token(combat_core, maze_sys)
        before_seed = _normalize_goldrush_generation_seed(_get_goldrush_generation_seed_strict(maze_sys))
        result["now_round_seed"] = runtime_token_before.get("now_round_seed")
        candidates = _build_chest_candidates(combat_core, maze_sys)
        candidate_lookup = _build_candidate_lookup(candidates)
        result["candidate_count"] = len(candidates)
        result["candidate_lookup_stats"] = {
            "collision_count": _safe_int(candidate_lookup.get("collision_count", 0), 0),
            "collisions": list(candidate_lookup.get("collisions", []) or [])
        }
        if result["candidate_count"] <= 0:
            result["reason"] = "candidate_not_ready"
            return result
        from common_cs.combat_core.enum_types.SystemType import SystemType
        from common_cs.combat_core.systems.systems_goldrush.maze.MazeMapEntityGenerator import GoldRushMazeEntityGenerator
        replay_core = _ReplayCore(combat_core, result, SystemType)
        replay_generation_system = _ReplayGenerationSystem(maze_sys, replay_core)
        result["generation_seed"] = replay_generation_system.get_generation_seed()
        replay_generation_system.maze_object = _ReplayMazeObjectProxy(replay_generation_system.maze_object, replay_generation_system)
        generator = GoldRushMazeEntityGenerator(replay_generation_system)
        generator.do_generate_entities()
        after_seed = _normalize_goldrush_generation_seed(replay_generation_system.get_generation_seed())
        if before_seed is not None and after_seed is not None and before_seed != after_seed:
            result["reason"] = "generation_seed_changed_during_replay"
            return result
        runtime_token_after = _build_goldrush_runtime_token(combat_core, maze_sys)
        result["runtime_token_validation"] = {
            "before": runtime_token_before,
            "after": runtime_token_after,
            "stable": _safe_uid_text(runtime_token_before.get("token", "")) == _safe_uid_text(runtime_token_after.get("token", "")) and bool(_safe_uid_text(runtime_token_before.get("token", "")))
        }
        if not result["runtime_token_validation"]["stable"]:
            result["reason"] = "runtime_token_unstable"
            return result
        postprocess = getattr(generator, "postprocess_obj", None)
        grouped = getattr(postprocess, "_data", {}) if postprocess else {}
        if isinstance(grouped, dict):
            result["postprocess_group_counts"] = {
                _safe_uid_text(key): len(_iter_values(value))
                for key, value in grouped.items()
            }
        chest_data = _dict_get(grouped, "ChestGroup") or []
        result["collected_candidate_count"] = len(_iter_values(chest_data))
        result["items"] = _extract_selected_boxes_with_lookup(chest_data, candidate_lookup)
        result["selected_count"] = len(result["items"])
        result["ok"] = True
    except Exception as e:
        result["reason"] = _safe_uid_text(e)
        result["traceback"] = traceback.format_exc()
    finally:
        try:
            generator = None
            replay_generation_system = None
            replay_core = None
            import gc
            gc.collect()
        except:
            pass
        # #region debug-point D:seed-replay-perf
        try:
            _goldrush_debug_perf(
                "seed_replay",
                "D",
                "main.cpp:_run_seed_a_plus_replay",
                (time.time() - debug_started_at) * 1000.0,
                {
                    "ok": bool(result.get("ok")),
                    "reason": _safe_uid_text(result.get("reason", "")),
                    "selected_count": _safe_int(result.get("selected_count", 0), 0),
                    "candidate_count": _safe_int(result.get("candidate_count", 0), 0),
                    "collected_candidate_count": _safe_int(result.get("collected_candidate_count", 0), 0)
                }
            )
        except:
            pass
        # #endregion
    return result

def _get_seed_box_level(entry):
    gen_info = entry.get("gen_info", {}) if isinstance(entry, dict) else {}
    try:
        return int(gen_info.get("level", 0))
    except:
        return 0

def _get_seed_reward_icon(entry):
    level = _get_seed_box_level(entry)
    if level >= 3:
        return REWARD_ICON_EPIC_DEFAULT
    if level >= 2:
        return REWARD_ICON_RARE_DEFAULT
    return REWARD_ICON_DEFAULT

def _get_goldrush_seed_replay_result(combat_core, scene_id=-1, force_refresh=False):
    try:
        replay_result = _run_seed_a_plus_replay(combat_core)
        result = dict(replay_result or {})
        result["scene_id"] = _safe_int(scene_id, -1)
        result["selected_count"] = _safe_int(result.get("selected_count", 0), 0)
        result["items"] = list(result.get("items", []) or [])
        result["updated_at"] = time.time()
        result["source"] = "seed_a_plus_live" if result.get("ok") else "disabled_without_seed_a_plus"
        if not result.get("ok"):
            result["reason"] = _safe_uid_text(result.get("reason", "")) or "seed_replay_failed"
        return result
    except Exception as e:
        return {
            "scene_id": _safe_int(scene_id, -1),
            "generation_seed": None,
            "items": [],
            "selected_count": 0,
            "ok": False,
            "updated_at": time.time(),
            "reason": _safe_uid_text(e),
            "source": "disabled_without_seed_a_plus"
        }

def _seed_level_to_goldrush_class_name(level):
    return "rd01_prop_chest02" if int(level or 0) >= 3 else "rd01_prop_chest01"

def _seed_level_to_goldrush_box_name(level):
    return "