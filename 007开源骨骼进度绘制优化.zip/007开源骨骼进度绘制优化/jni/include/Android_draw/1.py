import re
import sys
 
 
def extract_array(header_text: str, array_name: str | None = None) -> bytes:
    if array_name:
        # Grab the array body for a specific variable name
        pattern = rf"{re.escape(array_name)}\s*\[\s*\]\s*=\s*\{{(.*?)\}};"
        match = re.search(pattern, header_text, re.DOTALL)
        if not match:
            raise ValueError(f"Array '{array_name}' not found")
        body = match.group(1)
    else:
        # Fall back to the first {...} block that looks like a byte array
        match = re.search(r"\{(.*?)\};", header_text, re.DOTALL)
        if not match:
            raise ValueError("No array body found")
        body = match.group(1)
 
    # Pull every 0xNN token out, in order
    hex_bytes = re.findall(r"0x[0-9a-fA-F]{1,2}", body)
    if not hex_bytes:
        raise ValueError("No hex byte literals found in array body")
 
    return bytes(int(b, 16) for b in hex_bytes)
 
 
def main():
    if len(sys.argv) < 3:
        print(__doc__)
        sys.exit(1)
 
    in_path = sys.argv[1]
    out_path = sys.argv[2]
    array_name = sys.argv[3] if len(sys.argv) > 3 else "EMBEDDED_HOOK_SO"
 
    with open(in_path, "r", encoding="utf-8", errors="ignore") as f:
        text = f.read()
 
    try:
        data = extract_array(text, array_name)
    except ValueError:
        # Named array not found -> just take the first array in the file
        data = extract_array(text, None)
 
    with open(out_path, "wb") as f:
        f.write(data)
 
    print(f"Wrote {len(data)} bytes to {out_path}")
    print(f"Magic bytes: {data[:4]!r}")  # should be b'\\x7fELF' for a valid .so
 
 
if __name__ == "__main__":
    main()