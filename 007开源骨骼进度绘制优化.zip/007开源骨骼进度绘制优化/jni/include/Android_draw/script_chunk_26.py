)")

    skill_data = _nv_load_skill_data(combat_core)
    params = _parse_night_view_params(skill_data)

    initial_push_lens = None
    transition_time = None
    pair = _parse_nv_float_pair(skill_data.get("skill_args6", ""))
    if len(pair) >= 1:
        initial_push_lens = pair[0]
    if len(pair) >= 2:
        transition_time = pair[1]

    fog_custom2_ratio = None
    try:
        fog_custom2_ratio = float(skill_data.get("skill_args7", ""))
    except Exception:
        pass

    char_light = _parse_nv_float_pair(skill_data.get("skill_args9", ""))
    char_light_intensity_mul = char_light[0] if len(char_light) >= 1 else None
    char_light_range_mul = char_light[1] if len(char_light) >= 2 else None
    char_light_cutoff_power = char_light[2] if len(char_light) >= 3 else None

    fog_mgr = getattr(room, "fog_manager", None)
    stage_light_sys = _nv_get_stage_light_system(combat_core, combat_unit)

    post_process_result = _nv_apply_post_process(pos_mgr, params, initial_push_lens, transition_time)

    fog_result = "skip"
    if fog_mgr is not None and fog_custom2_ratio is not None:
        fog_mgr.set_night_view_fog_custom2_ratio(fog_custom2_ratio)
        fog_result = "applied"

    stage_light_result = {
        "found": stage_light_sys is not None,
        "intensity": None,
        "range": None,
        "cutoff": None,
    }
    if stage_light_sys is not None:
        if char_light_intensity_mul is not None:
            stage_light_sys.set_char_light_intensity_mul(char_light_intensity_mul)
            stage_light_result["intensity"] = char_light_intensity_mul
        if char_light_range_mul is not None:
            stage_light_sys.set_char_light_range_mul(char_light_range_mul)
            stage_light_result["range"] = char_light_range_mul
        if char_light_cutoff_power is not None:
            stage_light_sys.set_char_light_cutoff_power(char_light_cutoff_power)
            stage_light_result["cutoff"] = char_light_cutoff_power

    hooks = _nv_install_keep_alive_hooks()

    return {
        "post_process_result": post_process_result,
        "fog_result": fog_result,
        "fog_custom2_ratio": fog_custom2_ratio,
        "night_view_params": params,
        "initial_push_lens": initial_push_lens,
        "transition_time": transition_time,
        "stage_light_result": stage_light_result,
        "hooks": hooks,
        "room_class": room.__class__.__name__,
        "combat_core_class": combat_core.__class__.__name__,
        "has_post_process_mgr": pos_mgr is not None,
        "has_fog_mgr": fog_mgr is not None,
    }

def _maybe_run_goldrush_night_view_request(loop_now):
    global GOLDRUSH_NIGHT_VIEW_LAST_MANUAL_TOKEN

    try:
        manual_token = _safe_int(HOOK_CONTROL_STATE.get("goldrush_night_view_token", 0), 0)
    except:
        manual_token = 0
    if manual_token > 0 and manual_token != GOLDRUSH_NIGHT_VIEW_LAST_MANUAL_TOKEN:
        GOLDRUSH_NIGHT_VIEW_LAST_MANUAL_TOKEN = manual_token
        try:
            res = apply_native_night_view()
            _debug_log_append("goldrush_night_view", "triggered and applied successfully: %s" % _safe_uid_text(res))
        except Exception as e:
            _debug_log_append("goldrush_night_view_error", _safe_uid_text(e))
#endregion

def _maybe_run_goldrush_fog_request(loop_now):
    global GOLDRUSH_FOG_LAST_MANUAL_TOKEN

    try:
        manual_token = _safe_int(HOOK_CONTROL_STATE.get("goldrush_open_fog_token", 0), 0)
    except:
        manual_token = 0
    if manual_token > 0 and manual_token != GOLDRUSH_FOG_LAST_MANUAL_TOKEN:
        GOLDRUSH_FOG_LAST_MANUAL_TOKEN = manual_token
        _start_goldrush_open_map_job("manual")

def _maybe_run_goldrush_seed_box_request(loop_now):
    global GOLDRUSH_SEED_BOX_LAST_MANUAL_TOKEN

    try:
        manual_token = _safe_int(HOOK_CONTROL_STATE.get("goldrush_seed_box_token", 0), 0)
    except:
        manual_token = 0
    if manual_token > 0 and manual_token != GOLDRUSH_SEED_BOX_LAST_MANUAL_TOKEN:
        GOLDRUSH_SEED_BOX_LAST_MANUAL_TOKEN = manual_token
        _start_goldrush_seed_box_job("manual_seed_box")
    _advance_goldrush_seed_box_job(loop_now)

def safe_get_units_by_types_from_mgr(unit_mgr, unit_types):
    if not unit_mgr or not unit_types:
        return []
    try:
        getter = getattr(unit_mgr, 'get_units_by_types', None)
        if not getter:
            return []
        units = getter(unit_types)
        if units:
            return units
    except:
        pass
    return []

def safe_get_units_from_mgr(unit_mgr, method_name):
    if not unit_mgr:
        return []
    try:
        getter = getattr(unit_mgr, method_name, None)
        if not getter:
            return []
        units = getter()
        if units:
            return units
    except:
        pass
    return []

def safe_get_units_by_type_from_mgr(unit_mgr, unit_type):
    if not unit_mgr:
        return []
    try:
        getter = getattr(unit_mgr, 'get_units_by_type', None)
        if not getter:
            return []
        units = getter(unit_type)
        if units:
            return units
    except:
        pass
    return []

def safe_get_unit_from_mgr(unit_mgr, uid):
    if not unit_mgr or uid is None:
        return None
    try:
        getter = getattr(unit_mgr, 'get_unit', None)
        if getter:
            unit = getter(uid)
            if unit:
                return unit
    except:
        pass
    return None

def safe_find_player_unit_by_uid(uid):
    if uid is None:
        return None
    target_uid = str(uid)
    if target_uid == "" or target_uid == "unknown":
        return None

    mgr_candidates = []
    try:
        ref_unit_mgr = get_available_ref_unit_mgr()
        if ref_unit_mgr:
            mgr_candidates.append(ref_unit_mgr)
    except:
        pass
    try:
        unit_mgr = get_available_unit_mgr()
        if unit_mgr and all(unit_mgr is not item for item in mgr_candidates):
            mgr_candidates.append(unit_mgr)
    except:
        pass

    for mgr in mgr_candidates:
        unit = safe_get_unit_from_mgr(mgr, uid)
        if unit:
            return unit
        for method_name in ('get_player_units', 'get_mode_player_units', 'get_copycat_player_units'):
            try:
                for player in safe_get_units_from_mgr(mgr, method_name) or []:
                    if get_player_uid(player) == target_uid:
                        return player
            except:
                pass
    return None

def _append_unique_units(target_list, units, seen_keys):
    for unit in units or []:
        if not unit:
            continue
        try:
            uid_text = get_player_uid(unit)
        except:
            uid_text = "unknown"
        unique_key = uid_text if uid_text and uid_text != "unknown" else f"mem:{id(unit)}"
        if unique_key in seen_keys:
            continue
        seen_keys.add(unique_key)
        target_list.append(unit)

def get_primary_player_units(prefer_mode=False):
    result = []
    seen_keys = set()
    mgr_candidates = []

    try:
        ref_unit_mgr = get_available_ref_unit_mgr()
        if ref_unit_mgr:
            mgr_candidates.append(ref_unit_mgr)
    except:
        pass

    try:
        unit_mgr = get_available_unit_mgr()
        if unit_mgr and all(unit_mgr is not item for item in mgr_candidates):
            mgr_candidates.append(unit_mgr)
    except:
        pass

    def collect_by_method(method_name):
        before_count = len(result)
        for mgr in mgr_candidates:
            _append_unique_units(result, safe_get_units_from_mgr(mgr, method_name), seen_keys)
        return len(result) > before_count

    if prefer_mode:
        if collect_by_method('get_mode_player_units'):
            return result
        try:
            from common_cs import ComuKeys
            gold_types = tuple(item for item in (
                getattr(ComuKeys.UNIT_TYPE_CONF, 'GOLD_RUSH_PLAYER', None),
                getattr(ComuKeys.UNIT_TYPE_CONF, 'GOLD_RUSH_AI_PLAYER', None),
            ) if item is not None)
            if gold_types:
                for mgr in mgr_candidates:
                    _append_unique_units(result, safe_get_units_by_types_from_mgr(mgr, gold_types), seen_keys)
                if result:
                    return result
        except:
            pass
        if collect_by_method('get_player_units'):
            return result
    else:
        if collect_by_method('get_player_units'):
            return result
        if collect_by_method('get_mode_player_units'):
            return result

    collect_by_method('get_copycat_player_units')
    return result

def probe_info_readiness(unit_mgr):
    info = {
        'unit_mgr_ready': bool(unit_mgr),
        'room_unit_mgr_ready': False,
        'player_count': 0,
        'uid_ready_count': 0,
        'talent_ready_count': 0,
        'old_timing_ready': False,
        'full_ready': False,
    }
    try:
        player = getattr(GK, 'g_unit', None)
        room = getattr(player, 'room', None) if player else None
        room_unit_mgr = getattr(room, 'unit_mgr', None) if room else None
        info['room_unit_mgr_ready'] = bool(room_unit_mgr)

        readiness_mgr = room_unit_mgr or unit_mgr
        players = safe_get_units_from_mgr(readiness_mgr, 'get_player_units')
        info['player_count'] = len(players)
        for player in players:
            if not player:
                continue
            try:
                uid = get_player_uid(player)
                if uid and uid != 'unknown':
                    info['uid_ready_count'] += 1
            except:
                pass
            try:
                genius_list = getattr(player, 'genius_id_lv_lst', [])
                if genius_list:
                    info['talent_ready_count'] += 1
            except:
                pass
        info['old_timing_ready'] = info['room_unit_mgr_ready'] and info['player_count'] >= 2
        info['full_ready'] = info['old_timing_ready'] and info['uid_ready_count'] >= 1 and info['talent_ready_count'] >= 1
    except:
        pass
    return info

def collect_spawn_selection_data():
    spawn_data = {
        "type": "spawn_select",
        "valid": False,
        "players": []
    }
    # 