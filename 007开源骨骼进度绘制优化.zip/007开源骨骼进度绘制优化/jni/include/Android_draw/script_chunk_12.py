"),
                        "left_time": float(left_time or 0.0)
                    })
                except:
                    pass

        knight_data["valid"] = True
        knight_data["predictions"] = predictions
    except:
        pass

    return json.dumps(knight_data)

def collect_opera_singer_leap_data():
    leap_data = {
        "type": "opera_shadow_leap",
        "received": True,
        "valid": False,
        "charging": False,
        "is_blocked": False,
        "in_shadow_form": False,
        "speed_real": 0.0,
        "jump_speed": 0.0,
        "jump_time": 0.0,
        "presence_num": 0,
        "self_pos": [0.0, 0.0, 0.0],
        "direction": [0.0, 0.0, 0.0],
        "hit_pos": [0.0, 0.0, 0.0],
        "status": "init"
    }
    try:
        import math3d

        vector_ctor = getattr(math3d, 'Vector3', None)
        if vector_ctor is None:
            vector_ctor = getattr(math3d, 'vector', None)
        if vector_ctor is None:
            leap_data["status"] = "no_math3d_vector"
            return json.dumps(leap_data)

        unit = getattr(GK, 'g_unit', None)
        if not unit:
            leap_data["status"] = "no_unit"
            return json.dumps(leap_data)

        if not hasattr(unit, 'skill_mgr') or not unit.skill_mgr:
            leap_data["status"] = "no_skill_mgr"
            return json.dumps(leap_data)

        room = getattr(unit, 'room', None)
        if not room:
            leap_data["status"] = "no_room"
            return json.dumps(leap_data)
        leap_data["in_shadow_form"] = bool(getattr(unit, 'blackgoat_show_shadow', False))

        if not hasattr(unit, 'get_position3'):
            leap_data["status"] = "no_self_pos"
            return json.dumps(leap_data)

        self_pos = unit.get_position3()
        if not self_pos:
            leap_data["status"] = "invalid_self_pos"
            return json.dumps(leap_data)

        leap_data["self_pos"] = [float(self_pos.x), float(self_pos.y), float(self_pos.z)]

        direction = None
        try:
            from common_tools import utils as util
            import game_kernel as Netease
            if hasattr(Netease, 'g_cam_ctrl') and Netease.g_cam_ctrl and getattr(Netease.g_cam_ctrl, 'cam', None):
                direction = util.get_forward_cam(Netease.g_cam_ctrl.cam)
        except:
            direction = None

        if direction:
            try:
                direction.y = 0
                dir_len_sq = (
                    float(getattr(direction, 'x', 0.0)) * float(getattr(direction, 'x', 0.0)) +
                    float(getattr(direction, 'y', 0.0)) * float(getattr(direction, 'y', 0.0)) +
                    float(getattr(direction, 'z', 0.0)) * float(getattr(direction, 'z', 0.0))
                )
                if dir_len_sq > 0.000001 and hasattr(direction, 'normalize'):
                    direction.normalize()
                else:
                    direction = vector_ctor(1.0, 0.0, 0.0)
            except:
                direction = vector_ctor(1.0, 0.0, 0.0)
        elif hasattr(unit, 'get_direction3'):
            try:
                direction = unit.get_direction3()
                if direction:
                    direction.y = 0
                    dir_len_sq = (
                        float(getattr(direction, 'x', 0.0)) * float(getattr(direction, 'x', 0.0)) +
                        float(getattr(direction, 'y', 0.0)) * float(getattr(direction, 'y', 0.0)) +
                        float(getattr(direction, 'z', 0.0)) * float(getattr(direction, 'z', 0.0))
                    )
                    if dir_len_sq > 0.000001 and hasattr(direction, 'normalize'):
                        direction.normalize()
                    else:
                        direction = vector_ctor(1.0, 0.0, 0.0)
            except:
                direction = vector_ctor(1.0, 0.0, 0.0)

        if not direction:
            leap_data["status"] = "no_direction"
            return json.dumps(leap_data)

        leap_data["direction"] = [float(direction.x), float(direction.y), float(direction.z)]

        speed_real = 0.0
        try:
            speed_real = float(getattr(unit, 'speed_real', 0.0) or 0.0)
        except:
            speed_real = 0.0
        leap_data["speed_real"] = speed_real

        casting_skills = []
        if hasattr(unit.skill_mgr, 'get_casting_skill'):
            casting_skills = unit.skill_mgr.get_casting_skill()

        for skill in casting_skills or []:
            skill_name = type(skill).__name__
            if 'BlackgoatDash' not in skill_name:
                continue

            leap_data["charging"] = True
            break

        jump_speed = 3.0
        jump_time = 0.5
        try:
            presence_num = getattr(unit, 'presence_num', 0) if unit else 0
            if presence_num is None:
                presence_num = 0
            presence_num = int(presence_num)
        except:
            presence_num = 0
        l_skill = None
        try:
            for skill in unit.skill_mgr.skills.values():
                if 'BlackgoatDash' not in type(skill).__name__:
                    continue

                l_skill = getattr(skill, 'l_skill', skill)
                if leap_data["in_shadow_form"]:
                    jump_speed = float(getattr(l_skill, 'jump_shadow_speed', 3.0) or 3.0)
                else:
                    jump_speed = float(getattr(l_skill, 'jump_speed', 3.0) or 3.0)
                jump_time = float(getattr(l_skill, 'jump_time', 0.5) or 0.5)

                break
        except:
            pass

        leap_data["jump_speed"] = jump_speed
        leap_data["jump_time"] = jump_time
        leap_data["presence_num"] = presence_num

        move_dist = speed_real * jump_speed * jump_time
        if presence_num >= 2500:
            move_dist *= 1.2
        predicted_pos = vector_ctor(
            float(self_pos.x) + float(direction.x) * move_dist,
            float(self_pos.y) + float(direction.y) * move_dist,
            float(self_pos.z) + float(direction.z) * move_dist
        )

        if get_hook_control_flag("enable_auto_hook") and get_hook_control_flag("need_opera_hit_test"):
            try:
                from common_cs import CollisionConst
                collision_mgr = getattr(room, 'collision_mgr', None)
                if collision_mgr and hasattr(collision_mgr, 'hit_by_ray_new'):
                    filter_rule = CollisionConst.Filter(group_value=CollisionConst.Group.BATTLE_INTER_EXCLUDE)

                    res_forward = collision_mgr.hit_by_ray_new(self_pos, predicted_pos, filter_rule)
                    if res_forward and len(res_forward) >= 2 and res_forward[0]:
                        leap_data["is_blocked"] = True
                        hit_pos = res_forward[1]
                        if hit_pos:
                            predicted_pos = hit_pos
                            leap_data["hit_pos"] = [float(predicted_pos.x), float(predicted_pos.y), float(predicted_pos.z)]
            except:
                pass

        leap_data["valid"] = True
        leap_data["status"] = "ok"
    except Exception as e:
        leap_data["status"] = str(e)

    return json.dumps(leap_data)

def collect_yidhra_puppet_skill_info():
    results = []

    try:
        from common_cs import ComuKeys

        unit = getattr(GK, 'g_unit', None)
        room = getattr(unit, 'room', None) if unit else None
        if not room or not hasattr(room, 'unit_mgr') or not room.unit_mgr:
            return results

        puppets = room.unit_mgr.get_units_by_type(ComuKeys.UNIT_TYPE_CONF.YIDHRA_PUPPET)
        if not puppets:
            results.append("