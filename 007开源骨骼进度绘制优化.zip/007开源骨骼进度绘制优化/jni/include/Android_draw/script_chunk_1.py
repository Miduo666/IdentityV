"}
}

TARGET_BONES = [
    "biped spine", "biped head", "biped neck",
    "biped l clavicle", "biped r clavicle",
    "biped l upperarm", "biped r upperarm",
    "biped l forearm", "biped r forearm",
    "biped l hand", "biped r hand",
    "biped l thigh", "biped r thigh",
    "biped l calf", "biped r calf",
    "biped l foot", "biped r foot"
]

HOOK_CONTROL_LOCK = threading.Lock()
HOOK_CONTROL_STATE = {
    "enable_auto_hook": False,
    "need_bones": False,
    "need_matrix_raw": False,
    "need_violin_notes": False,
    "need_wuchang_umbrella": False,
    "need_knight_predictions": False,
    "need_opera_hit_test": False,
    "need_panels": False,
    "need_chair_runtime": False,
    "need_panel_logic_meta": False,
    "need_panel_static_cache": False,
    "need_info": False,
    "need_self_debuff": False,
    "need_all_unit_buffs": False,
    "need_special_countdown": False,
    "need_qte_state": False,
    "need_qte_state_fast": False,
    "need_goldrush_runtime": False,
    "need_goldrush_monster_hp": False,
    "need_goldrush_reference": False,
    "goldrush_scene_snapshot_token": 0,
    "goldrush_open_fog_token": 0,
    "goldrush_seed_box_token": 0,
    "goldrush_night_view_token": 0,
    "goldrush_nav_request_token": 0,
    "goldrush_nav_targets": [],
    "need_copycat_advanced": False,
    "need_copycat_meeting": False,
    "need_special_units": False,
    "need_special_unit_bones": False,
    "need_batter_auto_cancel": False,
    "need_low_latency_hunter_actions": False,
    "feature_auto_skill": False,
    "feature_board_low_latency": False,
    "feature_anti_cowboy": False,
    "feature_anti_coordinator": False,
    "feature_journalist": False,
    "feature_hds_freeze": False,
    "need_capture_player_models": False,
    "camera_vector_control_enabled": False,
    "camera_control_active": False,
    "camera_target_dir": [0.0, 0.0, 0.0],
    "player_vector_spin_active": False,
    "player_vector_spin_direction": 1,
    "player_vector_spin_speed": 12.0,
    "self_state_override_enabled": False,
    "self_state_override_ids": []
}
SELF_STATE_OVERRIDE_LAST_SIGNATURE = ""
SELF_STATE_OVERRIDE_LAST_APPLY_AT = 0.0

GOLDRUSH_FOG_LAST_RESULT = {
    "requested": False,
    "success": False,
    "status": "idle",
    "phase": "idle",
    "cleared_point_count": 0,
    "ui_refresh_count": 0,
    "reward_box_count": 0,
    "reward_box_marked_count": 0,
    "alchemy_box_count": 0,
    "alchemy_box_marked_count": 0,
    "flush_ok_count": 0,
    "request_source": "",
    "scene_id": -1,
    "updated_at": 0.0
}
GOLDRUSH_FOG_LAST_MANUAL_TOKEN = 0
GOLDRUSH_SEED_BOX_LAST_MANUAL_TOKEN = 0
GOLDRUSH_SEED_BOX_LAST_RESULT = {
    "requested": False,
    "success": False,
    "status": "idle",
    "phase": "idle",
    "reward_box_count": 0,
    "reward_box_marked_count": 0,
    "alchemy_box_count": 0,
    "alchemy_box_marked_count": 0,
    "flush_ok_count": 0,
    "request_source": "",
    "scene_id": -1,
    "updated_at": 0.0
}
GOLDRUSH_FOG_JOB = {"active": False}
GOLDRUSH_SEED_BOX_JOB = {"active": False}
GOLDRUSH_FOG_STEP_DELAY_SEC = 0.12
GOLDRUSH_FOG_MARK_BATCH_SIZE = 1
GOLDRUSH_FOG_TARGET_DURATION_SEC = 10.0
GOLDRUSH_NIGHT_VIEW_LAST_MANUAL_TOKEN = 0

TICK_CACHE_LOCK = threading.Lock()
TICK_CACHE = {
    "bones": {"payload": "", "updated_at": 0.0},
    "actions": {"payload": "", "updated_at": 0.0},
    "matrix_raw": {"payload": "", "updated_at": 0.0},
    "violin_notes": {"payload": "", "updated_at": 0.0},
    "wuchang_umbrella": {"payload": "", "updated_at": 0.0},
    "mary_mirror": {"payload": "", "updated_at": 0.0},
    "special_units": {"payload": "", "updated_at": 0.0},
    "special_unit_bones": {"payload": "", "updated_at": 0.0},
    "knight_predictions": {"payload": "", "updated_at": 0.0},
    "opera_shadow_leap": {"payload": "", "updated_at": 0.0},
    "panels": {"payload": "", "updated_at": 0.0},
    "info": {"payload": "", "updated_at": 0.0},
    "goldrush_runtime": {"payload": "", "updated_at": 0.0},
    "goldrush_monster_hp": {"payload": "", "updated_at": 0.0},
    "goldrush_reference": {"payload": "", "updated_at": 0.0},
    "goldrush_nav_paths": {"payload": "", "updated_at": 0.0},
    "goldrush_scene_snapshot": {"payload": "", "updated_at": 0.0},
    "copycat_advanced": {"payload": "", "updated_at": 0.0},
    "copycat_meeting": {"payload": "", "updated_at": 0.0},
    "self_debuff": {"payload": "", "updated_at": 0.0},
    "all_unit_buffs": {"payload": "", "updated_at": 0.0},
    "qte_state": {"payload": "", "updated_at": 0.0},
    "hunter_fast_actions": {"payload": "", "updated_at": 0.0}
}
TICK_SAMPLE_TIMERS = {}

def _set_tick_payload(name, payload, now=None):
    if not payload:
        return
    try:
        ts = float(now if now is not None else time.time())
        with TICK_CACHE_LOCK:
            entry = TICK_CACHE.get(name)
            if entry is None:
                entry = {"payload": "", "updated_at": 0.0}
                TICK_CACHE[name] = entry
            entry["payload"] = payload
            entry["updated_at"] = ts
    except:
        pass

def _get_tick_payload(name):
    try:
        with TICK_CACHE_LOCK:
            entry = TICK_CACHE.get(name)
            if not entry:
                return "", 0.0
            return entry.get("payload", ""), float(entry.get("updated_at", 0.0) or 0.0)
    except:
        return "", 0.0

def _tick_due(now, key, interval):
    try:
        last_time = float(TICK_SAMPLE_TIMERS.get(key, 0.0) or 0.0)
        if now - last_time < interval:
            return False
        TICK_SAMPLE_TIMERS[key] = now
        return True
    except:
        return False

RUN_TICK_COLLECTOR_BUDGET_SEC = 0.0032
RUN_TICK_CONTROL_POLL_INTERVAL_SEC = 0.010
RUN_TICK_CAMERA_CONTROL_INTERVAL_SEC = 0.012
RUN_TICK_SELF_STATE_OVERRIDE_INTERVAL_SEC = 0.050
RUN_TICK_MISC_REQUEST_INTERVAL_SEC = 0.050
RUN_TICK_PAYLOAD_FLUSH_INTERVAL_SEC = 0.012
INCREMENTAL_ACTION_CHUNK_SIZE = 2
INCREMENTAL_BONE_CHUNK_SIZE = 4
INCREMENTAL_INFO_PLAYER_CHUNK_SIZE = 2
INCREMENTAL_PANEL_CHUNK_SIZE = 4
INCREMENTAL_COPYCAT_ADVANCED_CHUNK_SIZE = 1
INCREMENTAL_ALL_UNIT_BUFFS_CHUNK_SIZE = 2

INCREMENTAL_COLLECTOR_STATE = {
    "actions": {"active": False, "pending_units": [], "index": 0, "result": None},
    "bones": {"active": False, "pending_units": [], "index": 0, "result": None},
    "info": {"active": False, "players": [], "index": 0, "base_results": [], "player_lines": []},
    "panels": {"active": False, "items": [], "index": 0, "result": None},
    "copycat_advanced": {"active": False, "items": [], "index": 0, "entries_by_uid": {}},
    "all_unit_buffs": {"active": False, "items": [], "index": 0, "result": None}
}

def _incremental_collector_active(name):
    try:
        return bool((INCREMENTAL_COLLECTOR_STATE.get(name) or {}).get("active"))
    except:
        return False

def _reset_incremental_collector(name):
    try:
        if name == "actions":
            INCREMENTAL_COLLECTOR_STATE[name] = {"active": False, "pending_units": [], "index": 0, "result": None}
        elif name == "bones":
            INCREMENTAL_COLLECTOR_STATE[name] = {"active": False, "pending_units": [], "index": 0, "result": None}
        elif name == "info":
            INCREMENTAL_COLLECTOR_STATE[name] = {"active": False, "players": [], "index": 0, "base_results": [], "player_lines": []}
        elif name == "panels":
            INCREMENTAL_COLLECTOR_STATE[name] = {"active": False, "items": [], "index": 0, "result": None}
        elif name == "copycat_advanced":
            INCREMENTAL_COLLECTOR_STATE[name] = {"active": False, "items": [], "index": 0, "entries_by_uid": {}}
        elif name == "all_unit_buffs":
            INCREMENTAL_COLLECTOR_STATE[name] = {"active": False, "items": [], "index": 0, "result": None}
    except:
        pass

def _run_tick_budget_exceeded(start_time):
    try:
        return (time.time() - float(start_time or 0.0)) >= RUN_TICK_COLLECTOR_BUDGET_SEC
    except:
        return False

class _TickCollectorBudgetStop(Exception):
    pass

def update_hook_control_state(packet_text):
    try:
        data = json.loads(packet_text)
        if not isinstance(data, dict):
            return
        if data.get("type") != "hook_control":
            return

        with HOOK_CONTROL_LOCK:
            HOOK_CONTROL_STATE["enable_auto_hook"] = bool(data.get("enable_auto_hook", False))
            HOOK_CONTROL_STATE["need_bones"] = bool(data.get("need_bones", False))
            HOOK_CONTROL_STATE["need_matrix_raw"] = bool(data.get("need_matrix_raw", False))
            HOOK_CONTROL_STATE["need_violin_notes"] = bool(data.get("need_violin_notes", False))
            HOOK_CONTROL_STATE["need_wuchang_umbrella"] = bool(data.get("need_wuchang_umbrella", False))
            HOOK_CONTROL_STATE["need_knight_predictions"] = bool(data.get("need_knight_predictions", False))
            HOOK_CONTROL_STATE["need_opera_hit_test"] = bool(data.get("need_opera_hit_test", False))
            HOOK_CONTROL_STATE["need_panels"] = bool(data.get("need_panels", False))
            HOOK_CONTROL_STATE["need_chair_runtime"] = bool(data.get("need_chair_runtime", False))
            HOOK_CONTROL_STATE["need_panel_logic_meta"] = bool(data.get("need_panel_logic_meta", False))
            HOOK_CONTROL_STATE["need_panel_static_cache"] = bool(data.get("need_panel_static_cache", False))
            HOOK_CONTROL_STATE["need_info"] = bool(data.get("need_info", False))
            HOOK_CONTROL_STATE["need_self_debuff"] = bool(data.get("need_self_debuff", False))
            HOOK_CONTROL_STATE["need_all_unit_buffs"] = bool(data.get("need_all_unit_buffs", False))
            previous_need_special_countdown = bool(HOOK_CONTROL_STATE.get("need_special_countdown", False))
            current_need_special_countdown = bool(data.get("need_special_countdown", False))
            HOOK_CONTROL_STATE["need_special_countdown"] = current_need_special_countdown
            if previous_need_special_countdown and not current_need_special_countdown:
                try:
                    SPECIAL_STATE_CACHE["fragrance"].clear()
                except:
                    pass
            HOOK_CONTROL_STATE["need_qte_state"] = bool(data.get("need_qte_state", False))
            HOOK_CONTROL_STATE["need_qte_state_fast"] = bool(data.get("need_qte_state_fast", False))
            HOOK_CONTROL_STATE["need_goldrush_runtime"] = bool(data.get("need_goldrush_runtime", False))
            HOOK_CONTROL_STATE["need_goldrush_monster_hp"] = bool(data.get("need_goldrush_monster_hp", False))
            HOOK_CONTROL_STATE["need_goldrush_reference"] = bool(data.get("need_goldrush_reference", False))
            HOOK_CONTROL_STATE["goldrush_scene_snapshot_token"] = _safe_int(data.get("goldrush_scene_snapshot_token", 0), 0)
            HOOK_CONTROL_STATE["goldrush_open_fog_token"] = _safe_int(data.get("goldrush_open_fog_token", 0), 0)
            HOOK_CONTROL_STATE["goldrush_seed_box_token"] = _safe_int(data.get("goldrush_seed_box_token", 0), 0)
            HOOK_CONTROL_STATE["goldrush_night_view_token"] = _safe_int(data.get("goldrush_night_view_token", 0), 0)
            HOOK_CONTROL_STATE["goldrush_nav_request_token"] = _safe_int(data.get("goldrush_nav_request_token", 0), 0)
            nav_targets = []
            raw_nav_targets = data.get("goldrush_nav_targets", [])
            if isinstance(raw_nav_targets, (list, tuple)):
                for raw_target in raw_nav_targets[:64]:
                    if not isinstance(raw_target, dict):
                        continue
                    raw_pos = raw_target.get("p", raw_target.get("target_pos", raw_target.get("pos", [])))
                    if not isinstance(raw_pos, (list, tuple)) or len(raw_pos) < 3:
                        continue
                    nav_targets.append({
                        "class_name": _safe_uid_text(raw_target.get("c", raw_target.get("class_name", raw_target.get("class", "")))),
                        "label": _safe_uid_text(raw_target.get("label", raw_target.get("name", ""))),
                        "pos": [
                            _safe_float(raw_pos[0], 0.0),
                            _safe_float(raw_pos[1], 0.0),
                            _safe_float(raw_pos[2], 0.0)
                        ]
                    })
            HOOK_CONTROL_STATE["goldrush_nav_targets"] = nav_targets
            HOOK_CONTROL_STATE["need_copycat_advanced"] = bool(data.get("need_copycat_advanced", False))
            HOOK_CONTROL_STATE["need_copycat_meeting"] = bool(data.get("need_copycat_meeting", False))
            HOOK_CONTROL_STATE["need_special_units"] = bool(data.get("need_special_units", False))
            HOOK_CONTROL_STATE["need_special_unit_bones"] = bool(data.get("need_special_unit_bones", False))
            HOOK_CONTROL_STATE["need_batter_auto_cancel"] = bool(data.get("need_batter_auto_cancel", False))
            HOOK_CONTROL_STATE["need_low_latency_hunter_actions"] = bool(data.get("need_low_latency_hunter_actions", False))
            HOOK_CONTROL_STATE["feature_auto_skill"] = bool(data.get("feature_auto_skill", False))
            HOOK_CONTROL_STATE["feature_board_low_latency"] = bool(data.get("feature_board_low_latency", False))
            HOOK_CONTROL_STATE["feature_anti_cowboy"] = bool(data.get("feature_anti_cowboy", False))
            HOOK_CONTROL_STATE["feature_anti_coordinator"] = bool(data.get("feature_anti_coordinator", False))
            HOOK_CONTROL_STATE["feature_journalist"] = bool(data.get("feature_journalist", False))
            HOOK_CONTROL_STATE["feature_hds_freeze"] = bool(data.get("feature_hds_freeze", False))
            HOOK_CONTROL_STATE["need_capture_player_models"] = bool(data.get("need_capture_player_models", False))
            HOOK_CONTROL_STATE["camera_vector_control_enabled"] = bool(data.get("camera_vector_control_enabled", False))
            HOOK_CONTROL_STATE["camera_control_active"] = bool(data.get("camera_control_active", False))
            target_dir = data.get("camera_target_dir", [0.0, 0.0, 0.0])
            if isinstance(target_dir, (list, tuple)) and len(target_dir) >= 3:
                HOOK_CONTROL_STATE["camera_target_dir"] = [
                    float(target_dir[0] or 0.0),
                    float(target_dir[1] or 0.0),
                    float(target_dir[2] or 0.0)
                ]
            HOOK_CONTROL_STATE["player_vector_spin_active"] = bool(data.get("player_vector_spin_active", False))
            HOOK_CONTROL_STATE["player_vector_spin_direction"] = 1 if int(data.get("player_vector_spin_direction", 1)) >= 0 else -1
            HOOK_CONTROL_STATE["player_vector_spin_speed"] = float(data.get("player_vector_spin_speed", 12.0) or 12.0)
            HOOK_CONTROL_STATE["self_state_override_enabled"] = bool(data.get("self_state_override_enabled", False))
            state_ids = data.get("self_state_override_ids", [])
            normalized_ids = []
            seen_ids = set()
            if isinstance(state_ids, (list, tuple)):
                for raw_value in state_ids:
                    try:
                        state_id = int(raw_value)
                    except:
                        continue
                    if state_id in seen_ids:
                        continue
                    seen_ids.add(state_id)
                    normalized_ids.append(state_id)
            HOOK_CONTROL_STATE["self_state_override_ids"] = normalized_ids
    except:
        pass

def get_hook_control_flag(name, default=False):
    try:
        with HOOK_CONTROL_LOCK:
            return bool(HOOK_CONTROL_STATE.get(name, default))
    except:
        return bool(default)

def _hook_feature_auto_skill_enabled():
    return get_hook_control_flag("feature_auto_skill")

def _hook_feature_board_low_latency_enabled():
    return get_hook_control_flag("feature_board_low_latency")

def _hook_feature_anti_cowboy_enabled():
    return get_hook_control_flag("feature_anti_cowboy")

def _hook_feature_anti_coordinator_enabled():
    return get_hook_control_flag("feature_anti_coordinator")

def _hook_feature_journalist_enabled():
    return get_hook_control_flag("feature_journalist")

def _hook_feature_hds_freeze_enabled():
    return get_hook_control_flag("feature_hds_freeze")

def _hook_need_special_units_enabled():
    return (
        get_hook_control_flag("need_special_units") or
        _hook_feature_auto_skill_enabled()
    )

def _hook_any_fast_response_feature_enabled():
    return (
        _hook_feature_auto_skill_enabled() or
        _hook_feature_anti_cowboy_enabled() or
        _hook_feature_anti_coordinator_enabled() or
        _hook_feature_journalist_enabled() or
        _hook_feature_hds_freeze_enabled()
    )

def _hook_actions_need_casting_skills():
    return (
        _hook_any_fast_response_feature_enabled() or
        get_hook_control_flag("need_low_latency_hunter_actions") or
        get_hook_control_flag("need_batter_auto_cancel")
    )

def _hook_actions_need_debug_vectors():
    return get_hook_control_flag("need_all_unit_buffs")

def _hook_need_special_countdown_enabled():
    return get_hook_control_flag("need_special_countdown")

def _hook_panels_need_debug_details():
    return get_hook_control_flag("need_all_unit_buffs")

def _hook_panels_need_chair_runtime():
    return get_hook_control_flag("need_chair_runtime") or get_hook_control_flag("need_all_unit_buffs")

def _hook_panels_need_logic_meta():
    return get_hook_control_flag("need_panel_logic_meta")

def _hook_panels_need_static_cache():
    return get_hook_control_flag("need_panel_static_cache")

PANEL_RUNTIME_CACHE = {
    "scene_id": -1,
    "world_type": -1,
    "in_battle": False,
    "logic_meta": {"valid": False},
    "static_panels": []
}

def _reset_panel_runtime_cache():
    PANEL_RUNTIME_CACHE["scene_id"] = -1
    PANEL_RUNTIME_CACHE["world_type"] = -1
    PANEL_RUNTIME_CACHE["in_battle"] = False
    PANEL_RUNTIME_CACHE["logic_meta"] = {"valid": False}
    PANEL_RUNTIME_CACHE["static_panels"] = []

def _get_panel_battle_context():
    map_info = get_current_map_info() or {}
    scene_id = _safe_int(map_info.get("scene_id", -1), -1)
    world_type = _safe_int(map_info.get("world_type", -1), -1)
    players = []
    try:
        players = get_primary_player_units(False) or []
    except:
        players = []
    if not players:
        try:
            players = get_primary_player_units(True) or []
        except:
            players = []
    in_battle = bool(scene_id >= 0 and len(players) > 0)
    return {
        "scene_id": scene_id,
        "world_type": world_type,
        "in_battle": in_battle,
        "player_count": len(players)
    }

def _hook_special_units_need_debug_details():
    return get_hook_control_flag("need_all_unit_buffs")

def _get_dynamic_tick_interval(key):
    if key == "bones":
        return 0.04 if _hook_feature_auto_skill_enabled() else 0.06
    if key == "actions":
        return 0.075 if (_hook_any_fast_response_feature_enabled() or _hook_feature_board_low_latency_enabled() or get_hook_control_flag("need_low_latency_hunter_actions")) else 0.14
    if key == "info":
        return 0.20 if _hook_feature_auto_skill_enabled() else 0.45
    if key == "hunter_fast_actions":
        if _hook_feature_auto_skill_enabled() or _hook_feature_hds_freeze_enabled() or _hook_feature_board_low_latency_enabled() or get_hook_control_flag("need_low_latency_hunter_actions"):
            return 0.05
        return 0.075
    if key == "mary_mirror":
        return 0.12 if _hook_feature_auto_skill_enabled() else 0.16
    if key == "special_units":
        return 0.14 if _hook_feature_auto_skill_enabled() else 0.20
    if key == "panels":
        return 0.10 if (_hook_feature_auto_skill_enabled() or _hook_feature_board_low_latency_enabled()) else 0.16
    if key == "self_debuff":
        return 0.10 if _hook_feature_auto_skill_enabled() else 0.16
    return None

def get_action_unit_uid(unit, fallback_unknown=True):
    uid = "unknown" if fallback_unknown else ""
    try:
        if hasattr(unit, 'uid') and getattr(unit, 'uid', None) is not None:
            uid = str(unit.uid)
        if (uid == "unknown" or uid == "") and hasattr(unit, 'warm_info') and unit.warm_info:
            uid = str(unit.warm_info.get('unique_id', uid))
        if (uid == "unknown" or uid == "") and hasattr(unit, 'unique_id') and unit.unique_id:
            uid = str(unit.unique_id)
    except:
        pass
    return uid

def build_unit_casting_skills(unit):
    result = []

    try:
        if hasattr(unit, 'skill_mgr') and unit.skill_mgr and hasattr(unit.skill_mgr, 'get_casting_skill'):
            casting_skills = unit.skill_mgr.get_casting_skill()
            if casting_skills:
                for skill in casting_skills:
                    skill_id = str(getattr(skill, 'skill_id', ''))
                    skill_type = str(getattr(skill, 'skill_type', ''))
                    if skill_id and skill_type:
                        result.append({
                            "skill_id": skill_id,
                            "skill_type": skill_type
                        })
    except:
        pass

    if result:
        return result

    try:
        if hasattr(unit, 'skill_mgr') and unit.skill_mgr:
            current_ids = list(getattr(unit.skill_mgr, 'current_skill_ex', set()) or [])
            current_ids.sort()
            for skill_id in current_ids:
                skill_type = ''
                try:
                    so = unit.skill_mgr.get_skill_obj(skill_id)
                    if so:
                        skill_type = str(getattr(so, 'skill_type', ''))
                except:
                    pass

                if not skill_type:
                    try:
                        sd = unit.get_skill_data(skill_id)
                        if sd:
                            skill_type = str(sd.get('skill_type', ''))
                    except:
                        pass

                result.append({
                    "skill_id": str(skill_id),
                    "skill_type": skill_type
                })
    except:
        pass

    return result

def apply_self_state_override(now=None):
    global SELF_STATE_OVERRIDE_LAST_SIGNATURE, SELF_STATE_OVERRIDE_LAST_APPLY_AT
    try:
        loop_now = float(now if now is not None else time.time())
    except:
        loop_now = time.time()

    try:
        with HOOK_CONTROL_LOCK:
            enabled = bool(HOOK_CONTROL_STATE.get("self_state_override_enabled", False))
            state_ids = list(HOOK_CONTROL_STATE.get("self_state_override_ids", []) or [])
    except:
        enabled = False
        state_ids = []

    if not enabled or not state_ids:
        SELF_STATE_OVERRIDE_LAST_SIGNATURE = ""
        SELF_STATE_OVERRIDE_LAST_APPLY_AT = 0.0
        return

    signature = ",".join([str(int(state_id)) for state_id in state_ids])
    if signature == SELF_STATE_OVERRIDE_LAST_SIGNATURE and (loop_now - float(SELF_STATE_OVERRIDE_LAST_APPLY_AT or 0.0)) < 0.18:
        return

    player = getattr(GK, 'g_unit', None)
    if not player:
        return
    state_machine = getattr(player, 'state_machine', None)

    applied_any = False
    for raw_state_id in state_ids:
        try:
            state_id = int(raw_state_id)
        except:
            continue

        changed = False
        if state_machine and hasattr(state_machine, 'change_state'):
            try:
                state_machine.change_state(state_id)
                changed = True
            except:
                changed = False
        if not changed:
            try:
                player.state = state_id
                changed = True
            except:
                changed = False
        if changed:
            applied_any = True

    if applied_any:
        SELF_STATE_OVERRIDE_LAST_SIGNATURE = signature
        SELF_STATE_OVERRIDE_LAST_APPLY_AT = loop_now

def apply_hook_camera_control():
    try:
        with HOOK_CONTROL_LOCK:
            enabled = bool(HOOK_CONTROL_STATE.get("camera_vector_control_enabled", False))
            active = bool(HOOK_CONTROL_STATE.get("camera_control_active", False))
            target_dir = HOOK_CONTROL_STATE.get("camera_target_dir", [0.0, 0.0, 0.0])
            player_spin_active = bool(HOOK_CONTROL_STATE.get("player_vector_spin_active", False))
            player_spin_direction = 1 if int(HOOK_CONTROL_STATE.get("player_vector_spin_direction", 1)) >= 0 else -1
            player_spin_speed = float(HOOK_CONTROL_STATE.get("player_vector_spin_speed", 12.0) or 12.0)
        if not enabled:
            return

        cam_ctrl = getattr(GK, 'g_cam_ctrl', None)
        player = getattr(GK, 'g_unit', None)
        if not cam_ctrl or not player:
            return

        if player_spin_active:
            try:
                cam = getattr(cam_ctrl, 'cam', None)
                if not cam and hasattr(cam_ctrl, 'cam_handler'):
                    cam = getattr(cam_ctrl.cam_handler, 'cam', None)
                if not cam:
                    return

                current_dir = None
                try:
                    if hasattr(util, 'get_forward_cam'):
                        current_dir = util.get_forward_cam(cam)
                except:
                    current_dir = None

                current_x = float(getattr(current_dir, 'x', 0.0) or 0.0) if current_dir is not None else 0.0
                current_z = float(getattr(current_dir, 'z', 0.0) or 0.0) if current_dir is not None else 0.0
                current_len = (current_x * current_x + current_z * current_z) ** 0.5
                if current_len <= 0.0001 and hasattr(player, 'get_direction3'):
                    unit_dir = player.get_direction3()
                    current_x = float(getattr(unit_dir, 'x', 0.0) or 0.0)
                    current_z = float(getattr(unit_dir, 'z', 0.0) or 0.0)
                    current_len = (current_x * current_x + current_z * current_z) ** 0.5
                if current_len <= 0.0001:
                    return
                current_x /= current_len
                current_z /= current_len

                step_deg = max(0.2, min(20.0, player_spin_speed)) * 0.35
                step_rad = math.radians(step_deg * player_spin_direction)
                cos_v = math.cos(step_rad)
                sin_v = math.sin(step_rad)
                next_x = current_x * cos_v - current_z * sin_v
                next_z = current_x * sin_v + current_z * cos_v

                if math3d is None:
                    return
                next_view = math3d.vector(float(next_x), 0.0, float(next_z))
                if hasattr(next_view, 'normalize'):
                    next_view.normalize()

                my_pos = player.get_position3() if hasattr(player, 'get_position3') else None
                wrote_native_camera = False
                if my_pos and util is not None and hasattr(util, 'set_cam_dir'):
                    try:
                        util.set_cam_dir(cam, my_pos, next_view)
                        wrote_native_camera = True
                    except:
                        wrote_native_camera = False

                try:
                    cam_ctrl.update_para({
                        'rot_hor': float(step_deg * player_spin_direction),
                        'rot_ver': 0.0
                    })
                except:
                    pass

                if not wrote_native_camera and hasattr(player, 'base_view'):
                    try:
                        player.base_view = next_view
                    except:
                        pass
            except:
                pass
            return

        if not active:
            return

        target_x = float(target_dir[0] if len(target_dir) > 0 else 0.0)
        target_z = float(target_dir[2] if len(target_dir) > 2 else 0.0)
        target_len = (target_x * target_x + target_z * target_z) ** 0.5
        if target_len <= 0.0001:
            return
        target_x /= target_len
        target_z /= target_len

        current_dir = None
        try:
            cam = getattr(cam_ctrl, 'cam', None)
            if cam and utils is not None:
                current_dir = util.get_forward_cam(cam)
        except:
            current_dir = None

        current_x = 0.0
        current_z = 0.0
        if current_dir is not None:
            try:
                current_x = float(getattr(current_dir, 'x', 0.0) or 0.0)
                current_z = float(getattr(current_dir, 'z', 0.0) or 0.0)
            except:
                current_x = 0.0
                current_z = 0.0

        current_len = (current_x * current_x + current_z * current_z) ** 0.5
        if current_len <= 0.0001 and hasattr(player, 'get_direction3'):
            try:
                unit_dir = player.get_direction3()
                current_x = float(getattr(unit_dir, 'x', 0.0) or 0.0)
                current_z = float(getattr(unit_dir, 'z', 0.0) or 0.0)
                current_len = (current_x * current_x + current_z * current_z) ** 0.5
            except:
                current_len = 0.0
        if current_len <= 0.0001:
            return
        current_x /= current_len
        current_z /= current_len

        cross_y = current_x * target_z - current_z * target_x
        dot = max(-1.0, min(1.0, current_x * target_x + current_z * target_z))
        angle_deg = 57.2957795 * math.acos(dot)
        if angle_deg <= 1.2:
            return

        yaw_delta = max(-18.0, min(18.0, angle_deg * (1.0 if cross_y > 0.0 else -1.0)))
        try:
            cam_ctrl.update_para({
                'rot_hor': float(yaw_delta),
                'rot_ver': 0.0
            })
        except:
            pass

        try:
            cam = getattr(cam_ctrl, 'cam', None)
            my_pos = player.get_position3() if hasattr(player, 'get_position3') else None
            if cam and my_pos and utils is not None and math3d is not None and hasattr(utils, 'set_cam_dir'):
                dir_vec = math3d.vector(target_x, 0.0, target_z)
                if hasattr(dir_vec, 'normalize'):
                    dir_vec.normalize()
                if hasattr(player, 'base_view'):
                    player.base_view = dir_vec
                util.set_cam_dir(cam, my_pos, dir_vec)
        except:
            pass
    except:
        pass

def check_bone_visibility(bone_pos):
    try:
        if not hasattr(GK, 'g_cam_ctrl') or not GK.g_cam_ctrl or not GK.g_cam_ctrl.cam_handler:
            return False
        camera_pos = GK.g_cam_ctrl.cam_handler.cam.world_position
        if not camera_pos or not bone_pos:
            return False
            
        cur_world = GK.g_world_mgr.cur_world
        from common_cs.CollisionConst import RoleFilter
        filter_obj = RoleFilter()
        result = cur_world.collision_mgr.hit_by_ray_new(camera_pos, bone_pos, filter_obj)
        
        is_blocked = result[0]
        return not is_blocked
    except Exception as e:
        return False

def _build_bone_payload_base():
    bones_data = {"type": "bones", "data": {}, "self_uid": "unknown"}
    try:
        if hasattr(GK, 'g_unit') and GK.g_unit:
            bones_data["self_uid"] = get_player_uid(GK.g_unit)
    except:
        pass
    return bones_data

def _collect_bone_unit_work_items():
    work_items = []
    try:
        unit_mgr = get_available_unit_mgr()
        for player in safe_get_units_from_mgr(unit_mgr, 'get_player_units') or []:
            if player:
                work_items.append(player)
        try:
            from common_cs import ComuKeys
            room = getattr(GK.g_unit, 'room', None) if hasattr(GK, 'g_unit') and GK.g_unit else None
            room_unit_mgr = getattr(room, 'unit_mgr', None) if room else None
            if room_unit_mgr:
                puppets = safe_get_units_by_type_from_mgr(room_unit_mgr, ComuKeys.UNIT_TYPE_CONF.YIDHRA_PUPPET)
                for puppet in puppets or []:
                    try:
                        if puppet and getattr(puppet, 'is_yidhra_puppet', False):
                            work_items.append(puppet)
                    except:
                        pass
        except:
            pass
    except:
        pass
    return work_items

def _append_bone_unit_payload(bones_data, player):
    try:
        if not player:
            return
        uid = get_player_uid(player)
        model = getattr(player, 'model', None)
        anim_data = getattr(player, 'anim_data_component', None)
        if not model or not anim_data:
            return
        player_bones = {}
        for bone_name in TARGET_BONES:
            try:
                bone_pos = anim_data.get_bone_position(bone_name=bone_name)
                if bone_pos:
                    player_bones[bone_name] = {
                        "world": [bone_pos.x, bone_pos.y, bone_pos.z],
                        "screen": [0, 0],
                        "visible": True
                    }
            except:
                pass
        if player_bones:
            bones_data["data"][uid] = player_bones
    except:
        pass

def _run_incremental_bone_collector(loop_now=None, start_new=False):
    state = INCREMENTAL_COLLECTOR_STATE.get("bones", {})
    if start_new or not state.get("active"):
        state["active"] = True
        state["pending_units"] = _collect_bone_unit_work_items()
        state["index"] = 0
        state["result"] = _build_bone_payload_base()
    pending_units = state.get("pending_units", []) or []
    result = state.get("result") or _build_bone_payload_base()
    index = int(state.get("index", 0) or 0)
    end_index = min(len(pending_units), index + INCREMENTAL_BONE_CHUNK_SIZE)
    for current_index in range(index, end_index):
        _append_bone_unit_payload(result, pending_units[current_index])
    state["index"] = end_index
    state["result"] = result
    if end_index >= len(pending_units):
        payload = json.dumps(result)
        _reset_incremental_collector("bones")
        return payload
    return None

def collect_bone_data():
    bones_data = _build_bone_payload_base()
    try:
        for player in _collect_bone_unit_work_items():
            _append_bone_unit_payload(bones_data, player)
    except:
        pass
    return json.dumps(bones_data)

def _build_panel_payload_base():
    return {
        "type": "panels",
        "valid": False,
        "scene_id": -1,
        "in_battle": False,
        "player_count": 0,
        "panels": [],
        "chairs": [],
        "windows": []
    }

def _read_box_bounding_half_extents(row_id):
    row = _get_dm_row('box_bounding', row_id)
    if not isinstance(row, dict):
        return None
    raw_dataconf = row.get('dataconf', ())
    triple = None
    if isinstance(raw_dataconf, (list, tuple)) and raw_dataconf:
        first = raw_dataconf[0]
        if isinstance(first, (list, tuple)) and len(first) >= 3:
            triple = first
        elif len(raw_dataconf) >= 3:
            triple = raw_dataconf
    if not isinstance(triple, (list, tuple)) or len(triple) < 3:
        return None
    return [
        _safe_float(triple[0], 0.0),
        _safe_float(triple[1], 0.0),
        _safe_float(triple[2], 0.0)
    ]

def _build_panel_logic_meta():
    meta = {"valid": False}
    try:
        from common_cs import ComuKeys
    except:
        ComuKeys = None
    try:
        global_table = _get_dm_table('global_data')
        if global_table:
            meta["wood_put_dis"] = _safe_float(global_table.get('wood_put_dis', 25.0), 25.0)
            meta["wood_destroy_dis"] = _safe_float(global_table.get('wood_destroy_dis', 22.0), 22.0)
            meta["wood_span_dis"] = _safe_float(global_table.get('wood_span_dis', 30.0), 30.0)
            raw_hit_range = global_table.get('panel_hit_range', ())
            if isinstance(raw_hit_range, (list, tuple)) and len(raw_hit_range) >= 3:
                meta["panel_hit_forward"] = _safe_float(raw_hit_range[0], 13.0)
                meta["panel_hit_width"] = _safe_float(raw_hit_range[1], 12.0)
                meta["panel_hit_shrink"] = _safe_float(raw_hit_range[2], 3.0)

        panel_box = _read_box_bounding_half_extents(142)
        if panel_box:
            meta["panel_box_half_length"] = _safe_float(panel_box[0], 3.0)
            meta["panel_box_half_height"] = _safe_float(panel_box[1], 3.0)
            meta["panel_box_half_width"] = _safe_float(panel_box[2], 1.0)
        shadow_box = _read_box_bounding_half_extents(141)
        if shadow_box:
            meta["panel_shadow_half_length"] = _safe_float(shadow_box[0], 8.0)
            meta["panel_shadow_half_height"] = _safe_float(shadow_box[1], 4.0)
            meta["panel_shadow_half_width"] = _safe_float(shadow_box[2], 5.0)

        panel_state = getattr(ComuKeys, 'PANEL_STATE', None) if ComuKeys else None
        if panel_state:
            meta["panel_state_idle"] = _safe_int(getattr(panel_state, 'IDLE', 0), 0)
            meta["panel_state_used"] = _safe_int(getattr(panel_state, 'USED', 0), 0)
            meta["panel_state_useing"] = _safe_int(getattr(panel_state, 'USEING', 0), 0)
            meta["panel_state_span"] = _safe_int(getattr(panel_state, 'SPAN', 0), 0)
            meta["panel_state_destroy"] = _safe_int(getattr(panel_state, 'DESTROY', 0), 0)

        meta["valid"] = any(key in meta for key in (
            "wood_put_dis",
            "panel_hit_forward",
            "panel_box_half_length",
            "panel_state_idle"
        ))
    except Exception as e:
        meta["error"] = _safe_uid_text(e)
    return meta

def _append_unique_panel_runtime_items(target_items, item_kind, units, seen_keys):
    for unit in units or []:
        if not unit:
            continue
        try:
            uid_text = _safe_uid_text(getattr(unit, 'uid', ''))
        except:
            uid_text = ''
        unique_key = f"{item_kind}:{uid_text}" if uid_text else f"{item_kind}:mem:{id(unit)}"
        if unique_key in seen_keys:
            continue
        seen_keys.add(unique_key)
        target_items.append((item_kind, unit))

def _read_panel_runtime_state(unit):
    def _read_state_from_obj(obj):
        if not obj:
            return -1
        for attr_name in ("state", "current_state", "cur_state"):
            value = _call_or_get(obj, attr_name, None)
            state_num = _safe_int(value, -1)
            if state_num != -1:
                return state_num
        state_comp = getattr(obj, "_state_comp", None)
        if state_comp:
            for attr_name in ("current_state", "cur_state", "state"):
                value = _call_or_get(state_comp, attr_name, None)
                state_num = _safe_int(value, -1)
                if state_num != -1:
                    return state_num
        return -1

    if not unit:
        return -1
    state_num = _read_state_from_obj(unit)
    if state_num != -1:
        return state_num
    combat_unit = _call_or_get(unit, "get_combat_unit", None)
    state_num = _read_state_from_obj(combat_unit)
    if state_num != -1:
        return state_num
    combat_unit = getattr(unit, "combat_unit", None)
    state_num = _read_state_from_obj(combat_unit)
    if state_num != -1:
        return state_num
    return -1

def _collect_hook_runtime_holders(unit):
    holders = []
    seen_ids = set()

    def append_holder(obj):
        if not obj:
            return
        obj_id = id(obj)
        if obj_id in seen_ids:
            return
        seen_ids.add(obj_id)
        holders.append(obj)

    append_holder(unit)
    append_holder(_call_or_get(unit, 'get_combat_unit', None))
    append_holder(getattr(unit, 'combat_unit', None))
    append_holder(getattr(unit, '_state_comp', None))

    for holder in list(holders):
        append_holder(getattr(holder, '_state_comp', None))
        append_holder(getattr(holder, 'ref_state_comp', None))
        append_holder(getattr(holder, 'state_comp', None))
        append_holder(_get_holder_component_by_keyword(holder, 'UnitComponentType', 'Hook', 'Hook', (
            'ref_hook_comp', 'hook_comp', 'hook_component', 'ref_hook_state_comp', 'hook_state_comp'
        )))
        append_holder(_get_holder_component_by_keyword(holder, 'UnitComponentType', 'Chair', 'Chair', (
            'ref_chair_comp', 'chair_comp', 'chair_component'
        )))
        components = _get_components_dict(holder)
        if isinstance(components, dict):
            for comp_name, comp_obj in components.items():
                try:
                    text = f"{comp_name} {type(comp_obj)}".lower()
                    if 'hook' in text or 'chair' in text:
                        append_holder(comp_obj)
                except:
                    pass
    return holders

def _read_hook_runtime_value_from_holders(holders, attr_names, default=None, invalid_values=None):
    invalid_values = set(() if invalid_values is None else invalid_values)
    for holder in holders or ():
        for attr_name in attr_names:
            value = _call_or_get(holder, attr_name, None)
            if value in invalid_values:
                continue
            if value is not None:
                return value
    return default

def _read_hook_runtime_value(unit, attr_names, default=None, invalid_values=None):
    return _read_hook_runtime_value_from_holders(
        _collect_hook_runtime_holders(unit),
        attr_names,
        default,
        invalid_values
    )

def _read_hook_runtime_state(unit):
    state_num = _read_panel_runtime_state(unit)
    if state_num != -1:
        return state_num
    value = _read_hook_runtime_value(
        unit,
        ('hook_state', 'chair_state', 'state', 'current_state', 'cur_state'),
        default=-1,
        invalid_values={-1, '-1', '', 'unknown'}
    )
    return _safe_int(value, -1)

def _read_hook_runtime_state_from_holders(unit, holders):
    state_num = _read_panel_runtime_state(unit)
    if state_num != -1:
        return state_num
    value = _read_hook_runtime_value_from_holders(
        holders,
        ('hook_state', 'chair_state', 'state', 'current_state', 'cur_state'),
        default=-1,
        invalid_values={-1, '-1', '', 'unknown'}
    )
    return _safe_int(value, -1)

def _start_incremental_panel_collector():
    state = INCREMENTAL_COLLECTOR_STATE.get("panels", {})
    panel_data = _build_panel_payload_base()
    state["active"] = True
    state["items"] = []
    state["index"] = 0
    state["result"] = panel_data
    state["include_debug_details"] = _hook_panels_need_debug_details()
    state["need_chair_runtime"] = _hook_panels_need_chair_runtime()
    state["include_logic_meta"] = _hook_panels_need_logic_meta()
    state["include_static_panels"] = _hook_panels_need_static_cache()
    state["player_unit_lookup"] = {}
    if state["include_static_panels"]:
        panel_data["static_panels"] = []
    state["idle_state"] = 0
    state["state_map"] = {}
    state["hook_state_map"] = {}
    state["unit_mgr"] = None
    state["room"] = None
    panel_context = _get_panel_battle_context()
    state["panel_context"] = panel_context
    panel_data["scene_id"] = panel_context.get("scene_id", -1)
    panel_data["in_battle"] = bool(panel_context.get("in_battle", False))
    panel_data["player_count"] = _safe_int(panel_context.get("player_count", 0), 0)
    try:
        from common_cs import ComuKeys
        player = getattr(GK, 'g_unit', None)
        room = getattr(player, 'room', None) if player else None
        unit_mgr = get_available_unit_mgr()
        ref_unit_mgr = get_available_ref_unit_mgr()
        room_unit_mgr = getattr(room, 'unit_mgr', None) if room else None
        state["room"] = room
        state["unit_mgr"] = unit_mgr or room_unit_mgr or ref_unit_mgr
        manager_candidates = []
        for mgr in (unit_mgr, room_unit_mgr, ref_unit_mgr):
            if mgr and all(mgr is not existing for existing in manager_candidates):
                manager_candidates.append(mgr)
        if not manager_candidates:
            return
        if state["need_chair_runtime"]:
            player_lookup = {}
            for mgr in manager_candidates:
                for method_name in ('get_player_units', 'get_mode_player_units', 'get_copycat_player_units'):
                    try:
                        for player_unit in safe_get_units_from_mgr(mgr, method_name) or []:
                            uid_text = get_player_uid(player_unit)
                            if uid_text and uid_text != "unknown" and uid_text not in player_lookup:
                                player_lookup[uid_text] = player_unit
                    except:
                        pass
            state["player_unit_lookup"] = player_lookup
        panel_state = getattr(ComuKeys, 'PANEL_STATE', None)
        state["idle_state"] = int(getattr(panel_state, 'IDLE', 0)) if panel_state else 0
        scene_changed = (
            _safe_int(PANEL_RUNTIME_CACHE.get("scene_id", -1), -1) != panel_context.get("scene_id", -1) or
            _safe_int(PANEL_RUNTIME_CACHE.get("world_type", -1), -1) != panel_context.get("world_type", -1)
        )
        if not panel_context.get("in_battle", False):
            _reset_panel_runtime_cache()
        elif scene_changed:
            _reset_panel_runtime_cache()
        if state.get("include_logic_meta") and panel_context.get("in_battle", False):
            cached_meta = PANEL_RUNTIME_CACHE.get("logic_meta") or {"valid": False}
            if not bool(cached_meta.get("valid", False)):
                cached_meta = _build_panel_logic_meta()
                PANEL_RUNTIME_CACHE["logic_meta"] = cached_meta
                PANEL_RUNTIME_CACHE["scene_id"] = panel_context.get("scene_id", -1)
                PANEL_RUNTIME_CACHE["world_type"] = panel_context.get("world_type", -1)
                PANEL_RUNTIME_CACHE["in_battle"] = True
            panel_data["panel_logic_meta"] = cached_meta
        if state["include_debug_details"] and panel_state:
            try:
                state["state_map"] = {
                    int(panel_state.IDLE): "