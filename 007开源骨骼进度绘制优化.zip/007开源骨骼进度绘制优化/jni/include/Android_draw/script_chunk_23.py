)",
            "is_closed": True,
            "is_unlock": False,
            "is_opening": False,
            "is_opened": False,
            "room_index": _safe_int(item.get("room_index", -1), -1),
            "model_name": _safe_uid_text(item.get("model_name", "")),
            "drop_item_id": -1,
            "drop_item_num": 0,
            "drop_preview_items": [],
            "drop_preview_count": 0,
            "seed_generated": True,
            "seed_source": _safe_uid_text(replay_result.get("source", "")) or "seed_replay",
            "mark_key_prefix": "frida_seed_reward_%s_" % _sanitize_goldrush_token_part(session_token),
            "icon_path": _get_seed_reward_icon(item)
        })
    return entries, replay_result

def _reward_box_entries_match(a, b, max_distance_sq=6400.0):
    if not isinstance(a, dict) or not isinstance(b, dict):
        return False
    pos_a = a.get("pos", [])
    pos_b = b.get("pos", [])
    if not isinstance(pos_a, (list, tuple)) or len(pos_a) < 3:
        return False
    if not isinstance(pos_b, (list, tuple)) or len(pos_b) < 3:
        return False
    class_a = _safe_uid_text(a.get("class_name", ""))
    class_b = _safe_uid_text(b.get("class_name", ""))
    if class_a and class_b and class_a != class_b:
        return False
    box_id_a = _safe_int(a.get("box_id", -1), -1)
    box_id_b = _safe_int(b.get("box_id", -1), -1)
    if box_id_a > 0 and box_id_b > 0 and box_id_a != box_id_b:
        return False
    room_index_a = _safe_int(a.get("room_index", -1), -1)
    room_index_b = _safe_int(b.get("room_index", -1), -1)
    if room_index_a >= 0 and room_index_b >= 0 and room_index_a != room_index_b:
        return False
    model_name_a = _safe_uid_text(a.get("model_name", ""))
    model_name_b = _safe_uid_text(b.get("model_name", ""))
    if model_name_a and model_name_b and model_name_a != model_name_b:
        return False
    dx = _safe_float(pos_a[0], 0.0) - _safe_float(pos_b[0], 0.0)
    dy = _safe_float(pos_a[1], 0.0) - _safe_float(pos_b[1], 0.0)
    dz = _safe_float(pos_a[2], 0.0) - _safe_float(pos_b[2], 0.0)
    return (dx * dx + dy * dy + dz * dz) <= max_distance_sq

def _merge_seed_reward_boxes_into_payload(payload, scene_id=-1, generation_seed=None):
    if not isinstance(payload, dict):
        return []
    reward_boxes = payload.get("reward_boxes", [])
    if not isinstance(reward_boxes, list):
        reward_boxes = []
    seed_entries = _get_goldrush_seed_runtime_entries(scene_id, generation_seed)
    if not seed_entries:
        payload["reward_boxes"] = reward_boxes
        return []
    merged_reward_boxes = []
    matched_live_indexes = set()
    sync_keys = (
        "scan_text", "box_id", "box_type", "reward_id", "box_quality", "box_quality_label",
        "box_quality_color", "box_level", "class_level", "display_item_quality", "gm_item_id",
        "gm_is_mega_gold", "gm_display_quality", "override_reward_id", "ban_pre_open",
        "room_index", "model_name", "config_model_path", "box_kind", "box_state",
        "box_state_name", "is_closed", "is_unlock", "is_opening", "is_opened",
        "open_player_uid", "open_timer_active", "reset_timer_active", "unlock_timer_active",
        "hp", "max_hp", "config_box_anim_type", "config_reward_id", "config_box_quality",
        "config_box_level", "drop_item_id", "drop_item_num", "drop_preview_items",
        "drop_preview_count"
    )
    for seed_entry in seed_entries:
        merged_entry = dict(seed_entry)
        matched_live = None
        for index, live_entry in enumerate(reward_boxes):
            if _reward_box_entries_match(seed_entry, live_entry):
                matched_live = live_entry
                matched_live_indexes.add(index)
                break
        if isinstance(matched_live, dict):
            merged_entry["live_uid"] = _safe_uid_text(matched_live.get("uid", ""))
            merged_entry["live_pos"] = list(matched_live.get("pos", []) or [])
            for key in sync_keys:
                if key in matched_live:
                    merged_entry[key] = matched_live.get(key)
        merged_reward_boxes.append(merged_entry)
    for index, live_entry in enumerate(reward_boxes):
        if index in matched_live_indexes:
            continue
        merged_reward_boxes.append(live_entry)
    payload["reward_boxes"] = merged_reward_boxes
    return seed_entries

def _box_is_opened(entity):
    state_text = _safe_uid_text(getattr(entity, "_box_state", ""))
    if "open" in state_text.lower():
        return True
    return _safe_bool(getattr(entity, "is_opened", False))

def _get_reward_box_icon(entity):
    info = getattr(entity, "_box_data_info", None) or {}
    if _box_is_opened(entity):
        icon_path = info.get("map_icon_opened", "") if hasattr(info, "get") else ""
        return icon_path or REWARD_ICON_OPENED_DEFAULT
    icon_path = info.get("map_icon", "") if hasattr(info, "get") else ""
    return icon_path or REWARD_ICON_DEFAULT

def _get_alchemy_icon(entity):
    data = getattr(entity, "_box_data", None) or {}
    is_done = _safe_bool(getattr(entity, "_is_done", False))
    if is_done:
        icon_path = data.get("map_icon_opened", "") if hasattr(data, "get") else ""
        return icon_path or ALCHEMY_ICON_OPENED_DEFAULT
    icon_path = data.get("map_icon", "") if hasattr(data, "get") else ""
    return icon_path or ALCHEMY_ICON_DEFAULT

def _stash_add_mark(stash_system, key, pos, icon_path):
    if not stash_system:
        return {"ok": False, "reason": "stash_missing"}
    try:
        world_position = _make_vector(pos)
        if world_position is None:
            return {"ok": False, "reason": "invalid_position"}
        stash_system.add(key, {
            "type": "mark_button",
            "world_position": world_position,
            "icon_path": icon_path
        })
        return {"ok": True, "result": "stash_add"}
    except Exception as e:
        return {"ok": False, "reason": str(e)}

def _add_minimap_mark(key, pos, icon_path, stash_system):
    world_position = _make_vector(pos)
    if world_position is None:
        return {"ok": False, "reason": "invalid_position"}
    try:
        from common_cs.combat_core.utils import goldrush_utils
        add_mark = getattr(goldrush_utils, "add_minimap_mark_icon", None)
        if callable(add_mark):
            add_mark(key, world_position, icon_path)
            return {"ok": True, "result": "goldrush_utils.add_minimap_mark_icon"}
    except:
        pass
    return _stash_add_mark(stash_system, key, world_position, icon_path)

def _flush_stash(stash_system, minimap_ui, big_map_ui):
    results = []
    for ui_obj, name in ((minimap_ui, "minimap"), (big_map_ui, "big_map")):
        if not ui_obj or not stash_system:
            continue
        try:
            stash_system.flush_to(ui_obj)
            results.append({"ui": name, "ok": True})
        except Exception as e:
            results.append({"ui": name, "ok": False, "reason": str(e)})
    return results

def _recover_ui_fog(minimap_ui, big_map_ui, fog_bitmap):
    refreshes = []
    for ui_obj, ui_name in ((minimap_ui, "minimap"), (big_map_ui, "big_map")):
        if not ui_obj or not fog_bitmap:
            continue
        refreshes.append({"ui": ui_name, "result": _call_if_exists(ui_obj, "recover_fog", fog_bitmap)})
    return refreshes

def _mark_reward_boxes(entity_mgr, stash_system):
    entities = _get_entities_by_type(entity_mgr, "GoldRushRewardBox")
    marked_count = 0
    for index, entity in enumerate(entities):
        try:
            pos = _get_position3(entity)
            if not pos:
                continue
            icon_path = _get_reward_box_icon(entity)
            mark_key = "hook_reward_box_%s" % _safe_uid_text(getattr(entity, "entity_id", index))
            result = _add_minimap_mark(mark_key, pos, icon_path, stash_system)
            if result.get("ok"):
                marked_count += 1
        except:
            pass
    return {"count": len(entities), "marked_count": marked_count}

def _mark_alchemy_boxes(entity_mgr, stash_system):
    entities = _get_entities_by_type(entity_mgr, "GoldRushAlchemyBox")
    marked_count = 0
    for index, entity in enumerate(entities):
        try:
            pos = _get_position3(entity)
            if not pos:
                continue
            icon_path = _get_alchemy_icon(entity)
            mark_key = "hook_alchemy_box_%s" % _safe_uid_text(getattr(entity, "entity_id", index))
            result = _add_minimap_mark(mark_key, pos, icon_path, stash_system)
            if result.get("ok"):
                marked_count += 1
        except:
            pass
    return {"count": len(entities), "marked_count": marked_count}

def _start_goldrush_open_map_job(request_source="manual"):
    return _run_goldrush_open_fog_via_level_mask(request_source, 140)

def _mark_entity_batch(job, entity_key, index_key, marked_key, key_prefix, icon_getter):
    entities = job.get(entity_key, []) or []
    current_index = int(job.get(index_key, 0) or 0)
    stash_system = job.get("stash_system")
    end_index = min(len(entities), current_index + GOLDRUSH_FOG_MARK_BATCH_SIZE)
    for index in range(current_index, end_index):
        entity = entities[index]
        try:
            pos = _get_position3(entity)
            if not pos:
                continue
            icon_path = icon_getter(entity)
            mark_key = "%s_%s" % (key_prefix, _safe_uid_text(getattr(entity, "entity_id", index)))
            result = _add_minimap_mark(mark_key, pos, icon_path, stash_system)
            if result.get("ok"):
                job[marked_key] = int(job.get(marked_key, 0) or 0) + 1
        except:
            pass
    job[index_key] = end_index
    return end_index >= len(entities)

def _mark_seed_reward_batch(job):
    seed_entries = job.get("reward_seed_entries", []) or []
    current_index = int(job.get("reward_index", 0) or 0)
    stash_system = job.get("stash_system")
    mark_key_prefix = _safe_uid_text(job.get("reward_mark_key_prefix", ""))
    end_index = min(len(seed_entries), current_index + GOLDRUSH_FOG_MARK_BATCH_SIZE)
    for index in range(current_index, end_index):
        entry = seed_entries[index]
        try:
            pos = entry.get("pos", [])
            icon_path = _safe_uid_text(entry.get("icon_path", "")) or REWARD_ICON_DEFAULT
            mark_key = "%s%s_%s_%s" % (
                mark_key_prefix or "frida_seed_reward_",
                _safe_uid_text(entry.get("room_index", "")),
                _sanitize_goldrush_token_part(entry.get("model_name")),
                _safe_uid_text(entry.get("seed_item_index", index))
            )
            result = _add_minimap_mark(mark_key, pos, icon_path, stash_system)
            if result.get("ok"):
                job["reward_marked_count"] = int(job.get("reward_marked_count", 0) or 0) + 1
        except:
            pass
    job["reward_index"] = end_index
    return end_index >= len(seed_entries)

def _finish_goldrush_fog_job(job, status_override=None):
    global GOLDRUSH_FOG_LAST_RESULT, GOLDRUSH_FOG_JOB
    result = dict(job.get("result", {}) or {})
    bitmap_result = job.get("bitmap_result", {}) or {}
    flush_results = job.get("flush_results", []) or []
    result["phase"] = "finished"
    result["updated_at"] = time.time()
    result["cleared_point_count"] = _safe_int(bitmap_result.get("clear_count", 0), 0)
    result["ui_refresh_count"] = len(job.get("recover_results", []) or [])
    reward_seed_entries = job.get("reward_seed_entries", []) or []
    result["reward_box_count"] = len(reward_seed_entries)
    result["reward_box_marked_count"] = _safe_int(job.get("reward_marked_count", 0), 0)
    result["alchemy_box_count"] = len(job.get("alchemy_entities", []) or [])
    result["alchemy_box_marked_count"] = _safe_int(job.get("alchemy_marked_count", 0), 0)
    result["flush_ok_count"] = sum(1 for item in flush_results if item.get("ok"))

    fog_ok = bool(bitmap_result.get("ok")) or bool((job.get("gm_clear_result") or {}).get("ok"))
    mark_ok = result["reward_box_marked_count"] > 0 or result["alchemy_box_marked_count"] > 0
    flush_ok = result["flush_ok_count"] > 0
    result["success"] = fog_ok or mark_ok or flush_ok
    if status_override:
        result["status"] = status_override
    else:
        result["status"] = "ok" if result["success"] else "no_effect"
    GOLDRUSH_FOG_LAST_RESULT = result
    GOLDRUSH_FOG_JOB = {"active": False}
    publish_valid = bool(reward_seed_entries) or bool(result.get("success"))
    _publish_goldrush_runtime_snapshot(result.get("updated_at"), not publish_valid, result.get("status", ""))
    return result

def _advance_goldrush_fog_job(loop_now):
    global GOLDRUSH_FOG_LAST_RESULT, GOLDRUSH_FOG_JOB
    job = GOLDRUSH_FOG_JOB
    if not job.get("active"):
        return
    now_value = float(loop_now or time.time())
    if now_value < float(job.get("next_step_at", 0.0) or 0.0):
        return

    result = job.get("result", {}) or {}
    phase = job.get("phase", "finished")
    debug_started_at = time.time()
    debug_phase_in = _safe_uid_text(phase)
    result["phase"] = phase
    result["status"] = "running"
    result["updated_at"] = time.time()
    result["cleared_point_count"] = _safe_int((job.get("bitmap_result", {}) or {}).get("clear_count", 0), 0)
    result["reward_box_marked_count"] = _safe_int(job.get("reward_marked_count", 0), 0)
    result["alchemy_box_marked_count"] = _safe_int(job.get("alchemy_marked_count", 0), 0)
    GOLDRUSH_FOG_LAST_RESULT = dict(result)

    try:
        if phase == "wait_map_loading":
            combat_core = get_available_combat_core() or job.get("combat_core")
            if combat_core:
                job["combat_core"] = combat_core
            if not _goldrush_map_loading_ready(combat_core):
                if now_value >= float(job.get("loading_deadline", 0.0) or 0.0):
                    _finish_goldrush_fog_job(job, "map_loading_timeout")
                    return
                result["status"] = "waiting_map_loading"
                GOLDRUSH_FOG_LAST_RESULT = dict(result)
            elif not _goldrush_replay_inputs_ready(combat_core):
                if now_value >= float(job.get("loading_deadline", 0.0) or 0.0):
                    _finish_goldrush_fog_job(job, "replay_inputs_timeout")
                    return
                result["status"] = "waiting_replay_inputs"
                GOLDRUSH_FOG_LAST_RESULT = dict(result)
            else:
                map_info = get_current_map_info() or {}
                refreshed_scene_id = _safe_int(map_info.get("scene_id", result.get("scene_id", -1)), -1)
                result["scene_id"] = refreshed_scene_id
                entity_mgr = _get_entity_mgr(combat_core) or job.get("entity_mgr")
                stash_system = _get_stash_system(combat_core) or job.get("stash_system")
                minimap_ui = _find_ui_by_name("UIBattleGoldRushMiniMap") or job.get("minimap_ui")
                big_map_ui = _find_ui_by_name("UIBattleGoldRushBigMap") or job.get("big_map_ui")
                removed_mark_count = _clear_goldrush_open_map_marks(stash_system, minimap_ui, big_map_ui)
                if removed_mark_count > 0:
                    result["removed_mark_count"] = _safe_int(result.get("removed_mark_count", 0), 0) + removed_mark_count
                job["entity_mgr"] = entity_mgr
                job["stash_system"] = stash_system
                job["minimap_ui"] = minimap_ui
                job["big_map_ui"] = big_map_ui
                seed_reward_entries = _build_seed_reward_box_runtime_entries(
                    combat_core,
                    refreshed_scene_id,
                    True
                )
                replay_result = {}
                if isinstance(seed_reward_entries, tuple):
                    seed_reward_entries, replay_result = seed_reward_entries
                result["generation_seed"] = replay_result.get("generation_seed")
                result["now_round_seed"] = replay_result.get("now_round_seed")
                result["selected_count"] = _safe_int(replay_result.get("selected_count", 0), 0)
                result["candidate_count"] = _safe_int(replay_result.get("candidate_count", 0), 0)
                result["collected_candidate_count"] = _safe_int(replay_result.get("collected_candidate_count", 0), 0)
                result["postprocess_group_counts"] = dict(replay_result.get("postprocess_group_counts", {}) or {})
                result["candidate_lookup_stats"] = dict(replay_result.get("candidate_lookup_stats", {}) or {})
                result["runtime_token_validation"] = dict(replay_result.get("runtime_token_validation", {}) or {})
                result["reward_boxes_source"] = _safe_uid_text(replay_result.get("source", ""))
                result["session_token"] = _build_goldrush_session_token(replay_result)
                result["reward_boxes_mark_key_prefix"] = "frida_seed_reward_%s_" % _sanitize_goldrush_token_part(result.get("session_token"))
                alchemy_entities = _get_entities_by_type(entity_mgr, "GoldRushAlchemyBox")
                _set_goldrush_seed_runtime_entries(
                    refreshed_scene_id,
                    seed_reward_entries,
                    "manual_open_map",
                    result.get("generation_seed")
                )
                result["reward_box_count"] = len(seed_reward_entries)
                result["alchemy_box_count"] = len(alchemy_entities)
                job["reward_seed_entries"] = seed_reward_entries
                job["reward_mark_key_prefix"] = result.get("reward_boxes_mark_key_prefix", "")
                job["generation_seed"] = result.get("generation_seed")
                job["reward_index"] = 0
                job["reward_marked_count"] = 0
                job["alchemy_entities"] = alchemy_entities
                job["alchemy_index"] = 0
                job["alchemy_marked_count"] = 0
                bitmap_plan = _prepare_goldrush_fog_bitmap_plan(
                    combat_core,
                    result["reward_box_count"],
                    len(alchemy_entities)
                )
                job["fog_bitmap"] = bitmap_plan.get("fog_bitmap")
                job["fog_raw_data"] = bitmap_plan.get("fog_raw_data")
                job["fog_fill_total_len"] = _safe_int(bitmap_plan.get("fog_fill_total_len", 0), 0)
                job["fog_fill_offset"] = 0
                job["fog_fill_chunk_size"] = _safe_int(bitmap_plan.get("fog_fill_chunk_size", 0), 0)
                job["bitmap_result"] = bitmap_plan.get("bitmap_result", {"ok": False, "clear_count": 0})
                job["phase"] = "gm_clear"
        elif not _goldrush_fog_job_scene_valid(job, result):
            current_core = get_available_combat_core() or job.get("combat_core")
            current_stash = _get_stash_system(current_core) or job.get("stash_system")
            current_minimap = _find_ui_by_name("UIBattleGoldRushMiniMap") or job.get("minimap_ui")
            current_big_map = _find_ui_by_name("UIBattleGoldRushBigMap") or job.get("big_map_ui")
            _clear_goldrush_open_map_marks(current_stash, current_minimap, current_big_map)
            _set_goldrush_seed_runtime_entries(-1, [], "scene_changed_abort", None)
            _finish_goldrush_fog_job(job, "scene_changed_abort")
            return
        elif phase == "gm_clear":
            job["gm_clear_result"] = _call_if_exists(job.get("minimap_ui"), "gm_clear_all_fog")
            _call_if_exists(job.get("big_map_ui"), "set_visible_big_map", True)
            job["phase"] = "bitmap"
        elif phase == "bitmap":
            if job.get("fog_raw_data") and int(job.get("fog_fill_total_len", 0) or 0) > 0:
                if _fill_goldrush_fog_bitmap_chunk(job):
                    job["phase"] = "reward_boxes"
            else:
                bitmap_result, fog_bitmap = _force_full_visible_via_bitmap(job.get("combat_core"), False)
                job["bitmap_result"] = bitmap_result
                job["fog_bitmap"] = fog_bitmap
                job["phase"] = "reward_boxes"
        elif phase == "reward_boxes":
            reward_seed_entries = job.get("reward_seed_entries", []) or []
            if reward_seed_entries:
                finished = _mark_seed_reward_batch(job)
            else:
                finished = True
            if finished:
                job["phase"] = "alchemy_boxes"
        elif phase == "alchemy_boxes":
            if _mark_entity_batch(job, "alchemy_entities", "alchemy_index", "alchemy_marked_count", "hook_alchemy_box", _get_alchemy_icon):
                job["phase"] = "recover_minimap"
        elif phase == "recover_minimap":
            minimap_ui = job.get("minimap_ui")
            fog_bitmap = job.get("fog_bitmap")
            if minimap_ui and fog_bitmap:
                job["recover_results"].append({
                    "ui": "minimap",
                    "result": _call_if_exists(minimap_ui, "recover_fog", fog_bitmap)
                })
            job["phase"] = "recover_big_map"
        elif phase == "recover_big_map":
            big_map_ui = job.get("big_map_ui")
            fog_bitmap = job.get("fog_bitmap")
            if big_map_ui and fog_bitmap:
                job["recover_results"].append({
                    "ui": "big_map",
                    "result": _call_if_exists(big_map_ui, "recover_fog", fog_bitmap)
                })
            job["phase"] = "flush_minimap"
        elif phase == "flush_minimap":
            stash_system = job.get("stash_system")
            minimap_ui = job.get("minimap_ui")
            if stash_system and minimap_ui:
                try:
                    stash_system.flush_to(minimap_ui)
                    job["flush_results"].append({"ui": "minimap", "ok": True})
                except Exception as e:
                    job["flush_results"].append({"ui": "minimap", "ok": False, "reason": str(e)})
            job["phase"] = "flush_big_map"
        elif phase == "flush_big_map":
            stash_system = job.get("stash_system")
            big_map_ui = job.get("big_map_ui")
            if stash_system and big_map_ui:
                try:
                    stash_system.flush_to(big_map_ui)
                    job["flush_results"].append({"ui": "big_map", "ok": True})
                except Exception as e:
                    job["flush_results"].append({"ui": "big_map", "ok": False, "reason": str(e)})
            _finish_goldrush_fog_job(job)
            return
        else:
            _finish_goldrush_fog_job(job, "invalid_phase")
            return
        job["next_step_at"] = now_value + GOLDRUSH_FOG_STEP_DELAY_SEC
    except Exception as e:
        _finish_goldrush_fog_job(job, "error:%s" % str(e))
    finally:
        try:
            debug_phase_out = _safe_uid_text(job.get("phase", debug_phase_in))
            _goldrush_debug_perf(
                "fog_job_tick",
                "E",
                "main.cpp:_advance_goldrush_fog_job",
                (time.time() - debug_started_at) * 1000.0,
                {
                    "phase_in": debug_phase_in,
                    "phase_out": debug_phase_out,
                    "active": bool(job.get("active")),
                    "result_status": _safe_uid_text(result.get("status", "")),
                    "reward_index": _safe_int(job.get("reward_index", 0), 0),
                    "alchemy_index": _safe_int(job.get("alchemy_index", 0), 0)
                }
            )
            if debug_phase_in != debug_phase_out:
                _goldrush_debug_emit(
                    "E",
                    "main.cpp:_advance_goldrush_fog_job",
                    "[DEBUG] fog job phase changed",
                    {
                        "phase_in": debug_phase_in,
                        "phase_out": debug_phase_out,
                        "active": bool(job.get("active")),
                        "result_status": _safe_uid_text(result.get("status", ""))
                    }
                )
        except:
            pass

#region 