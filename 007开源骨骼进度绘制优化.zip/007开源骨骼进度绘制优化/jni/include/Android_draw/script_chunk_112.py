":
            return {"color": "#4aa3ff", "icon": "box_blue", "layer": "reward_box", "priority": 80}
        return {"color": "#d6e4ff", "icon": "box", "layer": "reward_box", "priority": 75}
    if marker_kind == "alchemy_boxes":
        return {"color": "#66d9c2", "icon": "alchemy", "layer": "alchemy_box", "priority": 74}
    if marker_kind == "teleports":
        return {"color": "#64e5ff", "icon": "teleport", "layer": "teleport", "priority": 73}
    if marker_kind == "basecamp_points":
        return {"color": "#7fd96f", "icon": "camp", "layer": "basecamp", "priority": 70}
    if marker_kind == "escape_submit_points":
        return {"color": "#ffcf66", "icon": "submit", "layer": "submit_point", "priority": 76}
    if marker_kind == "scene_windows":
        return {"color": "#cccccc", "icon": "window", "layer": "scene_window", "priority": 50}
    if marker_kind == "scene_panels":
        return {"color": "#bbbbbb", "icon": "panel", "layer": "scene_panel", "priority": 50}
    return {"color": "#ffffff", "icon": "marker", "layer": "marker", "priority": 10}

def _project_goldrush_world_points(points, limit=128):
    result = {
        "world_points": [],
        "raw_points": [],
        "design_points": [],
        "visible_world_points": [],
        "visible_raw_points": [],
        "visible_design_points": [],
        "valid_count": 0,
        "visible_count": 0
    }
    for world_pos in points or []:
        if len(result["world_points"]) >= limit:
            break
        screen_point = _world_to_screen_point(world_pos)
        if not screen_point.get("valid"):
            continue
        world_point = list(world_pos[:3]) if isinstance(world_pos, (list, tuple)) and len(world_pos) >= 3 else [0.0, 0.0, 0.0]
        raw_point = list(screen_point.get("raw", [0.0, 0.0]))
        design_point = list(screen_point.get("design", [0.0, 0.0]))
        result["world_points"].append(world_point)
        result["raw_points"].append(raw_point)
        result["design_points"].append(design_point)
        result["valid_count"] += 1
        if screen_point.get("visible"):
            result["visible_world_points"].append(world_point)
            result["visible_raw_points"].append(raw_point)
            result["visible_design_points"].append(design_point)
            result["visible_count"] += 1
    return result

def _build_goldrush_visible_polyline_element(element):
    points = list((element or {}).get("points", []) or [])
    projected = _project_goldrush_world_points(points, 8)
    if projected.get("visible_count", 0) < 2:
        return None
    visible_world_points = list(projected.get("visible_world_points", []) or [])
    visible_raw_points = list(projected.get("visible_raw_points", []) or [])
    visible_design_points = list(projected.get("visible_design_points", []) or [])
    visible_segments = []
    for index in range(1, min(len(visible_design_points), len(visible_world_points))):
        visible_segments.append({
            "from": list(visible_design_points[index - 1]),
            "to": list(visible_design_points[index]),
            "world_from": list(visible_world_points[index - 1]),
            "world_to": list(visible_world_points[index])
        })
    visible_entry = dict(element)
    visible_entry["world_points"] = visible_world_points
    visible_entry["screen_points"] = {
        "raw": visible_raw_points,
        "design": visible_design_points
    }
    visible_entry["screen_visible"] = True
    visible_entry["screen_visible_point_count"] = len(visible_design_points)
    visible_entry["screen_segments"] = visible_segments
    return visible_entry

def _build_goldrush_visible_polygon_element(element):
    points = list((element or {}).get("points", []) or [])
    projected = _project_goldrush_world_points(points, 256)
    if projected.get("visible_count", 0) < 3:
        return None
    visible_entry = dict(element)
    visible_entry["world_points"] = list(projected.get("visible_world_points", []) or [])
    visible_entry["screen_points"] = {
        "raw": list(projected.get("visible_raw_points", []) or []),
        "design": list(projected.get("visible_design_points", []) or [])
    }
    visible_entry["screen_visible"] = True
    visible_entry["screen_visible_point_count"] = projected.get("visible_count", 0)
    return visible_entry

def _build_goldrush_visible_marker_element(element):
    pos = list((element or {}).get("pos", []) or [])
    screen_point = _world_to_screen_point(pos)
    if not screen_point.get("valid") or not screen_point.get("visible"):
        return None
    visible_entry = dict(element)
    visible_entry["screen_pos"] = {
        "raw": list(screen_point.get("raw", [0.0, 0.0])),
        "design": list(screen_point.get("design", [0.0, 0.0]))
    }
    visible_entry["screen_visible"] = True
    return visible_entry

def _build_goldrush_visible_draw_elements(polyline_elements, polygon_elements, marker_elements):
    visible_polylines = []
    visible_polygons = []
    visible_markers = []
    for element in polyline_elements or []:
        visible_entry = _build_goldrush_visible_polyline_element(element)
        if visible_entry:
            visible_polylines.append(visible_entry)
    for element in polygon_elements or []:
        visible_entry = _build_goldrush_visible_polygon_element(element)
        if visible_entry:
            visible_polygons.append(visible_entry)
    for element in marker_elements or []:
        visible_entry = _build_goldrush_visible_marker_element(element)
        if visible_entry:
            visible_markers.append(visible_entry)
    return {
        "polylines": visible_polylines,
        "polygons": visible_polygons,
        "markers": visible_markers
    }

def _build_goldrush_esp_protocol(scene_refs, bounds, polyline_elements, polygon_elements, marker_elements):
    visible_elements = _build_goldrush_visible_draw_elements(polyline_elements, polygon_elements, marker_elements)
    return {
        "protocol": "goldrush_esp_v1",
        "type": "esp_draw_elements",
        "meta": {
            "scene_id": _safe_int(scene_refs.get("scene_id", -1), -1),
            "generated_at": int(time.time()) if 'time' in globals() else 0,
            "screen_size": list(getattr(GK, 'g_screen_size', []) or []),
            "design_size": list(getattr(GK, 'g_design_size', []) or []),
            "bounds": dict(bounds or {})
        },
        "layers": {
            "polylines": visible_elements.get("polylines", []),
            "polygons": visible_elements.get("polygons", []),
            "markers": visible_elements.get("markers", [])
        },
        "counts": {
            "polyline_count": len(visible_elements.get("polylines", []) or []),
            "polygon_count": len(visible_elements.get("polygons", []) or []),
            "marker_count": len(visible_elements.get("markers", []) or [])
        }
    }

def _build_goldrush_draw_polyline_elements(grouped_segments, line_kind, limit=8192):
    elements = []
    for floor_value in sorted((grouped_segments or {}).keys()):
        for segment in grouped_segments.get(floor_value, []) or []:
            style_info = _get_goldrush_line_draw_style(line_kind, segment)
            elements.append({
                "kind": "polyline",
                "line_kind": line_kind,
                "layer": style_info.get("layer", line_kind),
                "floor": floor_value,
                "points": [list(segment.get("from", [0.0, 0.0, 0.0])), list(segment.get("to", [0.0, 0.0, 0.0]))],
                "color": style_info.get("color", "#ffffff"),
                "width": _safe_float(style_info.get("width", 1.0), 1.0),
                "style": style_info.get("style", "solid"),
                "priority": _safe_int(style_info.get("priority", 10), 10),
                "line_axis": segment.get("line_axis", ""),
                "normal_axis": segment.get("normal_axis", ""),
                "direction_label": segment.get("direction_label", ""),
                "yaw_deg": _safe_float(segment.get("yaw_deg", 0.0), 0.0)
            })
            if len(elements) >= limit:
                return elements
    return elements

def _build_goldrush_draw_polygon_elements(room_polygons, limit=2048):
    elements = []
    for polygon_entry in room_polygons or []:
        style_info = _get_goldrush_room_draw_style(
            polygon_entry.get("room_label", ""),
            polygon_entry.get("room_tags", [])
        )
        elements.append({
            "kind": "polygon",
            "layer": style_info.get("layer", "room_common"),
            "floor": _safe_int(polygon_entry.get("floor", 0), 0),
            "points": list(polygon_entry.get("points", []) or []),
            "color": style_info.get("color", "#4aa3ff"),
            "fill_color": style_info.get("fill_color", "#4aa3ff18"),
            "stroke_color": style_info.get("stroke_color", "#4aa3ff"),
            "stroke_width": 1.5,
            "priority": _safe_int(style_info.get("priority", 50), 50),
            "room_index": _safe_int(polygon_entry.get("room_index", -1), -1),
            "room_label": polygon_entry.get("room_label", ""),
            "room_tags": list(polygon_entry.get("room_tags", []) or [])
        })
        if len(elements) >= limit:
            return elements
    return elements

def _build_goldrush_draw_marker_elements(object_layers, limit=4096):
    elements = []
    marker_order = [
        "doors",
        "interactive_entities",
        "reward_boxes",
        "alchemy_boxes",
        "teleports",
        "basecamp_points",
        "escape_submit_points",
        "scene_windows",
        "scene_panels"
    ]
    for marker_kind in marker_order:
        for entry in (object_layers or {}).get(marker_kind, []) or []:
            style_info = _get_goldrush_marker_draw_style(marker_kind, entry)
            pos = list(entry.get("pos", entry.get("interact_pos", [0.0, 0.0, 0.0])))
            elements.append({
                "kind": "marker",
                "marker_kind": marker_kind,
                "layer": style_info.get("layer", marker_kind),
                "floor": _get_goldrush_world_floor(pos),
                "pos": pos,
                "color": style_info.get("color", "#ffffff"),
                "icon": style_info.get("icon", "marker"),
                "priority": _safe_int(style_info.get("priority", 10), 10),
                "label": _safe_uid_text(
                    entry.get("door_label", "") or
                    entry.get("special_label", "") or
                    entry.get("box_kind", "") or
                    entry.get("class_name", "") or
                    marker_kind
                ),
                "uid": entry.get("uid", ""),
                "room_index": _safe_int(entry.get("room_index", -1), -1),
                "meta": dict(entry)
            })
            if len(elements) >= limit:
                return elements
    return elements

def _build_goldrush_draw_pack(scene_refs, bounds, geometry_rooms, combined_outline_segments, combined_path_segments, combined_doorway_segments, object_layers):
    room_polygons = []
    door_markers = []
    for room_entry in geometry_rooms or []:
        for polygon_entry in room_entry.get("room_polygons", []) or []:
            room_polygons.append({
                "room_index": room_entry.get("room_index", -1),
                "room_label": room_entry.get("room_label", ""),
                "room_tags": list(room_entry.get("room_tags", []) or []),
                "floor": _safe_int(polygon_entry.get("floor", 0), 0),
                "points": list(polygon_entry.get("points", []) or []),
                "point_count": _safe_int(polygon_entry.get("point_count", 0), 0)
            })
    for entry in object_layers.get("doors", []) or []:
        marker_entry = dict(entry)
        marker_entry["floor"] = _get_goldrush_world_floor(entry.get("pos", [0.0, 0.0, 0.0]))
        door_markers.append(marker_entry)

    floor_groups = _build_goldrush_floor_groups(
        geometry_rooms,
        combined_outline_segments,
        combined_path_segments,
        combined_doorway_segments,
        object_layers
    )
    outline_lines = _group_goldrush_segments_by_floor(combined_outline_segments, 4096)
    path_lines = _group_goldrush_segments_by_floor(combined_path_segments, 4096)
    doorway_lines = _group_goldrush_segments_by_floor(combined_doorway_segments, 2048)
    polyline_elements = []
    polyline_elements.extend(_build_goldrush_draw_polyline_elements(outline_lines, "outline", 4096))
    polyline_elements.extend(_build_goldrush_draw_polyline_elements(path_lines, "path", 4096))
    polyline_elements.extend(_build_goldrush_draw_polyline_elements(doorway_lines, "doorway", 2048))
    polygon_elements = _build_goldrush_draw_polygon_elements(room_polygons, 2048)
    marker_elements = _build_goldrush_draw_marker_elements(object_layers, 4096)
    esp_protocol = _build_goldrush_esp_protocol(
        scene_refs,
        bounds,
        polyline_elements,
        polygon_elements,
        marker_elements
    )
    return {
        "scene_refs": scene_refs,
        "bounds": bounds,
        "floor_groups": floor_groups,
        "room_polygons": room_polygons,
        "line_layers": {
            "outline": outline_lines,
            "path": path_lines,
            "doorway": doorway_lines
        },
        "door_markers": door_markers,
        "polylines": polyline_elements,
        "polygons": polygon_elements,
        "markers": marker_elements,
        "esp_protocol": esp_protocol,
        "stats": {
            "floor_group_count": len(floor_groups),
            "room_polygon_count": len(room_polygons),
            "door_marker_count": len(door_markers),
            "polyline_count": len(polyline_elements),
            "polygon_count": len(polygon_elements),
            "marker_count": len(marker_elements),
            "visible_polyline_count": len(esp_protocol.get("layers", {}).get("polylines", []) or []),
            "visible_polygon_count": len(esp_protocol.get("layers", {}).get("polygons", []) or []),
            "visible_marker_count": len(esp_protocol.get("layers", {}).get("markers", []) or [])
        }
    }

def _build_goldrush_full_map_geometry(payload):
    room_entries = payload.get("maze_rooms", []) or []
    combined_outline_segments = _merge_goldrush_world_segments(room_entries, "world_outline_segments", 4096)
    combined_path_segments = _merge_goldrush_world_segments(room_entries, "world_path_segments", 4096)
    combined_doorway_segments = _merge_goldrush_world_segments(room_entries, "doorway_world_segments", 2048)
    model_refs = _collect_goldrush_full_map_model_refs(payload, 256)
    bounds = _build_goldrush_full_map_bounds(room_entries)

    geometry_rooms = []
    for room_entry in room_entries:
        room_polygons = _build_world_polygons_from_segments(room_entry.get("world_outline_segments", []) or [], 16, 256)
        room_floors = _get_goldrush_room_floor_list(room_entry)
        geometry_rooms.append({
            "uid": room_entry.get("uid", ""),
            "room_id": _safe_int(room_entry.get("room_id", -1), -1),
            "config_id": _safe_int(room_entry.get("config_id", -1), -1),
            "room_index": _safe_int(room_entry.get("room_index", -1), -1),
            "room_type": _safe_int(room_entry.get("room_type", -1), -1),
            "room_type_name": room_entry.get("room_type_name", ""),
            "room_label": room_entry.get("room_label", ""),
            "room_map_path": room_entry.get("room_map_path", ""),
            "cannot_teleport": bool(room_entry.get("cannot_teleport", False)),
            "pos": list(room_entry.get("pos", [0.0, 0.0, 0.0])),
            "voxel_bounds": dict(room_entry.get("voxel_bounds", {}) or {}),
            "room_floors": room_floors,
            "voxel_count": _safe_int(room_entry.get("voxel_count", 0), 0),
            "path_count": _safe_int(room_entry.get("path_count", 0), 0),
            "outline_segment_count": _safe_int(room_entry.get("world_outline_segment_count", 0), 0),
            "path_segment_count": _safe_int(room_entry.get("world_path_segment_count", 0), 0),
            "doorway_segment_count": _safe_int(room_entry.get("doorway_world_segment_count", 0), 0),
            "room_tags": list(room_entry.get("room_tags", []) or []),
            "group_names": list(room_entry.get("group_names", []) or []),
            "model_names": list(room_entry.get("model_names", []) or []),
            "room_polygons": room_polygons,
            "world_outline_segments": list(room_entry.get("world_outline_segments", []) or []),
            "world_path_segments": list(room_entry.get("world_path_segments", []) or []),
            "doorway_world_segments": list(room_entry.get("doorway_world_segments", []) or []),
            "path_wall_infos": list(room_entry.get("path_wall_infos", []) or [])
        })

    object_layers = {
        "doors": [],
        "interactive_entities": [],
        "reward_boxes": [],
        "alchemy_boxes": [],
        "teleports": [],
        "basecamp_points": [],
        "scene_windows": [],
        "scene_panels": [],
        "escape_submit_points": []
    }
    for entry in payload.get("doors", []) or []:
        object_layers["doors"].append({
            "uid": entry.get("uid", ""),
            "door_id": _safe_int(entry.get("door_id", -1), -1),
            "door_role": entry.get("door_role", ""),
            "door_label": entry.get("door_label", ""),
            "room_index": _safe_int(entry.get("room_index", -1), -1),
            "pos": list(entry.get("pos", [0.0, 0.0, 0.0])),
            "model_path": entry.get("model_path", ""),
            "door_facing_label": entry.get("door_facing_label", ""),
            "door_facing_axis": entry.get("door_facing_axis", ""),
            "door_yaw_deg": _safe_float(entry.get("door_yaw_deg", 0.0), 0.0)
        })
    for entry in payload.get("interactive_entities", []) or []:
        object_layers["interactive_entities"].append({
            "uid": entry.get("uid", ""),
            "template_id": _safe_int(entry.get("template_id", -1), -1),
            "special_label": entry.get("special_label", ""),
            "treasure_role": entry.get("treasure_role", ""),
            "room_index": _safe_int(entry.get("room_index", -1), -1),
            "pos": list(entry.get("pos", [0.0, 0.0, 0.0])),
            "model_path": entry.get("model_path", ""),
            "scene_group_map": entry.get("scene_group_map", "")
        })
    for entry in payload.get("reward_boxes", []) or []:
        object_layers["reward_boxes"].append({
            "uid": entry.get("uid", ""),
            "box_id": _safe_int(entry.get("box_id", -1), -1),
            "box_kind": entry.get("box_kind", ""),
            "box_state_name": entry.get("box_state_name", ""),
            "box_quality_label": entry.get("box_quality_label", ""),
            "pos": list(entry.get("pos", [0.0, 0.0, 0.0])),
            "config_model_path": entry.get("config_model_path", "")
        })
    for entry in payload.get("alchemy_boxes", []) or []:
        object_layers["alchemy_boxes"].append({
            "uid": entry.get("uid", ""),
            "pos": list(entry.get("pos", [0.0, 0.0, 0.0])),
            "is_synthesizing": bool(entry.get("is_synthesizing", False)),
            "box_name_tid": entry.get("box_name_tid", "")
        })
    for entry in payload.get("teleports", []) or []:
        object_layers["teleports"].append({
            "uid": entry.get("uid", ""),
            "pos": list(entry.get("pos", [0.0, 0.0, 0.0])),
            "dest_pos": list(entry.get("dest_pos", [0.0, 0.0, 0.0])),
            "class_name": entry.get("class_name", "")
        })
    for entry in payload.get("basecamp_points", []) or []:
        object_layers["basecamp_points"].append({
            "uid": entry.get("uid", ""),
            "class_name": entry.get("class_name", ""),
            "interact_pos": list(entry.get("interact_pos", [0.0, 0.0, 0.0])),
            "dest_pos": list(entry.get("dest_pos", [0.0, 0.0, 0.0])),
            "model_name": entry.get("model_name", "")
        })
    for entry in payload.get("scene_windows", []) or []:
        object_layers["scene_windows"].append({
            "uid": entry.get("uid", ""),
            "pos": list(entry.get("pos", [0.0, 0.0, 0.0]))
        })
    for entry in payload.get("scene_panels", []) or []:
        object_layers["scene_panels"].append({
            "uid": entry.get("uid", ""),
            "pos": list(entry.get("pos", [0.0, 0.0, 0.0]))
        })
    for entry in payload.get("escape_submit_points", []) or []:
        object_layers["escape_submit_points"].append({
            "uid": entry.get("uid", ""),
            "class_name": entry.get("class_name", ""),
            "pos": list(entry.get("pos", [0.0, 0.0, 0.0]))
        })

    object_ref_count = 0
    for key in object_layers:
        object_ref_count += len(object_layers.get(key, []) or [])

    scene_refs = _build_goldrush_scene_geometry_refs(payload.get("scene_id", -1))
    draw_pack = _build_goldrush_draw_pack(
        scene_refs,
        bounds,
        geometry_rooms,
        combined_outline_segments,
        combined_path_segments,
        combined_doorway_segments,
        object_layers
    )

    return {
        "scene_refs": scene_refs,
        "bounds": bounds,
        "rooms": geometry_rooms,
        "world_outline_segments": combined_outline_segments,
        "world_path_segments": combined_path_segments,
        "world_doorway_segments": combined_doorway_segments,
        "model_refs": model_refs,
        "object_layers": object_layers,
        "draw_pack": draw_pack,
        "stats": {
            "room_count": len(geometry_rooms),
            "world_outline_segment_count": len(combined_outline_segments),
            "world_path_segment_count": len(combined_path_segments),
            "world_doorway_segment_count": len(combined_doorway_segments),
            "model_ref_count": len(model_refs),
            "object_ref_count": object_ref_count,
            "draw_floor_group_count": len(draw_pack.get("floor_groups", []) or []),
            "draw_room_polygon_count": len(draw_pack.get("room_polygons", []) or []),
            "draw_door_marker_count": len(draw_pack.get("door_markers", []) or []),
            "draw_polyline_count": len(draw_pack.get("polylines", []) or []),
            "draw_polygon_count": len(draw_pack.get("polygons", []) or []),
            "draw_marker_count": len(draw_pack.get("markers", []) or []),
            "visible_polyline_count": len(draw_pack.get("esp_protocol", {}).get("layers", {}).get("polylines", []) or []),
            "visible_polygon_count": len(draw_pack.get("esp_protocol", {}).get("layers", {}).get("polygons", []) or []),
            "visible_marker_count": len(draw_pack.get("esp_protocol", {}).get("layers", {}).get("markers", []) or [])
        }
    }

def collect_goldrush_monsters(unit_mgr):
    monsters_data = []
    try:
        from common_cs import ComuKeys
        monster_type = getattr(ComuKeys.UNIT_TYPE_CONF, 'GOLD_RUSH_MONSTER', None)
        if monster_type is None:
            return monsters_data
        monsters = safe_get_units_by_type_from_mgr(unit_mgr, monster_type)
        for mon in monsters:
            try:
                pos = _extract_entity_position(mon)
                if not pos:
                    continue
                hp_comp = getattr(mon, 'ref_hp_comp', None)
                hp_value = 0.0
                if hp_comp:
                    hp_value = round(_safe_float(getattr(hp_comp, 'health', getattr(hp_comp, 'cur_hp', 0.0)), 0.0), 1)
                monsters_data.append({
                    "uid": _extract_entity_identity(mon),
                    "hp": hp_value,
                    "pos": _vec3_to_list(pos)
                })
            except:
                pass
    except:
        pass
    return monsters_data

def collect_goldrush_monster_hp_data():
    payload = {
        "type": "goldrush_monster_hp",
        "valid": False,
        "monsters": []
    }
    try:
        active_unit_mgr = get_available_ref_unit_mgr() or get_available_unit_mgr()
        if not active_unit_mgr:
            return json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(',', ':'))
        payload["monsters"] = collect_goldrush_monsters(active_unit_mgr)
        payload["valid"] = True
    except Exception as e:
        payload["error"] = str(e)
    return json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(',', ':'))

def _build_goldrush_runtime_payload():
    payload = {
        "type": "goldrush_runtime",
        "valid": False,
        "scene_id": -1,
        "scene_name_tid": "",
        "scene_name": "",
        "world_type": -1,
        "world_type_name": "",
        "mode_name": "",
        "monsters": [],
        "reward_boxes": [],
        "reward_boxes_meta": {},
        "summary": {}
    }
    try:
        map_info = get_current_map_info() or {}
        if not map_info or not map_info.get('is_goldrush'):
            return payload
        payload["scene_id"] = _safe_int(map_info.get('scene_id', -1), -1)
        payload["scene_name_tid"] = _safe_uid_text(map_info.get('scene_name_tid', ''))
        payload["scene_name"] = _safe_uid_text(map_info.get('scene_name', ''))
        payload["world_type"] = _safe_int(map_info.get('world_type', -1), -1)
        payload["world_type_name"] = _safe_uid_text(map_info.get('world_type_name', ''))
        payload["mode_name"] = _safe_uid_text(map_info.get('mode_name', ''))
        player = getattr(GK, 'g_unit', None)
        room = getattr(player, 'room', None) if player else None
        combat_core = get_available_combat_core() or getattr(room, 'combat_core', None)
        payload["generation_seed"] = _get_goldrush_current_generation_seed(combat_core)
        active_unit_mgr = get_available_ref_unit_mgr() or get_available_unit_mgr()
        if not room or not active_unit_mgr:
            return payload
        for unit in _iter_manager_units(active_unit_mgr):
            cls_name = type(unit).__name__
            try:
                if 'GoldRushRewardBox' in cls_name:
                    payload["reward_boxes"].append(_extract_reward_box_entry(unit))
            except:
                pass
        seed_reward_entries = _merge_seed_reward_boxes_into_payload(
            payload,
            payload["scene_id"],
            payload.get("generation_seed")
        )
        payload["reward_boxes"].sort(key=lambda item: (
            bool(item.get("seed_generated", False)),
            item.get("box_level", -1),
            item.get("uid", "")
        ))
        payload_generation_seed = _normalize_goldrush_generation_seed(payload.get("generation_seed"))
        seed_runtime_state = GOLDRUSH_SEED_RENDER_STATE if isinstance(GOLDRUSH_SEED_RENDER_STATE, dict) else {}
        fog_control = dict(GOLDRUSH_FOG_LAST_RESULT or {})
        seed_box_control = dict(GOLDRUSH_SEED_BOX_LAST_RESULT or {})
        reward_boxes_meta = {
            "source": _safe_uid_text(seed_runtime_state.get("source", "")),
            "mark_key_prefix": "",
            "session_token": "",
            "selected_count": 0,
            "seed_active_count": len(seed_reward_entries),
            "scene_match": False,
            "generation_seed_match": False,
            "session_match": False
        }
        reward_box_known_drop_count = sum(1 for item in payload["reward_boxes"] if int(item.get("drop_item_id", -1) or -1) > 0)
        reward_box_opened_count = sum(1 for item in payload["reward_boxes"] if item.get("is_opened"))
        reward_box_seed_count = sum(1 for item in payload["reward_boxes"] if item.get("seed_generated"))
        payload["reward_boxes_meta"] = reward_boxes_meta
        payload["summary"] = {
            "reward_box_count": len(payload["reward_boxes"]),
            "reward_box_seed_count": reward_box_seed_count,
            "reward_box_known_drop_count": reward_box_known_drop_count,
            "reward_box_opened_count": reward_box_opened_count,
            "reward_box_seed_active_count": len(seed_reward_entries),
            "generation_seed": payload_generation_seed,
            "now_round_seed": None,
            "candidate_count": 0,
            "collected_candidate_count": 0,
            "selected_count": 0,
            "postprocess_group_counts": {},
            "candidate_lookup_stats": {},
            "runtime_token_validation": {"stable": False},
            "clear_existing_frida_marks": {
                "found_count": 0,
                "cleared_count": 0
            },
            "reward_boxes": {
                "source": reward_boxes_meta["source"],
                "mark_key_prefix": reward_boxes_meta["mark_key_prefix"]
            }
        }
        payload["fog_control"] = fog_control
        payload["seed_box_control"] = seed_box_control
        payload["valid"] = True
    except Exception as e:
        payload["error"] = str(e)
    finally:
        # #region debug-point B:runtime-payload-perf
        try:
            _goldrush_debug_perf(
                "runtime_payload_build",
                "B",
                "main.cpp:_build_goldrush_runtime_payload",
                (time.time() - debug_started_at) * 1000.0,
                {
                    "valid": bool(payload.get("valid")),
                    "scene_id": _safe_int(payload.get("scene_id", -1), -1),
                    "reward_box_count": len(payload.get("reward_boxes", []) or []),
                    "seed_reward_active_count": _safe_int((payload.get("summary", {}) or {}).get("reward_box_seed_active_count", 0), 0),
                    "error": _safe_uid_text(payload.get("error", ""))
                }
            )
        except:
            pass
        # #endregion
    return payload

def collect_goldrush_runtime_data():
    # #region debug-point B:runtime-export
    debug_started_at = time.time()
    payload = {}
    response_text = ""
    try:
        payload = _build_goldrush_runtime_payload()
        response_text = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(',', ':'))
        return response_text
    finally:
        try:
            _goldrush_debug_perf(
                "runtime_payload_export",
                "B",
                "main.cpp:collect_goldrush_runtime_data",
                (time.time() - debug_started_at) * 1000.0,
                {
                    "valid": bool(payload.get("valid")) if isinstance(payload, dict) else False,
                    "reward_box_count": len(payload.get("reward_boxes", []) or []) if isinstance(payload, dict) else 0,
                    "response_bytes": len(response_text or "")
                }
            )
        except:
            pass
    # #endregion

def _publish_goldrush_runtime_snapshot(loop_now=None, force_invalid=False, reason=""):
    now_value = float(loop_now or time.time())
    if force_invalid:
        payload = {
            "type": "goldrush_runtime",
            "valid": False,
            "scene_id": -1,
            "scene_name_tid": "",
            "scene_name": "",
            "world_type": -1,
            "world_type_name": "",
            "mode_name": "",
            "monsters": [],
            "reward_boxes": [],
            "reward_boxes_meta": {},
            "summary": {},
            "error": _safe_uid_text(reason)
        }
        _set_tick_payload("goldrush_runtime", json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(',', ':')), now_value)
        return
    try:
        payload_text = collect_goldrush_runtime_data()
        if payload_text:
            _set_tick_payload("goldrush_runtime", payload_text, now_value)
    except:
        pass

def _goldrush_nav_vec3_to_list(value):
    if value is None:
        return []
    if isinstance(value, (list, tuple)) and len(value) >= 3:
        return [
            _safe_float(value[0], 0.0),
            _safe_float(value[1], 0.0),
            _safe_float(value[2], 0.0)
        ]
    try:
        return [
            _safe_float(getattr(value, 'x', 0.0), 0.0),
            _safe_float(getattr(value, 'y', 0.0), 0.0),
            _safe_float(getattr(value, 'z', 0.0), 0.0)
        ]
    except:
        return []

def _goldrush_nav_iter_values(value):
    if value is None:
        return
    if isinstance(value, (list, tuple)):
        for item in value:
            yield item
        return
    try:
        for item in value:
            yield item
    except:
        return

def _goldrush_nav_serialize_points(value, limit=256):
    result = []
    for raw in _goldrush_nav_iter_values(value):
        point = _goldrush_nav_vec3_to_list(raw)
        if len(point) == 3:
            result.append(point)
        if len(result) >= max(1, int(limit or 256)):
            break
    return result

def _goldrush_nav_make_vec(point):
    import math3d
    return math3d.vector(float(point[0]), float(point[1]), float(point[2]))

def _goldrush_nav_get_player_pos(player):
    if player is None:
        return []
    for method_name in ('get_position3', 'get_pos', 'get_position'):
        try:
            getter = getattr(player, method_name, None)
            if callable(getter):
                point = _goldrush_nav_vec3_to_list(getter())
                if len(point) == 3:
                    return point
        except:
            pass
    for attr_name in ('world_position', 'position', 'pos', 'logic_position', 'server_position', 'move_pos', 'cur_pos'):
        try:
            point = _goldrush_nav_vec3_to_list(getattr(player, attr_name, None))
            if len(point) == 3:
                return point
        except:
            pass
    return []

def _goldrush_nav_get_local_uid():
    try:
        g_unit = getattr(GK, 'g_unit', None)
        if g_unit:
            return _safe_uid_text(getattr(g_unit, 'uid', ''))
    except:
        pass
    return ""

def _goldrush_nav_get_mode_players():
    try:
        g_unit = getattr(GK, 'g_unit', None)
        room = getattr(g_unit, 'room', None) if g_unit else None
        combat_core = getattr(room, 'combat_core', None) if room else None
        ref_unit_mgr = getattr(combat_core, 'ref_unit_mgr', None) if combat_core else None
        getter = getattr(ref_unit_mgr, 'get_mode_player_units', None) if ref_unit_mgr else None
        if callable(getter):
            return list(getter() or [])
    except:
        pass
    return []

def _goldrush_nav_find_local_player():
    local_uid = _goldrush_nav_get_local_uid()
    mode_players = _goldrush_nav_get_mode_players()
    if local_uid:
        for unit in mode_players:
            try:
                if _safe_uid_text(getattr(unit, 'uid', '')) == local_uid:
                    return unit
            except:
                pass
    try:
        player = getattr(getattr(GK, 'g_world_mgr', None), 'cur_player', None)
        if player:
            return player
    except:
        pass
    try:
        player = getattr(GK, 'g_unit', None)
        if player:
            return player
    except:
        pass
    if mode_players:
        return mode_players[0]
    return None

def _goldrush_nav_find_guideline_component(player):
    if player is None:
        return None, {"path": "player_none"}
    for attr_name in ('guide_line_trail_comp', 'guideline_trail_comp', 'ref_guideline_trail_comp'):
        try:
            comp = getattr(player, attr_name, None)
            if comp:
                return comp, {"path": "attr", "name": attr_name}
        except:
            pass
    try:
        getter = getattr(player, 'get_component', None)
        enum_value = getattr(UnitComponentType, 'GoldRushGuideLineTrail', None)
        if callable(getter) and enum_value is not None:
            comp = getter(enum_value)
            if comp:
                return comp, {"path": "get_component_enum", "name": "GoldRushGuideLineTrail"}
    except:
        pass
    for attr_name in dir(player):
        try:
            lower_name = attr_name.lower()
            if 'guideline' not in lower_name and 'trail' not in lower_name:
                continue
            comp = getattr(player, attr_name, None)
            if comp and 'trail' in type(comp).__name__.lower():
                return comp, {"path": "dir_keyword", "name": attr_name}
        except:
            pass
    return None, {"path": "not_found"}

def _goldrush_nav_compute_single_path(guideline_comp, player_pos, target_pos):
    if guideline_comp is None or len(player_pos) != 3 or len(target_pos) != 3:
        return []
    try:
        direct_points = getattr(guideline_comp, '_get_path_points', None)
        if callable(direct_points):
            result = _goldrush_nav_serialize_points(
                direct_points(_goldrush_nav_make_vec(player_pos), _goldrush_nav_make_vec(target_pos)),
                256
            )
            if result:
                return result
    except:
        pass
    for attr_name in ('ref_detour_sys', 'detour_sys', 'nav_system'):
        try:
            nav_sys = getattr(guideline_comp, attr_name, None)
            if not nav_sys:
                continue
            for method_name in ('find_path', '_find_path', 'get_path_points', '_get_path_points'):
                try:
                    method = getattr(nav_sys, method_name, None)
                    if not callable(method):
                        continue
                    result = _goldrush_nav_serialize_points(
                        method(_goldrush_nav_make_vec(player_pos), _goldrush_nav_make_vec(target_pos)),
                        256
                    )
                    if result:
                        return result
                except:
                    pass
        except:
            pass
    return []

def collect_goldrush_nav_paths_data(request_token, targets):
    # #region debug-point C:nav-paths-start
    debug_started_at = time.time()
    # #endregion
    payload = {
        "type": "goldrush_nav_paths",
        "valid": False,
        "request_token": _safe_int(request_token, 0),
        "scene_id": -1,
        "generation_seed": None,
        "scene_name": "",
        "mode_name": "",
        "player_pos": [],
        "target_count": 0,
        "path_count": 0,
        "paths": []
    }
    try:
        map_info = get_current_map_info() or {}
        if not map_info or not map_info.get('is_goldrush'):
            payload["error"] = "not_goldrush"
            return json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(',', ':'))
        payload["scene_id"] = _safe_int(map_info.get('scene_id', -1), -1)
        payload["scene_name"] = _safe_uid_text(map_info.get('scene_name', ''))
        payload["mode_name"] = _safe_uid_text(map_info.get('mode_name', ''))
        payload["generation_seed"] = _get_goldrush_current_generation_seed(get_available_combat_core())
        normalized_targets = []
        if isinstance(targets, (list, tuple)):
            for raw_target in targets[:64]:
                if not isinstance(raw_target, dict):
                    continue
                pos = _goldrush_nav_vec3_to_list(raw_target.get('pos', []))
                if len(pos) != 3:
                    continue
                normalized_targets.append({
                    "class_name": _safe_uid_text(raw_target.get('class_name', '')),
                    "label": _safe_uid_text(raw_target.get('label', '')),
                    "target_pos": pos
                })
        payload["target_count"] = len(normalized_targets)
        if not normalized_targets:
            payload["valid"] = True
            return json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(',', ':'))

        player = _goldrush_nav_find_local_player()
        if player is None:
            payload["error"] = "player_not_found"
            return json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(',', ':'))
        player_pos = _goldrush_nav_get_player_pos(player)
        if len(player_pos) != 3:
            payload["error"] = "player_pos_not_found"
            return json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(',', ':'))
        payload["player_pos"] = player_pos

        guideline_comp, guideline_find = _goldrush_nav_find_guideline_component(player)
        if guideline_comp is None:
            for fallback_player in _goldrush_nav_get_mode_players():
                if fallback_player is player:
                    continue
                guideline_comp, guideline_find = _goldrush_nav_find_guideline_component(fallback_player)
                if guideline_comp is not None:
                    player = fallback_player
                    player_pos = _goldrush_nav_get_player_pos(player)
                    if len(player_pos) == 3:
                        payload["player_pos"] = player_pos
                    break
        payload["guideline"] = {
            "found": guideline_comp is not None,
            "find": guideline_find,
            "class": type(guideline_comp).__name__ if guideline_comp else ""
        }
        if guideline_comp is None:
            payload["error"] = "guideline_not_found"
            return json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(',', ':'))

        for index, target in enumerate(normalized_targets):
            target_pos = target.get("target_pos", [])
            path_points = _goldrush_nav_compute_single_path(guideline_comp, player_pos, target_pos)
            payload["paths"].append({
                "index": index,
                "class_name": target.get("class_name", ""),
                "label": target.get("label", ""),
                "target_pos": target_pos,
                "point_count": len(path_points),
                "path_points": path_points
            })
        payload["path_count"] = len(payload["paths"])
        payload["valid"] = True
    except Exception as e:
        payload["error"] = str(e)
    finally:
        # #region debug-point C:nav-paths-perf
        try:
            _goldrush_debug_perf(
                "nav_paths_collect",
                "C",
                "main.cpp:collect_goldrush_nav_paths_data",
                (time.time() - debug_started_at) * 1000.0,
                {
                    "valid": bool(payload.get("valid")),
                    "request_token": _safe_int(payload.get("request_token", 0), 0),
                    "target_count": _safe_int(payload.get("target_count", 0), 0),
                    "path_count": _safe_int(payload.get("path_count", 0), 0),
                    "error": _safe_uid_text(payload.get("error", "")),
                    "guideline_found": bool((payload.get("guideline", {}) or {}).get("found", False))
                }
            )
        except:
            pass
        # #endregion
    return json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(',', ':'))

def collect_goldrush_reference_data():
    payload = {
        "type": "goldrush_reference",
        "valid": False,
        "scene": dict(GOLDRUSH_SCENE_REFERENCE),
        "levels": [dict(item) for item in GOLDRUSH_LEVEL_REFERENCE],
        "items": [],
        "item_count": 0,
        "reward_boxes": [],
        "buffs": [],
        "interact_types": [],
        "interact_conditions": [],
        "interact_effects": [],
        "doorway_configs": [],
        "minimap_reference": {},
        "navigation_reference": {},
        "states": [],
        "skills": [],
        "global_params": {},
        "basecamp_ui": [],
        "treasure_key_chain": {}
    }
    try:
        table = _get_goldrush_item_data_table()
        items = []
        for raw_key, cfg in table.items():
            try:
                item_id = _safe_int(raw_key, _safe_int(cfg.get('id', -1), -1))
                if item_id <= 0:
                    continue
                name_tid = _safe_uid_text(cfg.get('name', cfg.get('g_name', '')))
                items.append({
                    "item_id": item_id,
                    "name_tid": name_tid,
                    "name": _resolve_tid_text(name_tid),
                    "value": _safe_int(cfg.get('value', 0), 0),
                    "sold_price": _safe_int(cfg.get('sold_price', 0), 0),
                    "weight": _safe_float(cfg.get('weight', 0.0), 0.0),
                    "storage_type": _safe_int(cfg.get('storage_type', 0), 0),
                    "tag": _safe_uid_text(cfg.get('tag', '')),
                    "stack_limit": _safe_int(cfg.get('stack_limit', 0), 0)
                })
            except:
                pass
        items.sort(key=lambda item: item.get("item_id", 0))
        payload["items"] = items
        payload["item_count"] = len(items)
        payload["reward_boxes"] = _build_table_entries('goldrush_reward_box', ('box_type', 'box_quality', 'box_level', 'reward_id', 'class_level', 'box_anim_type'))
        payload["buffs"] = _build_table_entries('goldrush_buff', ('buff_tid', 'buff_desc_tid', 'buff_icon_path', 'duration', 'show_type', 'show_priority', 'is_show', 'stack_type', 'target_type', 'time_stackable'))
        for entry in payload["buffs"]:
            entry["name"] = _resolve_tid_text(entry.get("buff_tid", ''))
            entry["desc"] = _resolve_tid_text(entry.get("buff_desc_tid", ''))
        payload["interact_types"] = _build_table_entries('goldrush_interact_entity_type', ('type_name', 'scene_group_map', 'entity_category', 'default_state', 'model_path', 'interact_icon', 'interact_icon_down'))
        for entry in payload["interact_types"]:
            template_id = _safe_int(entry.get("id", -1), -1)
            chain_info = _build_goldrush_interact_chain_info(template_id)
            entry["required_item_ids"] = list(chain_info.get("required_item_ids", []))
            entry["produced_item_ids"] = list(chain_info.get("produced_item_ids", []))
            entry["required_items"] = _get_goldrush_item_names(entry["required_item_ids"])
            entry["produced_items"] = _get_goldrush_item_names(entry["produced_item_ids"])
        payload["interact_conditions"] = _build_table_entries('goldrush_interact_condition', ('condition_type', 'start_state'))
        for entry in payload["interact_conditions"]:
            cfg = _get_dm_row('goldrush_interact_condition', entry.get("id", -1))
            entry["item_ids"] = sorted(item_id for item_id in _collect_numeric_values(cfg.get('params', {})) if item_id > 0)
            entry["items"] = _get_goldrush_item_names(entry.get("item_ids", []))
        payload["interact_effects"] = _build_table_entries('goldrush_interact_effect', ('effect_type', 'interact_type_id', 'priority', 'start_state', 'target', 'target_state'))
        for entry in payload["interact_effects"]:
            cfg = _get_dm_row('goldrush_interact_effect', entry.get("id", -1))
            entry["item_ids"] = sorted(item_id for item_id in _collect_numeric_values(cfg.get('params', {})) if item_id > 0)
            entry["items"] = _get_goldrush_item_names(entry.get("item_ids", []))
        payload["doorway_configs"] = _build_table_entries('goldrush_doorway_configs', ('model', 'theme'))
        payload["minimap_reference"] = {
            "fog_bitmap_class": "MazeFogBitmap",
            "fog_resolution_server": 128,
            "fog_resolution_client": 256,
            "voxel_to_img_pixel": 60,
            "minimap_ui": "UIBattleGoldRushMiniMap",
            "bigmap_ui": "UIBattleGoldRushBigMap",
            "can_force_clear_fog": True,
            "force_clear_fog_note": "